#!/usr/bin/env python3
"""Vérification reproductible du lemme 5.38 (arithmétique entière exacte)."""
import math
import random


def U(n: int) -> int:
    assert n > 0
    return (3*n + 1)//2 if n%2 else n//2


def nu2(n: int) -> int:
    assert n > 0
    return (n & -n).bit_length() - 1


def windows(n: int):
    """De la fenêtre du pied à celle de tête ; zéros de tête ajoutés si nécessaire."""
    L = max(3, len(str(n)))
    p = n%2
    lam = 1+2*p
    res = {}
    for i in range(L-2):
        w = (n//10**i)%1000
        carry_in = (lam*(n%10**i)+p)//10**i
        z,y,x = w%10,(w//10)%10,(w//100)%10
        t0 = lam*z+carry_in
        th0,e0 = t0%10,t0//10
        t1 = lam*y+e0
        th1,e1 = t1%10,t1//10
        t2 = lam*x+e1
        th2,e2 = t2%10,t2//10
        b0 = th0//2+5*(th1%2)
        b1 = th1//2+5*(th2%2)
        res[i] = {'window': w, 'carry_in':carry_in,
                  'out':(b1,b0), 'high':(th2,e2)}
        assert 0<=carry_in<=2
        if i>0:
            prev=res[i-1]
            assert w%100 == prev['window']//10
            assert b0 == prev['out'][0]
            prev_digit=(n//10**(i-1))%10
            expected=(lam*prev_digit+prev['carry_in'])//10
            assert carry_in == expected
    b = [None]*(L+1)
    for i,dat in res.items():
        b[i]=dat['out'][1]
        b[i+1]=dat['out'][0]
    th2,e2=res[L-3]['high']
    b[L-1]=th2//2+5*(e2%2)
    b[L]=e2//2
    assert all(d is not None for d in b)
    reconstructed=sum(d*10**i for i,d in enumerate(b))
    assert reconstructed == U(n), (n,reconstructed,U(n))
    return res


def certificate(u: int):
    """Croissance d'un chiffre à la fois, avec fenêtre de 3 chiffres au minimum."""
    assert u>0 and u%2
    a=nu2(3*u+1)
    for s in range(1,a+2):
        t=u%10**s
        v=nu2(3*t+1)
        if v<s:
            assert v==a
            assert s==a+1
            break
        assert a>=s
    assert v==a
    return a,s


if __name__=='__main__':
    # Teste exhaustivement la représentation sur les 40 000 premiers entiers positifs.
    samples=range(1,40001)
    for n in samples:
        windows(n)
        if n%2: certificate(n)

    # Teste des valeurs allant jusqu'à cent chiffres.
    rng=random.Random(538239)
    for i in range(12000):
        L=rng.randint(3,100)
        n=rng.randrange(10**(L-1), 10**L)
        windows(n)
        if n%2: certificate(n)

    a,s=certificate(4984461)
    assert (a,s)==(3,4)
    assert U(4984461)==7476692
    assert (3*4984461+1)//8==1869173
    assert [(windows(4984461)[i]['window'], windows(4984461)[i]['carry_in'],
             windows(4984461)[i]['out']) for i in range(4,-1,-1)] == [
             (498,1,(4,7)),(984,1,(7,6)),(844,1,(6,6)),(446,0,(6,9)),(461,1,(9,2))]
    assert U(4512)==2256

    # Vérifie l'identité logarithmique bloc par bloc sur plusieurs trajectoires impaires.
    for u0 in range(3,5000,2):
        u=u0; A=0; R=0.
        for j in range(20):
            if u==1: break
            a=nu2(3*u+1)
            A+=a
            R+=math.log2(1+1/(3*u))
            u=(3*u+1)//2**a
            D=A-(j+1)*math.log2(3)-R
            exact=math.log2(u0/u)
            assert math.isclose(D,exact,rel_tol=1e-10,abs_tol=1e-11),(u0,j,D,exact)
    print('Vérification OK: 40 000 entiers exhaustifs, 12 000 tirages reproductibles')
    print('Certificat 4 984 461 :', certificate(4984461), 'U=7476692, impair suivant=1869173')
    print('Déficit du bloc :', math.log2(4984461/1869173))
