# Matrice Φ–Ψ des blocs de corps 000–999

## Objet

Chaque bloc `B` représente **trois positions décimales consécutives** du corps ; `007` doit rester distinct, en notation, de `7` comme bloc de largeur fixe.
Le bloc **ne suit pas Syracuse de manière autonome** : la branche de multiplication dépend de la parité **globale** du nombre et les deux frontières doivent être raccordées.

## Convention d’orientation des deux flux

- La **retenue de multiplication** arrive depuis le bloc situé **à droite** (du pied vers la tête), puis ressort **à gauche**.
- Le **reste de division** arrive depuis le bloc situé **à gauche** (de la tête vers le pied), puis ressort **à droite**.

Ainsi, pour `p=N mod 2`, `λ=1+2p`, `B` entre 000 et 999, `c` la retenue entrante de droite et `r` le reste entrant de gauche :

```text
T = λ B + c
M = T mod 1000
C = floor(T / 1000)
Q = floor((1000 r + M)/2)
R = M mod 2
```

L'opérateur local est : `(B,p,c,r) → (Q,C,R)`.

Pour un entier pair (`p=0`), seule la retenue `c=0` est physiquement possible : 2 modes par bloc (`r=0` ou `r=1`). Pour un impair (`p=1`), trois retenues entrantes `c=0,1,2` et deux restes `r=0,1` : 6 modes. **Total : 8 modes par bloc**, soit **8 000 lignes** pour 1 000 blocs.

## Condition de recollement (blocs voisins)

Si `A` est le bloc de **gauche** et `B` celui de **droite** :

```text
A.c_entrant_droite = B.C_sortante_gauche
B.r_entrant_gauche = A.R_sortant_droite
```

Les sorties de deux cellules ne doivent donc **jamais être choisies indépendamment**. Un mode admissible dans la table ne définit pas une branche libre pour un entier fixé.

## Initialisation et sommet

- Au pied du nombre : `c = p` (le `+1` de l'impair est injecté une seule fois).
- Après les propagations du pied vers la tête, soit `C_haut` la retenue totale sortant du dernier bloc. Au sommet du nombre : `r_haut = C_haut mod 2` et `Q_haut = floor(C_haut/2)` (éventuel bloc supplémentaire `001` de quotient).
- Le reste final au pied doit être nul, car `λN+p` est pair.

## Trois CSV complémentaires

1. **Matrice_Complete_8000.csv** — toutes les transitions de cellule `B,p,c,r`, leurs deux sorties de frontière et le bloc quotient à trois chiffres.
2. **Vue_Compacte_1000.csv** — exactement 1 ligne par bloc d’entrée, avec ses 8 sorties possibles et leurs frontières.
3. **Superposition_4000.csv** — projection propre au lemme 5.38 : les **deux chiffres inférieurs de la sortie** de chaque triplet sont indépendants du reste reçu depuis la gauche ; seule la sortie du chiffre supérieur en dépend. C'est la bonne forme pour les triplets décalés d'un chiffre.
4. **Adjacence_Creuses.csv** — projection sans mémoire de frontière sur les couples bloc d'entrée → bloc de sortie ; les multiplicités des modes y sont conservées. **Ce graphe projeté ne suffit pas pour obtenir la dynamique globale** sans réintroduire les conditions de recollement.

## Relation au déficit dyadique

Les lignes qui peuvent être un pied impair véritable (`p=1, c=1, B impair`) exposent la valeur `min(3, ν₂(3B+1))`. Pour un bloc de corps arbitraire, **cette valuation ne doit pas être interprétée comme une profondeur du nombre global**. Une profondeur exacte `ν₂(3N+1)` exige de prolonger le suffixe jusqu'à la précision suffisante ; on peut ensuite calculer une contribution exacte au déficit `δ(N)=a-log₂(3+1/N)` entre impairs.

## Reproductibilité

```bash
python3 syracuse_matrice_blocs_000_999.py --dossier .
```

Le programme vérifie l'identité `U(N)` par assemblage des lignes de la matrice, indépendamment sur de nombreux entiers (jusqu'à 120 chiffres), puis contrôle pour les triplets **chevauchants** la paire de chiffres de sortie attendue.

Ce travail est un **catalogue exhaustif des cellules locales**, pas une preuve de convergence universelle.
