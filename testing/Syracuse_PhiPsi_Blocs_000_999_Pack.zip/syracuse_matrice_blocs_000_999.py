#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Construit la matrice exhaustive de blocs Φ–Ψ de base 1000.

Un triplet B represente trois chiffres adjacents (000...999) dans un nombre,
NON un nombre soumis independamment a une iteration Syracuse.

Entrees d'une cellule:
    p  = parite GLOBALE du nombre, 0/1 ; lambda=1+2p
    c  = retenue entrante depuis le bloc de DROITE, 0/1/2 si impair,
         toujours 0 si pair
    r  = reste de division entrant depuis le bloc de GAUCHE, 0/1
Sorties:
    t  = lambda*B+c
    Bm = t % 1000       (bloc normalise apres multiplication)
    C  = t // 1000      (retenue sortante vers GAUCHE)
    Q  = (1000*r+Bm)//2 (bloc quotient, 3 chiffres)
    R  = Bm % 2        (reste sortant vers DROITE)

Les conditions de recollement entre voisin gauche A et droit B sont :
    A.c_entrant = B.c_sortant ; B.r_entrant = A.r_sortant.

La projection des deux derniers chiffres de sortie (fenetres chevauchantes)
ne depend pas du reste entrant de gauche, tandis que le chiffre superieur
peut en dependre. Cette distinction est centrale pour le lemme 5.38.
"""
import argparse
import csv
import json
import random
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

MODES = [('P', 0, 0), ('P', 0, 1)] + [
    ('I', c, r) for c in (0, 1, 2) for r in (0, 1)
]


def valuation2(n):
    if n <= 0:
        raise ValueError('valuation2 attend un entier positif')
    return (n & -n).bit_length() - 1


def cellule(B, p, c, r):
    if not (0 <= B <= 999 and p in (0, 1) and r in (0, 1)):
        raise ValueError('bloc/parite/reste invalide')
    if c not in ((0,) if p == 0 else (0, 1, 2)):
        raise ValueError('retenue impossible pour cette branche')
    lam = 1 + 2 * p
    t = lam * B + c
    bmult, cout = t % 1000, t // 1000
    q, rout = (1000 * r + bmult) // 2, bmult % 2
    assert 0 <= q <= 999 and 0 <= cout <= 2
    # Expression independante de r des deux derniers chiffres de sortie.
    b2 = bmult // 100
    b1 = (bmult // 10) % 10
    b0 = bmult % 10
    sortie_2 = 10 * (b1 // 2 + 5 * (b2 % 2)) + (b0 // 2 + 5 * (b1 % 2))
    assert sortie_2 == q % 100
    bsort_high = b2 // 2 + 5 * r
    assert bsort_high == q // 100
    return {
        'bloc_entree': f'{B:03d}',
        'parite_globale': p,
        'branche': 'P' if p == 0 else 'I',
        'lambda_global': lam,
        'retenue_entrante_droite': c,
        'reste_entrant_gauche': r,
        'produit_local_lambda_B_plus_retenue': t,
        'bloc_multiplie_normalise': f'{bmult:03d}',
        'retenue_sortante_gauche': cout,
        'dividende_local_1000_reste_plus_bloc': 1000*r + bmult,
        'bloc_sortie_divise': f'{q:03d}',
        'reste_sortant_droite': rout,
        'sortie_2_chiffres_superposition': f'{sortie_2:02d}',
        'chiffre_sortie_gauche': bsort_high,
        'compatible_bloc_pied_global': int((p == 0 and B % 2 == 0 and c == 0) or (p == 1 and B % 2 == 1 and c == 1)),
        'profondeur_dyadique_garantie_si_pied_impair': (
            min(3, valuation2(3*B + 1)) if p == 1 and B % 2 == 1 and c == 1 else ''
        ),
        'identifiant_mode': f'{"P" if p == 0 else "I"}_c{c}_r{r}',
    }


def U(n):
    return (n // 2) if n % 2 == 0 else ((3 * n + 1) // 2)


def blocs_base1000(n):
    if n < 0:
        raise ValueError
    if n == 0:
        return [0]
    v = []
    while n:
        v.append(n % 1000)
        n //= 1000
    return v  # du pied vers la tete


def reconstruire_par_blocs(n, table=None):
    """Le quotient complet est reconstruit en 2 passes, frontieres exactes."""
    p = n & 1
    blocks = blocs_base1000(n)
    c = p
    normalized = []
    mult_rows = []
    for b in blocks:
        t = (1 + 2*p) * b + c
        v, c_new = t % 1000, t // 1000
        normalized.append(v)
        mult_rows.append((b, c, v, c_new))
        c = c_new
    # Traitement du sommet du cone : le dernier report sortant
    # se divise aussi. Peut ajouter un bloc 001 au quotient.
    high = c // 2
    rem = c % 2
    out = [None]*len(blocks)
    div_rows = [None]*len(blocks)
    for i in range(len(blocks)-1, -1, -1):
        b, cin, v, cout = mult_rows[i]
        rem_in = rem
        if table is not None:
            qrow = table[(b, p, cin, rem_in)]
            q = int(qrow['bloc_sortie_divise'])
            rem = qrow['reste_sortant_droite']
        else:
            q, rem = (1000*rem + v) // 2, v % 2
        out[i] = q
        div_rows[i] = {'index_depuis_pied':i,'bloc_initial':f'{b:03d}',
                       'retenue_de_droite':cin,'bloc_apres_multiplication':f'{v:03d}',
                       'retenue_vers_gauche':cout,'reste_de_gauche':rem_in,
                       'bloc_sortie':f'{q:03d}', 'reste_vers_droite':rem}
    if rem != 0:
        raise AssertionError('le dividende global lambda*n+p doit etre pair')
    result = high * (1000 ** len(blocks)) + sum(q*(1000**i) for i, q in enumerate(out))
    assert result == U(n), (n, result, U(n))
    return result, div_rows, high


def write_csv(path, rows, fields):
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f, fieldnames=fields, delimiter=';', extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--dossier',default='/mnt/data')
    ap.add_argument('--verifications',type=int,default=15000)
    args=ap.parse_args()
    root=Path(args.dossier)
    root.mkdir(parents=True, exist_ok=True)
    rows=[]
    table={}
    compact=[]
    proj=[]
    sparse=defaultdict(list)
    for b in range(1000):
        rec={'bloc_000_999':f'{b:03d}', 'bloc_num':b,
             'parite_bloc_isole':b%2,
             'alpha_3_si_bloc_pied_impair': min(3, valuation2(3*b+1)) if b%2 else ''}
        for branch,c,r in MODES:
            p=int(branch=='I')
            row=cellule(b,p,c,r)
            rows.append(row)
            table[(b,p,c,r)]=row
            mode=row['identifiant_mode']
            rec[f'{mode}_sortie']=row['bloc_sortie_divise']
            rec[f'{mode}_retenue_vers_gauche']=row['retenue_sortante_gauche']
            rec[f'{mode}_reste_vers_droite']=row['reste_sortant_droite']
            sparse[(b,int(row['bloc_sortie_divise']))].append(mode)
            if r == 0:
                proj.append({
                    'bloc_000_999': f'{b:03d}',
                    'parite_globale':p,
                    'branche':branch,
                    'retenue_entrante_droite':c,
                    'bloc_multiplie_normalise':row['bloc_multiplie_normalise'],
                    'retenue_sortante_gauche':row['retenue_sortante_gauche'],
                    'sortie_2_chiffres_independante_reste_gauche':row['sortie_2_chiffres_superposition'],
                    'chiffre_gauche_si_reste_entrant_0':row['chiffre_sortie_gauche'],
                    'chiffre_gauche_si_reste_entrant_1':cellule(b,p,c,1)['chiffre_sortie_gauche'],
                    'reste_sortant_droite':row['reste_sortant_droite'],
                    'mode':f'{branch}_c{c}'})
        compact.append(rec)
    assert len(rows)==8000 and len(proj)==4000 and len(compact)==1000
    base='Syracuse_PhiPsi_Blocs_000_999'
    files={
        'matrice':root/f'{base}_Matrice_Complete_8000.csv',
        'compact':root/f'{base}_Vue_Compacte_1000.csv',
        'projection':root/f'{base}_Superposition_4000.csv',
        'adjacence':root/f'{base}_Adjacence_Creuses.csv',
    }
    write_csv(files['matrice'],rows,list(rows[0]))
    write_csv(files['compact'],compact,list(compact[0]))
    write_csv(files['projection'],proj,list(proj[0]))
    adjacency=[{
        'bloc_depart':f'{b:03d}', 'bloc_arrivee':f'{out:03d}',
        'nombre_modes_locaux':len(modes),
        'modes_couples_aux_frontieres':'|'.join(modes),
        'note':'projection seulement; exiger le recollement des frontieres pour la trajectoire'
    } for (b,out),modes in sorted(sparse.items())]
    write_csv(files['adjacence'],adjacency,list(adjacency[0]))

    rng=random.Random(20261116)
    # Recalcul par l'assemblage de la matrice elle-meme (pas seulement la formule).
    cases=[0,1,2,3,7,39,4512,4461,5461,4984461,999,1000,1001,
           2**69-1,10**21-1,10**35+234567890123456789]
    cases.extend(range(2,30002))
    for digits in (3,4,5,6,7,8,9,10,20,40,70,120):
        for _ in range(args.verifications//12):
            first=rng.randint(1,9)
            n=first*10**(digits-1)+rng.randrange(10**(digits-1))
            cases.append(n)
    for n in cases:
        val,_,_=reconstruire_par_blocs(n,table)
        assert val==U(n)
    # tester la projection chevauchante exacte de deux chiffres de chaque triplet.
    for n in cases:
        p=n%2
        L=len(str(n))
        if L<3: continue
        for i in range(L-2):
            w=n//10**i % 1000
            c=( (1+2*p)*(n%10**i)+p )//10**i
            row=table[(w,p,c,0)]
            expected=(U(n)//10**i)%100
            assert int(row['sortie_2_chiffres_superposition'])==expected, (n,i,w,expected,row)
    # Deux exemples audites avec tables de recollement.
    examples={}
    for n in (4512,4984461,4461,5461,999,2**69-1):
        value, blocks, high = reconstruire_par_blocs(n, table)
        examples[str(n)]={'U_n':value,'blocs_groupe_de_trois_du_pied_vers_la_tete':blocks,'quotient_haut':high}
    stats={
        'nombre_blocs':1000,
        'nombre_modes_physiquement_compatibles_par_bloc':8,
        'nombre_transitions_locales':len(rows),
        'nombre_projections_superposees':len(proj),
        'nombre_aretes_projetees_uniques':len(adjacency),
        'nombre_calculs_de_recollement_verifies':len(cases),
        'modes_par_branches':dict(Counter(row['branche'] for row in rows)),
        'valeurs_retenue_sortante_branche_impaire':dict(Counter(row['retenue_sortante_gauche'] for row in rows if row['parite_globale']==1)),
        'restes_sortants_branche_impaire':dict(Counter(row['reste_sortant_droite'] for row in rows if row['parite_globale']==1)),
        'nombre_modes_vers_une_meme_sortie_distribution':dict(sorted(Counter(len(modes) for modes in sparse.values()).items())),
        'exemples': examples,
    }
    meta=root/f'{base}_Verification.json'
    meta.write_text(json.dumps(stats,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    explanation=root/f'{base}_NOTICE.md'
    explanation.write_text('''# Matrice Φ–Ψ des blocs de corps 000–999

## Objet

Chaque bloc `B` représente **trois positions décimales consécutives** du corps ; `007` doit rester distinct, en notation, de `7` comme bloc de largeur fixe.
Le bloc **ne suit pas Syracuse de manière autonome** : la branche de multiplication dépend de la parité **globale** du nombre et les deux frontières doivent être raccordées.

## Convention d’orientation des deux flux

- La **retenue de multiplication** arrive depuis le bloc situé **à droite** (du pied vers la tête), puis ressort **à gauche**.
- Le **reste de division** arrive depuis le bloc situé **à gauche** (de la tête vers le pied), puis ressort **à droite**.

Ainsi, pour `p=N mod 2`, `λ=1+2p`, `B` entre 000 et 999, `c` la retenue entrante de droite et `r` le reste entrant de gauche :

```text
T = λ B + c
M = T mod 1000
C = floor(T / 1000)
Q = floor((1000 r + M)/2)
R = M mod 2
```

L'opérateur local est : `(B,p,c,r) → (Q,C,R)`.

Pour un entier pair (`p=0`), seule la retenue `c=0` est physiquement possible : 2 modes par bloc (`r=0` ou `r=1`). Pour un impair (`p=1`), trois retenues entrantes `c=0,1,2` et deux restes `r=0,1` : 6 modes. **Total : 8 modes par bloc**, soit **8 000 lignes** pour 1 000 blocs.

## Condition de recollement (blocs voisins)

Si `A` est le bloc de **gauche** et `B` celui de **droite** :

```text
A.c_entrant_droite = B.C_sortante_gauche
B.r_entrant_gauche = A.R_sortant_droite
```

Les sorties de deux cellules ne doivent donc **jamais être choisies indépendamment**. Un mode admissible dans la table ne définit pas une branche libre pour un entier fixé.

## Initialisation et sommet

- Au pied du nombre : `c = p` (le `+1` de l'impair est injecté une seule fois).
- Après les propagations du pied vers la tête, soit `C_haut` la retenue totale sortant du dernier bloc. Au sommet du nombre : `r_haut = C_haut mod 2` et `Q_haut = floor(C_haut/2)` (éventuel bloc supplémentaire `001` de quotient).
- Le reste final au pied doit être nul, car `λN+p` est pair.

## Trois CSV complémentaires

1. **Matrice_Complete_8000.csv** — toutes les transitions de cellule `B,p,c,r`, leurs deux sorties de frontière et le bloc quotient à trois chiffres.
2. **Vue_Compacte_1000.csv** — exactement 1 ligne par bloc d’entrée, avec ses 8 sorties possibles et leurs frontières.
3. **Superposition_4000.csv** — projection propre au lemme 5.38 : les **deux chiffres inférieurs de la sortie** de chaque triplet sont indépendants du reste reçu depuis la gauche ; seule la sortie du chiffre supérieur en dépend. C'est la bonne forme pour les triplets décalés d'un chiffre.
4. **Adjacence_Creuses.csv** — projection sans mémoire de frontière sur les couples bloc d'entrée → bloc de sortie ; les multiplicités des modes y sont conservées. **Ce graphe projeté ne suffit pas pour obtenir la dynamique globale** sans réintroduire les conditions de recollement.

## Relation au déficit dyadique

Les lignes qui peuvent être un pied impair véritable (`p=1, c=1, B impair`) exposent la valeur `min(3, ν₂(3B+1))`. Pour un bloc de corps arbitraire, **cette valuation ne doit pas être interprétée comme une profondeur du nombre global**. Une profondeur exacte `ν₂(3N+1)` exige de prolonger le suffixe jusqu'à la précision suffisante ; on peut ensuite calculer une contribution exacte au déficit `δ(N)=a-log₂(3+1/N)` entre impairs.

## Reproductibilité

```bash
python3 syracuse_matrice_blocs_000_999.py --dossier .
```

Le programme vérifie l'identité `U(N)` par assemblage des lignes de la matrice, indépendamment sur de nombreux entiers (jusqu'à 120 chiffres), puis contrôle pour les triplets **chevauchants** la paire de chiffres de sortie attendue.

Ce travail est un **catalogue exhaustif des cellules locales**, pas une preuve de convergence universelle.
''',encoding='utf-8')
    zipped=root/f'{base}_Pack.zip'
    with zipfile.ZipFile(zipped,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for fp in list(files.values())+[meta,explanation,Path(__file__)]:
            z.write(fp,arcname=fp.name)
    print(json.dumps({'files':{k:str(v) for k,v in files.items()},'notice':str(explanation),
                      'archive':str(zipped),
                      'stats':{k:v for k,v in stats.items() if k!='exemples'}},indent=2,ensure_ascii=False))

if __name__ == '__main__':
    main()
