# Syracuse Φ–Ψ — Deux réarmements consécutifs et contrôle du déficit

**Étude autonome**, prolongement de la matrice des réarmements `(r,t,r')`, de la superposition décimale et du déficit dyadique. Le manuscrit principal v14 n'est pas modifié par cette annexe. Les résultats ci-dessous sont exacts dans leur domaine ; ils ne démontrent pas la convergence universelle de Syracuse.

## 1. Définitions et domaine

On emploie la transformation accélérée `U(n)=n/2` si `n` est pair, `U(n)=(3n+1)/2` s'il est impair. À chaque départ impair non terminal `u_j>1`, poser :

- `r_j = ν₂(u_j+1)`, nombre de transitions impaires consécutives sous `U` ;
- `q_j = (u_j+1)/2^r_j`, impair ;
- `t_j = ν₂(3^r_j q_j - 1)`, nombre de transitions paires après le corridor impair ;
- `u_{j+1} = (3^r_j q_j - 1)/2^t_j`.

La matrice à deux réarmements est indexée par les cinq paramètres positifs `(r₀,t₀,r₁,t₁,r₂)`. Nous excluons `u₀=1` et `u₁=1`, mais le dernier état `u₂=1` est autorisé comme arrivée terminale.

## 2. Théorème : congruence exacte d'un double réarmement

Notons :

    M₁ = 2^(t₁+r₂+1)
    Q₁ = 3^(-r₁) (1-2^t₁+2^(t₁+r₂)) mod M₁
    M = 2^(t₀+r₁+t₁+r₂+1)

Les inverses de 3 sont les inverses multiplicatifs modulo la puissance de deux considérée.

Alors **tous** les entiers initiaux non terminaux qui réalisent exactement les cinq longueurs prescrites sont :

    q₀ ≡ 3^(-r₀) [1-2^t₀ + 2^(t₀+r₁) Q₁] (mod M)
    u₀ = 2^r₀ q₀ - 1,

avec `q₀` un représentant positif de la classe, assez grand pour que `u₀>1` et `u₁>1`. Une classe existe pour **tout** choix de cinq longueurs positives ; elle contient une infinité de représentants positifs.

**Preuve.** La condition `r₂=ν₂(u₂+1)` impose `q₁≡Q₁ (mod M₁)` pour le deuxième corridor. Or

    2^(t₀+r₁) q₁ = 3^r₀ q₀ - 1 + 2^t₀.

L'inversion de `3^r₀`, impaire, donne la congruence écrite. Elle entraîne réciproquement les valeurs exactes de `t₀`, `r₁`, `t₁`, `r₂` grâce au bit terminal `+1` présent dans chaque module. Le paramètre `r₀` est fixé par `u₀=2^r₀q₀-1` avec `q₀` impair.

**Précision nouvelle.** Le second corridor affine la classe initiale en ajoutant exactement `t₁+r₂` bits de congruence sur `q₀`.

## 3. Proposition : déficit cumulé de deux corridors

Poser `H = r₀+t₀+r₁+t₁`, `K=r₀+r₁`, et

    A = 2^H - 3^K,
    E = 2^(t₀+r₁)(2^t₁-1) + 3^r₁(2^t₀-1).

Alors `E>0` et

    u₂<u₀   si et seulement si   A q₀ > E.

On a donc `D₂ = log₂(u₀/u₂)>0` exactement lorsque cette inégalité est vraie. Si `A≤0`, tout membre de la classe est croissant sur les deux corridors. Si `A>0`, il faut vérifier le seuil `q₀>E/A`; une contraction multiplicative seule ne suffit pas en général.

**Preuve.** En éliminant `q₁` :

    u₂ = [3^(r₀+r₁) q₀ - 3^r₁ + 2^t₀(3^r₁-2^r₁)] / 2^(t₀+r₁+t₁).

Comparer avec `u₀=2^r₀q₀-1`, puis regrouper les termes.

### Certification par les triplets (lemme 5.41)

Sur les `K=r₀+r₁` étapes *impair vers impair*, les `r_j-1` premiers états impairs de chaque corridor ont une profondeur exactement `a=1`, et le dernier a `a=1+t_j`. La somme des profondeurs visibles aux trois premiers bits par fenêtres terminales est donc :

    A_K^min = K + min(t₀,2) + min(t₁,2).

Avant l'arrivée éventuelle à 1, tous les départs des `K` sous-blocs sont au moins 3 ; par suite :

    D₂ ≥ A_K^min - K log₂(10/3)
       = min(t₀,2) + min(t₁,2) - K log₂(5/3).

Cette borne **ne dépend que des longueurs des deux corridors**. Si elle est positive, elle constitue un certificat de descente, mais sa négativité n'est pas un certificat de croissance.

## 4. Calcul exact de la matrice 1..8

Pour chacun des cinq paramètres de 1 à 8, nous obtenons `8^5=32 768` motifs, chacun réalisable par une infinité de départs. Les cellules du CSV contiennent la classe congruentielle, un témoin minimal non terminal, les deux résultats impairs, la formule affine et le déficit numérique.

| Classification | Nombre de motifs |
| --- | ---: |
| Descente démontrée pour toute la classe | 27 128 |
| Croissance démontrée pour toute la classe | 5 640 |
| Seuil mixte dans cette plage | 0 |
| Certifiés par la seule borne de pied à trois chiffres | 4 600 |
| Le second motif augmente le plus petit départ admissible | 32 261 |
| Le plus petit départ reste inchangé | 507 |

Il s'agit du **comptage uniforme de cinq paramètres bornés**, et non d'une proportion d'entiers ou d'une loi de fréquence le long d'une trajectoire.

### Deux exemples

- `(r₀,t₀,r₁,t₁,r₂)=(3,1,1,2,1)` : `q₀=1`, `u₀=7→u₁=13→u₂=5`. Le déficit de deux corridors est `log₂(7/5)>0`.
- `(1,1,3,1,2)` : `q₀=197`, `393→295→499` et `D₂=log₂(393/499)<0`. Cette croissance est imposée sur toute la classe.

## 5. Critère de fidélité globale des prolongements

Supposons qu'un mot de corridors infini soit prescrit. À chaque profondeur `H`, les conditions fixent un résidu impair `ρ_H` de `q₀` modulo `M_H=2^S_H`, avec `M_H→∞`, et les classes sont emboîtées par réduction modulo les puissances précédentes.

**Proposition.** Il existe un **entier positif fixe `q₀`** appartenant à toutes ces classes si et seulement si la suite des représentants canoniques `ρ_H∈{1,3,...,M_H-1}` est **finalement constante** (en écartant les états terminaux qui rendraient le motif incompatible).

**Preuve.** Si `q₀` est fixe, dès que `M_H>q₀`, son résidu canonique est exactement `q₀`, donc `ρ_H=q₀`. Inversement, si `ρ_H=q` pour tout `H` assez grand, `q` satisfait toutes les congruences finies par compatibilité et réalise les longueurs imposées à chaque horizon.

Ce critère distingue de façon exacte une chaîne de préfixes réalisables par des entiers éventuellement différents d'une trajectoire issue d'un **même entier fixé**. Il ne prouve pas que les chaînes non terminales ont nécessairement leurs résidus croissants sans borne : démontrer cela serait une étape majeure liée directement à Syracuse.

## 6. Vérifications et limites

Le programme joint :

- vérifie les 32 768 cellules et un deuxième témoin dans chaque classe ;
- reproduit toutes les transitions de deux corridors au moyen de l'opérateur décimal Φ–Ψ en base 1000 ;
- vérifie les congruences sur les départs impairs de 3 à 99 999 ;
- certifie les signes du déficit par **arithmétique entière** et non avec des logarithmes flottants.

Nous n'avons démontré aucune convergence universelle : toutes les suites **finies** de réarmements demeurent possibles ; la difficulté est leur réalisation à profondeur illimitée par un entier fixe et l'éventuelle positivité du déficit.
