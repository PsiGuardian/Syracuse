#!/usr/bin/env python3
"""Matrice exacte de deux corridors consécutifs Phi-Psi.

Calculs entiers exacts, 5 parametres bornes r0,t0,r1,t1,r2.
Le choix r0,t0,r1,t1,r2 >=1 fixe une classe infinie de departs u0.
Aucune probabilite sur les trajectoires n'est supposee.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

LOG32=math.log2(1.5)
LOG103=math.log2(10/3)

def v2(n:int)->int:
    if n<=0:raise ValueError(n)
    return (n & -n).bit_length()-1

def U(n:int)->int:
    return (3*n+1)//2 if n&1 else n//2

def U_base1000(n:int)->int:
    assert n>0
    p=n&1
    lam=1+2*p
    x=n
    blocks=[]
    while x:
        blocks.append(x%1000); x//=1000
    blocks.append(0)
    mult=[]
    carry=p
    for block in blocks:
        z=lam*block+carry
        mult.append(z%1000)
        carry=z//1000
    assert carry==0
    rem=0
    out=0
    for block in reversed(mult):
        out=out*1000+(1000*rem+block)//2
        rem=block&1
    assert rem==0
    return out

def corr(n:int):
    assert n>1 and n&1
    r=v2(n+1)
    q=(n+1)>>r
    e=3**r*q-1
    t=v2(e)
    u=e>>t
    assert u&1
    return r,q,t,u,v2(u+1)

def residue_1(r,t,rp):
    modulus=1<<(t+rp+1)
    residue=(pow(3**r,-1,modulus)*(1-(1<<t)+(1<<(t+rp))))%modulus
    assert residue&1
    return residue,modulus

def residue_2(r0,t0,r1,t1,r2):
    q1_res,m1=residue_1(r1,t1,r2)
    modulus=1<<(t0+r1+t1+r2+1)
    numer=1-(1<<t0)+(1<<(t0+r1))*q1_res
    residue=(pow(3**r0,-1,modulus)*numer)%modulus
    assert residue&1
    initial_res,initial_mod=residue_1(r0,t0,r1)
    assert residue%initial_mod==initial_res
    return residue,modulus,q1_res,m1

def row(r0,t0,r1,t1,r2):
    q_res,M,q1_res,M1=residue_2(r0,t0,r1,t1,r2)
    q_min=q_res
    # Exclure les etats deja termines au nombre 1 dans les deux corridors.
    # La classe conserve une infinite de temoins apres cette exclusion.
    while (1<<r0)*q_min-1<=1 or (3**r0*q_min-1)//(1<<t0)<=1:
        q_min+=M
    u0=(1<<r0)*q_min-1
    assert u0>1
    rr0,qq0,tt0,u1,rr1=corr(u0)
    rr_1,qq1,tt1,u2,rr2=corr(u1)
    assert (rr0,qq0,tt0,rr1,rr_1,tt1,rr2)==(r0,q_min,t0,r1,r1,t1,r2)
    assert qq1%M1==q1_res
    rtotal=r0+r1
    h=r0+t0+r1+t1
    numerator=3**(r0+r1)*q_min-(3**r1)+(1<<t0)*(3**r1-2**r1)
    den=1<<(t0+r1+t1)
    assert numerator%den==0 and numerator//den==u2
    coefficient=(1<<h)-3**rtotal
    additive=(1<<(t0+r1))*((1<<t1)-1)+(3**r1)*((1<<t0)-1)
    assert additive>0
    assert (u2<u0)==(coefficient*q_min>additive)
    if coefficient<=0:
        kind='croissance_universelle'
        n_exceptions=-1
    elif coefficient*q_min>additive:
        kind='descente_universelle'
        n_exceptions=0
    else:
        kind='mixte_seuil'
        # q=q_res+kM, k>=0, exclure u=1.
        threshold=additive//coefficient
        # q<=threshold are non-descending
        first=q_min
        n_exceptions=max(0,(threshold-first)//M+1)
    delta=math.log2(u0/u2)
    J=lambda u: math.log2(u+1)+LOG32*v2(u+1)
    deltaJ=J(u2)-J(u0)
    # Dans chaque corridor, il y a r etats impairs successifs :
    # r-1 etats ont a=1 ; le dernier a=1+t. Donc la somme tronquee
    # sur *tous* les etats impairs du corridor est r+min(t,2).
    K=r0+r1
    Amin3=r0+r1+min(t0,2)+min(t1,2)
    dlow=Amin3-K*LOG103
    a0=v2(3*u0+1)
    a1=v2(3*u1+1)
    alpha0=min(3,a0);alpha1=min(3,a1)
    # Realisation sur le relèvement suivant, qui doit conserver tous les r,t.
    u0b=(1<<r0)*(q_min+M)-1
    ar,aq,at,au,arp=corr(u0b)
    br,bq,bt,bu,brp=corr(au)
    assert (ar,at,arp,br,bt,brp)==(r0,t0,r1,r1,t1,r2)
    return {
      'r0':r0,'t0':t0,'r1':r1,'t1':t1,'r2':r2,
      'q0_residu':q_res,'q0_modulo':M,'q0_min_u0_sup_1':q_min,
      'q0_residu_un_corridor':residue_1(r0,t0,r1)[0],
      'q0_modulo_un_corridor':residue_1(r0,t0,r1)[1],
      'q1_residu':q1_res,'q1_modulo':M1,
      'u0_min':u0,'u1_min':u1,'u2_min':u2,
      'mot_parite':f"{'I'*r0}{'P'*t0}{'I'*r1}{'P'*t1}{'I'*r2}P",
      'h_2corridors':h,'coefficient_contractant_2h_moins_3m':coefficient,
      'correction_positive':additive,'type_certificat':kind,
      'nombre_representants_non_descendants':n_exceptions,
      'descente_pour_temoin':int(u2<u0),
      'deficit_2corridors_min':f'{delta:.12f}',
      'delta_J_2corridors_min':f'{deltaJ:.12f}',
      'a0':a0,'a1':a1,'alpha3_u0':alpha0,'alpha3_u1':alpha1,
      'nombre_blocs_impair_impair':K,
      'budget_min_alpha3_ensemble_corridors':Amin3,
      'borne_deficit_pied_seul':f'{dlow:.12f}',
      'pied_certifie_deficit':int(dlow>0),
      'suffixe_u0':f'{u0%1000:03d}',
      'suffixe_u1':f'{u1%1000:03d}',
      'suffixe_u2':f'{u2%1000:03d}',
      'temoin_2':u0b,
    }

def independent_checks(rows, max_r):
    # reproduit les deux corridors par transitions unitaires U et blocs base1000
    for idx,row_ in enumerate(rows):
        n=int(row_['u0_min']);r0=int(row_['r0']);t0=int(row_['t0']);r1=int(row_['r1']);t1=int(row_['t1'])
        x=n
        for _ in range(r0+t0):
            assert U_base1000(x)==U(x)
            x=U(x)
        assert x==int(row_['u1_min'])
        for _ in range(r1+t1):
            assert U_base1000(x)==U(x)
            x=U(x)
        assert x==int(row_['u2_min'])
    # Verification exhaustive de 50 000 temoins impairs.
    for n in range(3,100001,2):
        r0,q0,t0,u1,r1=corr(n)
        if u1==1: continue  # trajet termine, exclu du second corridor non-terminal
        r_1,q1,t1,u2,r2=corr(u1)
        assert r_1==r1
        qres,M,q1res,M1=residue_2(r0,t0,r1,t1,r2)
        assert q0%M==qres and q1%M1==q1res
        assert u0_from_q(r0,q0)==n

def u0_from_q(r,q):return (1<<r)*q-1

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--max-r',type=int,default=8)
    ap.add_argument('--max-t',type=int,default=8)
    ap.add_argument('--sortie',default='/mnt/data')
    ap.add_argument('--verifier',action='store_true')
    args=ap.parse_args()
    dest=Path(args.sortie);dest.mkdir(parents=True,exist_ok=True)
    rows=[]
    for r0 in range(1,args.max_r+1):
      for t0 in range(1,args.max_t+1):
       for r1 in range(1,args.max_r+1):
        for t1 in range(1,args.max_t+1):
         for r2 in range(1,args.max_r+1):
          rows.append(row(r0,t0,r1,t1,r2))
    outfile=dest/'Syracuse_PhiPsi_Deux_Rearmements_Matrice.csv'
    with outfile.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0].keys()));writer.writeheader();writer.writerows(rows)
    if args.verifier:
        independent_checks(rows,args.max_r)
    counts=Counter(x['type_certificat'] for x in rows)
    growth=Counter()
    groups=defaultdict(Counter)
    samples=[]
    for x in rows:
        q1prev=int(x['q0_residu_un_corridor'])
        modprev=int(x['q0_modulo_un_corridor'])
        while (1<<int(x['r0']))*q1prev-1<=1 or (3**int(x['r0'])*q1prev-1)//(1<<int(x['t0']))<=1:
            q1prev+=modprev
        grew=int(x['q0_min_u0_sup_1'])>q1prev
        growth['valeur_min_augmentee' if grew else 'valeur_min_inchangee']+=1
        groups[(x['r0'],x['t0'],x['r1'])][x['type_certificat']]+=1
        if (x['r0'],x['t0'],x['r1'],x['t1'],x['r2']) in [
            (1,1,3,1,2),(2,1,5,1,3),(3,1,1,2,1),(1,1,1,1,1),
            (3,4,2,1,1),(2,1,2,2,2),(4,1,4,1,4)]:
            samples.append(x)
    pergroup=dest/'Syracuse_PhiPsi_Deux_Rearmements_Synthese_512.csv'
    with pergroup.open('w',newline='',encoding='utf-8') as f:
        fns=['r0','t0','r1','total_sous_classes','certif_descente','certif_croissance','seuil_mixte']
        w=csv.DictWriter(f,fieldnames=fns);w.writeheader()
        for (r0,t0,r1),c in sorted(groups.items()):
            w.writerow(dict(r0=r0,t0=t0,r1=r1,total_sous_classes=sum(c.values()),
              certif_descente=c['descente_universelle'],certif_croissance=c['croissance_universelle'],seuil_mixte=c['mixte_seuil']))
    fex=dest/'Syracuse_PhiPsi_Deux_Rearmements_Exemples.csv'
    with fex.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(samples)
    qmins=sorted(x['q0_min_u0_sup_1'] for x in rows)
    stats={
        'parametres':{'r0_t0_r1_t1_r2':f'1..{args.max_r}; 1..{args.max_t}; 1..{args.max_r}; 1..{args.max_t}; 1..{args.max_r}'},
        'nombre_motifs':len(rows),'nombre_motifs_realises':len(rows),
        'certificats':dict(counts),'croissance_plus_petit_temoin':dict(growth),
        'certificat_pied_seul':sum(x['pied_certifie_deficit'] for x in rows),
        'temoin_en_descente':sum(x['descente_pour_temoin'] for x in rows),
        'q0_min_mediane':qmins[len(qmins)//2],
        'q0_min_max':qmins[-1],
        'q0_min_quartile_1':qmins[len(qmins)//4],
        'q0_min_quartile_3':qmins[3*len(qmins)//4],
        'verifications_effectuees':args.verifier,
        'sorties':[outfile.name,pergroup.name,fex.name]}
    (dest/'Syracuse_PhiPsi_Deux_Rearmements_Resultats.json').write_text(json.dumps(stats,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(stats,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
