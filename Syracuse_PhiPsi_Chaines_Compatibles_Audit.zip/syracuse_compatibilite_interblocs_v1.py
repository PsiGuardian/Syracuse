#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Audit des chaines admissibles de cellules Phi-Psi en base 1000.
Utilise le CSV exact precedent. Ne constitue pas une preuve de Syracuse.
"""
from __future__ import annotations
import csv, json, random, math, zipfile
from collections import Counter, defaultdict
from pathlib import Path
ROOT=Path('/mnt/data')
SRC=ROOT/'Syracuse_PhiPsi_Blocs_000_999_Matrice_Complete_8000.csv'
PREFIX='Syracuse_PhiPsi_Chaines_Compatibles'

def valuation(x):
    assert x>0
    return (x&-x).bit_length()-1

def odd_step(n):
    assert n>0 and n%2==1
    a=valuation(3*n+1)
    return a,(3*n+1)//(1<<a)

def U(n): return n//2 if n%2==0 else (3*n+1)//2

def fmt(x,width=3):return str(x).zfill(width)

def write(filename,rows,keys):
    path=ROOT/filename
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=keys,delimiter=';')
        w.writeheader(); w.writerows(rows)
    return path

with SRC.open(encoding='utf-8-sig',newline='') as f:
    R=list(csv.DictReader(f,delimiter=';'))
assert len(R)==8000
index={}
for row in R:
    B=int(row['bloc_entree']);p=int(row['parite_globale'])
    c=int(row['retenue_entrante_droite']);r=int(row['reste_entrant_gauche'])
    k=(B,p,c,r)
    assert k not in index
    index[k]=row
    lam=1+2*p
    t=lam*B+c
    assert int(row['produit_local_lambda_B_plus_retenue'])==t
    assert int(row['retenue_sortante_gauche'])==t//1000
    assert int(row['reste_sortant_droite'])==(B+c)%2
    assert int(row['bloc_sortie_divise'])==((1000*r+t%1000)//2)

# Tableau des transferts de frontieres, sans perdre c et R.
counts=defaultdict(int)
for B,p,c,r in index:
    row=index[(B,p,c,r)]
    C=int(row['retenue_sortante_gauche']);RR=int(row['reste_sortant_droite'])
    counts[(p,c,r,C,RR)]+=1
rows_front=[dict(parite=p,retenue_droite_entrante=c,reste_gauche_entrant=r,
    retenue_gauche_sortante=C,reste_droite_sortant=RR,
    nombre_blocs_000_999=number)
    for (p,c,r,C,RR),number in sorted(counts.items())]
path_front=write(PREFIX+'_Transferts_Frontieres.csv',rows_front,list(rows_front[0]))
assert sum(counts.values())==8000

# Complete et verifie l'assemblage d'un bloc de pied et d'une tete d'un chiffre.
rows_pair=[]
for n in range(10000):
    b=n%1000;d=n//1000;p=n%2
    row_right=index[(b,p,p,0)] # r sera fixe ci-dessous
    C_right=int(row_right['retenue_sortante_gauche'])
    tleft=(1+2*p)*d+C_right
    C_top=tleft//1000
    r_top=C_top%2
    r_right=(tleft%1000)%2
    left=index[(d,p,C_right,r_top)]
    right=index[(b,p,p,r_right)]
    assert int(left['reste_sortant_droite'])==r_right
    assert int(right['retenue_sortante_gauche'])==C_right
    assert int(right['reste_sortant_droite'])==0
    Q_right=int(right['bloc_sortie_divise'])
    Q_left=int(left['bloc_sortie_divise'])
    out=C_top//2*1000000+1000*Q_left+Q_right
    assert out==U(n)
    dct=dict(nombre_initial=n,pied_000_999=fmt(b),tete_000_009=fmt(d),
             branche='I' if p else 'P',
             carry_pied_entrant=p,carry_pied_vers_tete=C_right,
             carry_tete_vers_exterieur=C_top,
             reste_tete_entrant=r_top,reste_tete_vers_pied=r_right,
             reste_pied_sortant=0,
             bloc_tete_sortie=fmt(Q_left),bloc_pied_sortie=fmt(Q_right),
             entier_apres_U=out,
             mode_tete=left['identifiant_mode'],mode_pied=right['identifiant_mode'])
    if n%2==1:
        a,v=odd_step(n)
        dct.update(a0_exact_representant=a,entier_impair_suivant=v,
                    a1_exact_representant=odd_step(v)[0],
                    alpha3=min(3,valuation(3*b+1)),
                    alpha4=min(4,valuation(3*n+1)))
    rows_pair.append(dct)
assert len(rows_pair)==10000
keys_pair=list(rows_pair[-1]);
path_pair=write(PREFIX+'_Raccords_10000.csv',rows_pair,keys_pair)

# 500 pieds impairs : garanties sur (a0,a1) dues uniquement a la fenetre de 3 chiffres.
rows_trip=[]
for b in range(1,1000,2):
    r8=b%8
    if r8==1:
        a0,a1='2','1, 2 ou >=3'; cert='oui (premier bloc pour u>1)'
    elif r8==3:
        a0,a1='1','2 ou >=3';cert='non, requiert un chiffre de gauche'
    elif r8==5:
        a0,a1='>=3','1, 2 ou >=3';cert='oui (premier bloc pour u>1)'
    else:
        a0,a1='1','1';cert='non, deux premieres profondeurs egales a 1'
    d_zero=(b%16)
    d_one=(b+1000)%16
    assert d_zero!=d_one
    def next_class(r16):
        return ('>=3' if r16==3 else '2' if r16==11 else '1' if r16 in (7,15) else 'inconnu sans extension')
    rows_trip.append(dict(pied=fmt(b),pied_modulo8=r8,pied_modulo16=b%16,
        alpha3=min(3,valuation(3*b+1)),a0_universel=a0,a1_universel=a1,
        classe_mod16_si_chiffre_gauche_pair=d_zero,
        classe_mod16_si_chiffre_gauche_impair=d_one,
        a1_si_gauche_pair_si_a0_1=next_class(d_zero) if r8 in (3,7) else '',
        a1_si_gauche_impair_si_a0_1=next_class(d_one) if r8 in (3,7) else '',
        garantie_descente=cert))
assert len(rows_trip)==500
path_trip=write(PREFIX+'_Pieds_500_Transferts_Dyadiques.csv',rows_trip,list(rows_trip[0]))

# 5000 suffixes impairs de 4 chiffres : certificats UNIVERSELS sur tous n congrus modulo 10000.
rows_suffix=[]
for r in range(1,10000,2):
    alpha3=min(3,valuation(3*(r%1000)+1))
    alpha4=min(4,valuation(3*r+1))
    if r%4==1:
        a0='>=2';a1='non necessaire'; first='1';proof='a0>=2 et (3n+1)/4 < n si n>1'
    else:
        a0='1'
        if r%16==3:
            a1='>=3'; first='2'; proof='a0=1, a1>=3; somme a>=4'
        elif r%16==11:
            a1='2'; first='non garanti';proof='a0=1, a1=2; pas de descente dans 2 blocs'
        elif r%16 in (7,15):
            a1='1'; first='non garanti';proof='a0=a1=1; croissance pendant 2 blocs'
        else:raise AssertionError(r)
    rows_suffix.append(dict(suffixe_4_chiffres=fmt(r,4),residu_modulo8=r%8,
        residu_modulo16=r%16,alpha3=alpha3,alpha4=alpha4,
        a0_garanti=a0,a1_garanti=a1,certifie_descente_au_plus_2_blocs=first,
        demonstration=proof))
path_suffix=write(PREFIX+'_Suffixes_5000_Certificats.csv',rows_suffix,list(rows_suffix[0]))
assert sum(x['certifie_descente_au_plus_2_blocs']!='non garanti' for x in rows_suffix)==3125

# Reconstructor generique pour le test base1000, en consultant les 8000 lignes.
def reconstruct(n):
    assert n>=0
    p=n&1
    blocks=[];m=n
    if m==0: blocks=[0]
    while m:
        m,b=divmod(m,1000);blocks.append(b)
    cin=p; shifted=[]
    for b in blocks:
        row=index[(b,p,cin,0)]
        shifted.append((b,cin,int(row['retenue_sortante_gauche'])))
        cin=int(row['retenue_sortante_gauche'])
    lead=cin//2;rem=cin%2;ans=lead*1000**len(blocks)
    for i in range(len(blocks)-1,-1,-1):
        b,cin,_=shifted[i]
        row=index[(b,p,cin,rem)]
        ans+=int(row['bloc_sortie_divise'])*1000**i
        rem=int(row['reste_sortant_droite'])
    assert rem==0
    return ans
rng=random.Random(5382026)
for n in list(range(1,40000))+[2**69-1,4984461,4512,4461,5461,10**30+341]:
    assert reconstruct(n)==U(n)
for digits in (6,9,12,21,30,60,100,150):
    for i in range(1000):
        n=rng.randrange(10**(digits-1),10**digits)
        assert reconstruct(n)==U(n)
# Les suffixes de quatre chiffres sont des classes modulo 2^4, donc la table donne
# la meme certification pour n=r+10000*t, independamment de la tete.
for _ in range(20000):
    rec=rows_suffix[rng.randrange(len(rows_suffix))]
    r=int(rec['suffixe_4_chiffres']); n=r+10000*rng.randrange(0,10**12)
    if n<=1:continue
    a,v=odd_step(n)
    if rec['a0_garanti']=='1':assert a==1
    if rec['a0_garanti']=='1' and rec['a1_garanti']!='non necessaire':
        a1,_=odd_step(v)
        if rec['a1_garanti']=='1':assert a1==1
        if rec['a1_garanti']=='2':assert a1==2
        if rec['a1_garanti']=='>=3':assert a1>=3
    if rec['certifie_descente_au_plus_2_blocs']=='1':assert v<n
    if rec['certifie_descente_au_plus_2_blocs']=='2':
        a1,v2=odd_step(v)
        assert v2<n

summary={
 'source_csv_lignes':len(R),
 'comptage_transferts_frontieres_groupes':len(rows_front),
 'assemblages_deux_blocs_testes':len(rows_pair),
 'fenetres_pied_impaires':len(rows_trip),
 'suffixes_quatre_chiffres_impairs':len(rows_suffix),
 'classes_4_chiffres_certifiees_au_plus_2_blocs':3125,
 'classes_4_chiffres_non_certifiees_2_blocs':1875,
 'reconstitutions_multiblocs_independantes_verifiees':39999+6+8*1000,
 'verifications_classes_alongements':20000,
 'distribution_blocs_pied_mod8':dict(sorted(Counter(x['pied_modulo8'] for x in rows_trip).items())),
 'correspondance_deux_blocs':{
  '4461': {'U':U(4461), 'a0':odd_step(4461)[0], 'prochain_impair':odd_step(4461)[1]},
  '5461': {'U':U(5461), 'a0':odd_step(5461)[0], 'prochain_impair':odd_step(5461)[1]},
  '4984461':{'U':U(4984461), 'a0':odd_step(4984461)[0]}
 },
 'resultat_logique':'Toutes les suites finies de profondeurs a_j positives restent realisables par une classe positive modulo une puissance de 2, conformement a la proposition 5.46. Le graphe n impose pas la descente universelle.'
}
path_sum=ROOT/(PREFIX+'_Synthese.json')
path_sum.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
notice=f'''# Chaînes compatibles Φ–Ψ : audit des deux frontières

Sources : `{SRC.name}` (8 000 cellules), manuscrit v12 § 27.

## Orientation exacte
Pour un bloc `B` de trois chiffres, p global et retenue reçue à droite `c` :

    T = (1 + 2p) B + c
    C = floor(T/1000)             retenue émise vers la gauche
    R = T mod 2 = (B+c) mod 2    reste émis vers la droite
    Q = floor((1000 r + (T mod 1000))/2), r reste reçu de la gauche.

Pour deux blocs adjacents A (gauche) et B (droite) :

    c_A=C_B ; r_B=R_A.

Le transfert se calcule sans ambiguïté : retenues de droite à gauche,
puis restes de gauche à droite. Au pied, c=p. Au sommet, r=C_sommet mod 2.
Toutes les entrées de la matrice ne sont pas indépendamment réalisables.

## Première contrainte entre deux profondeurs impaires
Soit u>1 impair, a0=nu2(3u+1), v=(3u+1)/2^a0, a1=nu2(3v+1).
Le suffixe de trois chiffres fixe u mod 8 :

| u mod 8 | a0 garanti | a1 garanti | certifie u1<u0 ? |
| --- | --- | --- | --- |
| 1 | 2 | 1,2 ou >=3 | oui |
| 3 | 1 | >=2 | non, affiner modulo 16 |
| 5 | >=3 | 1,2 ou >=3 | oui |
| 7 | 1 | 1 | non, deux montées |

Lorsque u mod 16 = 3, a0=1 puis a1>=3 et le deuxième impair est inférieur à u.
Lorsque u mod 16 = 11, a0=1 puis a1=2, et le deuxième impair est supérieur à u.
Lorsque u mod 16 = 7 ou 15, a0=a1=1, et les deux blocs augmentent u.
Les résidus modulo 16 se déterminent avec quatre chiffres décimaux terminaux.

## Limite
La matrice définit les transitions individuelles exactement et permet des
certificats à horizon fini. Elle ne rend pas impossible une suite finie arbitraire
de profondeurs positives : les incompatibilités artificielles entre modes
ne constituent pas un nouvel invariant de descente.

## Fichiers
* `{path_front.name}` : effectifs des transformations des drapeaux de frontière.
* `{path_pair.name}` : 10 000 montages exacts avec un triplet et un chiffre de gauche.
* `{path_trip.name}` : les 500 triplets de pied impairs et leur classification universelle.
* `{path_suffix.name}` : 5 000 classes de suffixes impairs sur quatre chiffres.
* `{path_sum.name}` : synthèse des vérifications.
* `{Path(__file__).name}` : programme reproductible.
'''
path_notice=ROOT/(PREFIX+'_LISEZMOI.md')
path_notice.write_text(notice,encoding='utf8')
zip_path=ROOT/(PREFIX+'_Audit.zip')
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for p in [SRC,path_front,path_pair,path_trip,path_suffix,path_sum,path_notice,Path(__file__)]:
        z.write(p,arcname=p.name)
print(json.dumps(summary,ensure_ascii=False,indent=2))
print('FICHIERS',*[str(p) for p in [path_front,path_pair,path_trip,path_suffix,path_sum,path_notice,zip_path]],sep='\n')
