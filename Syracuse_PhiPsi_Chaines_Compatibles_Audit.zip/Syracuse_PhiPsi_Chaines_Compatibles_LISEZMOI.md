# Chaînes compatibles Φ–Ψ : audit des deux frontières

Sources : `Syracuse_PhiPsi_Blocs_000_999_Matrice_Complete_8000.csv` (8 000 cellules), manuscrit v12 § 27.

## Orientation exacte
Pour un bloc `B` de trois chiffres, p global et retenue reçue à droite `c` :

    T = (1 + 2p) B + c
    C = floor(T/1000)             retenue émise vers la gauche
    R = T mod 2 = (B+c) mod 2    reste émis vers la droite
    Q = floor((1000 r + (T mod 1000))/2), r reste reçu de la gauche.

Pour deux blocs adjacents A (gauche) et B (droite) :

    c_A=C_B ; r_B=R_A.

Le transfert se calcule sans ambiguïté : retenues de droite à gauche,
puis restes de gauche à droite. Au pied, c=p. Au sommet, r=C_sommet mod 2.
Toutes les entrées de la matrice ne sont pas indépendamment réalisables.

## Première contrainte entre deux profondeurs impaires
Soit u>1 impair, a0=nu2(3u+1), v=(3u+1)/2^a0, a1=nu2(3v+1).
Le suffixe de trois chiffres fixe u mod 8 :

| u mod 8 | a0 garanti | a1 garanti | certifie u1<u0 ? |
| --- | --- | --- | --- |
| 1 | 2 | 1,2 ou >=3 | oui |
| 3 | 1 | >=2 | non, affiner modulo 16 |
| 5 | >=3 | 1,2 ou >=3 | oui |
| 7 | 1 | 1 | non, deux montées |

Lorsque u mod 16 = 3, a0=1 puis a1>=3 et le deuxième impair est inférieur à u.
Lorsque u mod 16 = 11, a0=1 puis a1=2, et le deuxième impair est supérieur à u.
Lorsque u mod 16 = 7 ou 15, a0=a1=1, et les deux blocs augmentent u.
Les résidus modulo 16 se déterminent avec quatre chiffres décimaux terminaux.

## Limite
La matrice définit les transitions individuelles exactement et permet des
certificats à horizon fini. Elle ne rend pas impossible une suite finie arbitraire
de profondeurs positives : les incompatibilités artificielles entre modes
ne constituent pas un nouvel invariant de descente.

## Fichiers
* `Syracuse_PhiPsi_Chaines_Compatibles_Transferts_Frontieres.csv` : effectifs des transformations des drapeaux de frontière.
* `Syracuse_PhiPsi_Chaines_Compatibles_Raccords_10000.csv` : 10 000 montages exacts avec un triplet et un chiffre de gauche.
* `Syracuse_PhiPsi_Chaines_Compatibles_Pieds_500_Transferts_Dyadiques.csv` : les 500 triplets de pied impairs et leur classification universelle.
* `Syracuse_PhiPsi_Chaines_Compatibles_Suffixes_5000_Certificats.csv` : 5 000 classes de suffixes impairs sur quatre chiffres.
* `Syracuse_PhiPsi_Chaines_Compatibles_Synthese.json` : synthèse des vérifications.
* `syracuse_compatibilite_interblocs_v1.py` : programme reproductible.

## Adjacences de deux cellules

- `Syracuse_PhiPsi_Chaines_Compatibles_Paires_Modes_Internes_40.csv` : **40 couples de modes** distincts possibles à l'intérieur d'un nombre, pondérés par 8 000 000 configurations de deux blocs de valeurs et de frontières libres. Les modes des deux blocs doivent partager la même parité globale.
- `Syracuse_PhiPsi_Chaines_Compatibles_Paires_Modes_Tete_Pied_14.csv` : **14 couples de modes** distincts pour les 1 000 000 entiers formés de deux blocs complets (zéros de tête admis), parce que la retenue du pied vaut p et que le reste au sommet est imposé.
- Les dénombrements ci-dessus concernent les cellules **disjointes de base 1000**. Les triplets **chevauchants** du lemme 5.38 se recollent sur deux chiffres communs, et leur projection utilise une autre représentation. Ces deux mécanismes sont exacts mais ne doivent pas être confondus.
