# Syracuse Φ–Ψ — Opérateur de prolongement temporel (v14)

**Auteur du manuscrit :** Andrew Caron. **Étude et implémentation :** 16 novembre 2026.

## Objectif et définition

Nous suivons le bloc cible `BBB` en position `i>=1` en base 1000 et ses modes `(B,p,c,r)` : `B` bloc de 0 à 999, `p` parité globale, `c` retenue entrante depuis la droite et `r` reste entrant depuis la gauche.

```
L = 1000**i
p = n % 2
lam = 1 + 2*p
B = (n // L) % 1000
c = (lam * (n % L) + p) // L
r = ((lam*n + p) // (1000*L)) % 2
U(n) = n//2 si n pair ; (3*n+1)//2 si n impair
```

Pour les modes des instants `0,...,H`, les classes de résidus modulo

```
M_H = 2**(H+1) * 1000**(i+1)
```

sont suffisantes. Le prolongement exact d'une classe `x mod M_H` est l'union des deux classes `x mod (2*M_H)` et `(x+M_H) mod (2*M_H)` : on calcule le nouveau mode sur les deux classes **en conservant la même origine**. Aucun raccordement purement graphique n'est admis comme trajectoire.

## Compression exacte en rubans arithmétiques

Au lieu de parcourir tous les nombres, le programme groupe les résidus initiaux sous la forme `k*L+s`, où `s` parcourt une progression arithmétique dans un intervalle et où le mot temporel complet des modes est constant. À l'étage suivant, le ruban est scindé selon le nouveau bit résiduel, le quotient est relevé et les seuils de changement de bloc, de retenue et de reste sont calculés **exactement par arithmétique entière**.

Chaque rubrique de sortie `niveau_Hx_modes.csv` donne un mot projeté, le nombre exact de résidus initiaux compatibles et un témoin positif ; elle ne doit pas être interprétée comme un ensemble de transitions librement composables.

## Vérifications exhaustives — un bloc à droite (i=1)

| Dernier rang H des modes | Résidus modulo | Mots de modes distincts | Résidus avec descente certifiée au plus au rang H+1 | Budget impair–impair alpha3 positif |
|---:|---:|---:|---:|---:|
| 0 | 2 000 000 | 8 000 | 1 000 000 | 0 |
| 1 | 4 000 000 | 48 000 | 3 000 000 | 0 |
| 2 | 8 000 000 | 256 000 | 6 000 000 | 1 000 000 |
| 3 | 16 000 000 | 1 276 000 | 13 000 000 | 3 000 000 |

Les deux dernières colonnes mesurent des propriétés distinctes et ne sont pas additives. Une classe certifiée l'est pour tous ses éléments positifs supérieurs à 1. La vérification de descente repose sur le signe de `(2**h-3**m)*n-B` et non sur le coefficient multiplicatif seul.

L'assemblage naïf des arcs propose 288 000 chaînes de trois modes, alors que seules 256 000 sont réelles : 32 000 exclusions. À quatre modes, l'assemblage naïf de triplets propose 1 376 000 chaînes, contre 1 276 000 réelles : 100 000 exclusions. Parmi les 256 000 chaînes de trois modes, 130 000 ont exactement quatre modes successeurs et 126 000 exactement six.

Les 16 mots de parité de longueur quatre sont tous réalisés, avec exactement un million de classes résiduelles chacun. Ce sont les conditions de frontière des modes projetés, **et non les mots de parité seuls**, qui éliminent les 100 000 assemblages artificiels.

## Programme autonome (Python standard, sans pip)

```bash
python3 syracuse_phi_psi_operateur_prolongement.py --verifier --droite 1 --horizon 2 --sortie resultats_locaux
python3 syracuse_phi_psi_operateur_prolongement.py --droite 1 --horizon 3 --sortie resultats_quatre_motifs
python3 syracuse_phi_psi_operateur_prolongement.py --horizon -1 --nombre 39 --blocs-impairs 5
python3 syracuse_phi_psi_operateur_prolongement.py --droite 5 --horizon 2 --sortie resultats_5_blocs
```

**Coût mesuré :** l'horizon 3 à `i=1` a nécessité environ 650 Mo de mémoire au pic ; les horizons supérieurs peuvent croître fortement. Il n'existe pas de limite mathématique fixe à `H`, mais un calcul exhaustif arbitrairement profond n'est pas garanti praticable sur une machine de capacité finie.

## Déficit et certification

Sur un mot de parité fixé, `U**h(n)=(3**m*n+B_h)/2**h`. Le programme calcule le seuil **entier** de descente pour toutes les classes initiales. Les états impairs successifs aux rangs `t_j` et `t_(j+1)` imposent une profondeur dyadique `a_j=t_(j+1)-t_j`. Le certificat inférieur par triplets utilise `alpha_j=min(3,a_j)` et

```
somme(alpha_j) - K*log2(10/3) > 0
```

Son signe est décidé sans flottants en vérifiant `2**sum(alpha_j) * 3**K > 10**K`.

La méthode ne prouve **ni** que tous les mots ouverts sont finalement compensés **ni** la convergence universelle de Syracuse. Chaque résultat est à horizon fini ; un prolongement infini de classes de résidus peut ne pas représenter un même entier positif fixe.

## Contenu des fichiers

- `Syracuse_PhiPsi_Manuscrit_Complet_v14.pdf` — manuscrit original (22 pages) et complément révisé.
- `Syracuse_PhiPsi_Complement_v14.pdf` et `Syracuse_PhiPsi_Theoremes_v14.tex` — complément scientifique avec section 29.
- `Syracuse_PhiPsi_Theoreme_5_49_50.pdf/.tex` — théorème et corollaire autonomes.
- `syracuse_phi_psi_operateur_prolongement.py` — opérateur et tests.
- `niveau_H0` à `niveau_H3` : listes de mots projetés, témoins et multiplicité exacte, plus mots de parité.
- `Syracuse_PhiPsi_Prolongement_Chemins_4modes_Interdits_100000.csv` — compositions de triplets impossibles.
- `Syracuse_PhiPsi_Operateur_Prolongement_Degres_3vers4.csv` — degré de prolongement des 256 000 chaînes à trois modes.
- `resultats.json` — synthèse machine des tests.
