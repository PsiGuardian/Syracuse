#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Syracuse Phi-Psi: OPERATEUR EXACT DE PROLONGEMENT TEMPOREL.

Un objet Bande représente une famille exacte de résidus initiaux n modulo
M_h=2**(h+1) * 1000**(i+1) avec modes identiques aux instants 0,...,h.
La famille des résidus dans [0,M_h) est n=k*L+s, s dans [debut,fin),
s = d (mod q), L=1000**i, q=2**(h+1).

Le prolongement ne compose jamais arbitrairement deux arcs:
  (1) chaque résidu est relevé aux deux classes r et r+M_h;
  (2) la classe d'un suffixe s (mod q) est scindée en s mod 2q;
  (3) les frontières de mode sont identifiées par seuils entiers exacts;
  (4) l'opérateur U est réappliqué au MEME entier initial.

Aucune dépendance externe, entiers de précision arbitraire.
"""
from __future__ import annotations
from dataclasses import dataclass
from collections import Counter,defaultdict
from pathlib import Path
import argparse, csv, json, random, math, time

BASE=1000

def U(n: int) -> int:
    if n<0: raise ValueError('n doit etre >=0')
    return (3*n+1)//2 if n&1 else n//2

def mode(n: int, L: int) -> int:
    p=n&1
    lam=1+2*p
    B=(n//L)%BASE
    c=(lam*(n%L)+p)//L
    r=((lam*n+p)//(BASE*L))&1
    assert ((p==0 and c==0) or (p==1 and 0<=c<=2))
    return 8*B+(0 if p==0 else 2+2*c)+r

def decode_mode(z:int)->tuple[int,int,int,int]:
    B,w=divmod(z,8)
    if w<2:return B,0,0,w
    return B,1,(w-2)//2,(w-2)&1

def ceil_div(x:int,y:int)->int:
    return -((-x)//y)

@dataclass(frozen=True,slots=True)
class Bande:
    k: int
    d: int
    debut: int
    fin: int
    modes: tuple[int,...]
    # invariant: s%q = d, s in [debut,fin), 0<=s<L

    def effectif(self,q:int)->int:
        return (self.fin-1-self.debut)//q+1


def affine_parites(p:tuple[int,...])->list[tuple[int,int]]:
    """U^t(n)=(A_t n + D_t)/2^t, t=0..len(p)."""
    out=[(1,0)]
    for t,par in enumerate(p):
        A,D=out[-1]
        out.append(((3*A if par else A),(3*D+(1<<t) if par else D)))
    return out


def splitter_mode(k:int,d:int,q:int,L:int,h:int,A:int,D:int,p:int,
                  debut:int,fin:int, modes:tuple[int,...]):
    """Scinde un ruban sur les seuils EXACTS du mode S_i(U^h(n)).

    Sur le ruban, la parite p_h et l'application affine U^h sont fixes.
    Aucun passage par une approximation en virgule flottante.
    """
    assert debut<fin and debut%q==d and 0<=d<q
    nbase=k*L
    first=debut
    last=debut+q*((fin-1-debut)//q)
    denom=1<<h
    ymin=(A*(nbase+first)+D)//denom
    ymax=(A*(nbase+last)+D)//denom
    candidates={first}

    def add_threshold(numer:int,denom_x:int):
        # 1er s dans le reseau s≡d mod q tel que U^h(s) >= seuil
        raw=ceil_div(numer,denom_x)
        start=debut+q*max(0,ceil_div(raw-debut,q))
        if start<fin:
            candidates.add(start)

    # Changements de bloc et de retenue (en fonction de U^h(n)).
    for j in range(ymin//L-1,ymax//L+3):
        threshold_list=[j*L]
        if p:
            threshold_list += [j*L+ceil_div(L-1,3), j*L+ceil_div(2*L-1,3)]
        for v in threshold_list:
            add_threshold(denom*v-A*nbase-D,A)

    # Changement du reste de la division: 
    # r = floor(U^{h+1}(n)/(500 L)) mod 2
    lam=1+2*p
    A1=lam*A
    D1=lam*D+p*denom
    den1=denom*2
    zmin=(A1*(nbase+first)+D1)//den1
    zmax=(A1*(nbase+last)+D1)//den1
    T=500*L
    for j in range(zmin//T-1,zmax//T+3):
        add_threshold(den1*j*T-A1*nbase-D1,A1)

    points=sorted(candidates)
    out=[]
    for z,st in enumerate(points):
        en=points[z+1] if z+1<len(points) else fin
        mm=mode(U_iter_affine(nbase+st,A,D,h),L)
        out.append(Bande(k,d,st,en,modes+(mm,)))
    return out

def U_iter_affine(n:int,A:int,D:int,h:int)->int:
    return (A*n+D)//(1<<h)


def initial(i:int):
    if i<1:raise ValueError('i >=1')
    L=BASE**i
    q=2
    for k in range(2*BASE):
        for d in range(min(q,L)):
            yield from splitter_mode(k,d,q,L,0,1,0,d,d,L,())


def prolonger(b:Bande,h:int,i:int):
    """Bande h => bandes h+1. Aucun melange de residus distincts.
    Retourne les 2 relevements de k et les deux classes s modulo 2q.
    """
    L=BASE**i
    q=1<<(h+1)
    nq=q*2
    # La bande h contient h+1 parites aux rangs 0..h.
    # Le dernier couple affine est donc deja U^(h+1), sans nouvelle mise a jour.
    A1,D1=affine_parites(tuple(decode_mode(m)[1] for m in b.modes))[-1]
    for lift in (0,BASE*q):
        k2=b.k+lift
        for d2 in (b.d,b.d+q):
            first=b.debut+((d2-b.debut)%nq)
            if first>=b.fin:continue
            yield from splitter_mode(k2,d2,nq,L,h+1,A1,D1,
                                      U_iter_affine(k2*L+first,A1,D1,h+1)&1,
                                      first,b.fin,b.modes)


def iter_niveau(i:int,h:int):
    """Generate complete exact partition at time h; expensive in h."""
    if h<0:raise ValueError('h>=0')
    cur=initial(i)
    for t in range(h):
        # For streaming recursion, avoid materializing entire previous level.
        def rec(it,t=t):
            for b in it:
                yield from prolonger(b,t,i)
        cur=rec(cur)
    yield from cur


def seuil_premiere_descente(parites: tuple[int,...]) -> int|None:
    """Seuil EXACT T: tout n>=T ayant ce mot de parite descend
    a un rang <= len(parites), en utilisant l'identite affine.
    Si aucun facteur 2**t>3**m_t, retourne None.
    Pour les petits n<T, verifier au cas par cas; aucun statut global
    n'est deduit uniquement du signe du facteur multiplicatif.
    """
    seuil=[]
    for h,(a,d) in enumerate(affine_parites(parites)[1:],1):
        coeff=(1<<h)-a
        if coeff>0:
            seuil.append(d//coeff+1)
    return min(seuil) if seuil else None


def certificat_odd_alpha3(parites:tuple[int,...]) -> tuple[bool,int,int,int]:
    """Budget de deficit sur les blocs impair->impair TERMINES.
    Par construction, les positions des deux portes impaires consecutives
    donnent la profondeur complete a. Pour la garantie uniforme on utilise
    alpha3=min(3,a), et u_j>=3 jusqu a la premiere arrivee a 1.
    Retour: (positif, K, A_min, total_A_exact), en se limitant a u0 impair.
    """
    if not parites or parites[0]!=1:
        return False,0,0,0
    positions=[j for j,p in enumerate(parites) if p]
    if len(positions)<2:return False,0,0,0
    depths=[positions[j+1]-positions[j] for j in range(len(positions)-1)]
    A=0;Amin=0
    for k,a in enumerate(depths,1):
        A+=a;Amin+=min(a,3)
        if (1<<Amin)*(3**k)>10**k:
            return True,k,Amin,A
    return False,len(depths),Amin,A


def compte_certifie_bande(b:Bande,q:int,M:int,L:int,
                           seuil:int|None)->int:
    """Compte exactement les classes r mod M dont TOUS les representants
    positifs sont descendants avant le rang garanti par le mot de parite.
    L exception n=1 est exclue; les representants positifs >1 de cette
    classe peuvent etre certifies par la meme identite affine.
    """
    if seuil is None:return 0
    nb=b.effectif(q)
    n0=b.k*L+b.debut
    # Pour r>0, le representant minimal positif est r.
    start=max(0,ceil_div(seuil-n0,q))
    count=max(0,nb-start)
    # Cas residu n=0: son plus petit representant positif est M.
    if n0==0 and (seuil>0) and M>=seuil:
        count+=1
    # Cas residu n=1: n=1 est un point fixe sous U^2; on ne le compte
    # pas comme descendant, meme si les autres membres de la classe le sont.
    # Ici l affinement par les seuils peut exclure le residu 1; le nombre
    # de classes toutes certifiees pour n>1 est donne avec cette exception.
    if n0<=1 and (1-n0)%q==0:
        j=(1-n0)//q
        if 0<=j<nb and n0+j*q<seuil:
            # Si la classe r=1 est sur une branche contractante, la forme
            # affine est descendante pour 1+M > seuil en precision finie.
            if 1+M>=seuil:count+=1
    return count


def resume(i:int,max_h:int,sortie:Path,example_cap:int=50):
    L=BASE**i
    sortie.mkdir(parents=True,exist_ok=True)
    report=[]
    last_paths=set()
    last_edges=set()
    for h in range(max_h+1):
        t0=time.perf_counter()
        q=1<<(h+1)
        M=q*BASE*L
        counts=Counter()
        mins={}
        bands_count=0
        effectif=0
        certified_residues=0
        certified_bands=0
        n_with_odd_budget=0
        words=Counter()
        path_example={}
        # coefficients de 'mots' pour sauver fichiers.
        for b in iter_niveau(i,h):
            bands_count+=1
            c=b.effectif(q)
            effectif+=c
            counts[b.modes]+=c
            n0=b.k*L+b.debut
            if n0==0:
                n0=n0+q if c>=2 else M
            if b.modes not in mins or n0<mins[b.modes]:
                mins[b.modes]=n0
            if b.modes not in path_example:
                path_example[b.modes]=n0
            par=tuple(decode_mode(z)[1] for z in b.modes)
            words[''.join('I' if v else 'P' for v in par)]+=c
            # Certificat EXACT pour toutes les classes dont le representant
            # minimal satisfait l inegalite affine; groupes scindes par seuil.
            seuil=seuil_premiere_descente(par)
            certified_residues+=compte_certifie_bande(b,q,M,L,seuil)
            if seuil is not None:
                certified_bands+=1
            if certificat_odd_alpha3(par)[0]:
                n_with_odd_budget+=c
        assert effectif==M,(h,effectif,M)
        paths=set(counts)
        # memory caution: for h>2 we may not want keep sets of all paths
        print('H=',h,'bands=',bands_count,'paths=',len(paths),'classes=',M,
              'classes_certifiees=',certified_residues,'temps=',round(time.perf_counter()-t0,1),flush=True)
        data={
          'h':h,'i':i,'nb_classes_modulaires':M,'modulo':M,
          'rubans_symboliques':bands_count,
          'chaines_modes_distinctes':len(paths),
          'residus_couverts':effectif,
          'residus_avec_descente_universelle_certifiee_hors_1':certified_residues,
          'residus_avec_budget_alpha3_positif':n_with_odd_budget,
          'remarque_certification':'Exact par seuil affine: une classe residuelle r mod M compte si tous ses membres positifs autres que 1 ont une descente prouvee sous leur depart.',
          'nombre_mots_parite':len(words),
          'duree_secondes':round(time.perf_counter()-t0,2),
        }
        if h>=1:
            edges={tuple(x[:h]) for x in paths}
            data['prefixes_h_precedent_retrouves']=len(edges)
            data['prefixes_h_precedent_manquants']=len(last_paths-edges) if last_paths else 0
            # not exact naive comp metric except for h2 below
        if h==2:
            ab={(x[0],x[1]) for x in paths}
            bc={(x[1],x[2]) for x in paths}
            pred=Counter(y for x,y in ab)
            succ=Counter(x for x,y in bc)
            predicted=sum(pred[mid]*succ[mid] for mid in pred)
            data.update(arcs_temporaux=len(ab),compositions_paires_predictives=predicted,
                        compositions_irrealisables=predicted-len(paths))
        report.append(data)
        with (sortie/f'niveau_H{h}_mots_parite.csv').open('w',encoding='utf-8',newline='') as f:
            w=csv.writer(f,delimiter=';');w.writerow(['mot_parite','nb_classes_residuelles'])
            w.writerows(sorted(words.items()))
        with (sortie/f'niveau_H{h}_modes.csv').open('w',encoding='utf-8',newline='') as f:
            w=csv.writer(f,delimiter=';');w.writerow(['mode_ids','nombre_residus','temoin_positif','parites'])
            for modes,nc in sorted(counts.items()):
                w.writerow([','.join(map(str,modes)),nc,path_example[modes],
                            ''.join('I' if decode_mode(x)[1] else 'P' for x in modes)])
        last_paths=paths
    with (sortie/'resultats.json').open('w',encoding='utf-8') as f:
        json.dump(report,f,ensure_ascii=False,indent=2)
    return report


def depth_odd(u:int)->int:
    if u<=0 or u%2==0:raise ValueError('u impair strictement positif')
    m=3*u+1
    return (m&-m).bit_length()-1


def deficit_blocks(u:int, max_k:int):
    if u<=1 or not(u&1):raise ValueError('u impair >1')
    out=[];initial=u;sumalpha=0;A=0
    for j in range(max_k):
        if u==1:break
        a=depth_odd(u)
        v=(3*u+1)//(1<<a)
        alpha=min(a,3)
        sumalpha+=alpha;A+=a
        # Conditions exactes: deficit positive <=> v<initial.
        # For partial bound, avoid floats to decide: 2^sumalpha *3^K > 10^K
        k=j+1
        low_cert=(1<<sumalpha)*(3**k)>(10**k)
        out.append(dict(j=j,u=u,triplet=str(u%1000).zfill(3),a=a,
                        alpha3=alpha,u_suivant=v,A_K=A,Amin_K=sumalpha,
                        deficit_exact_signe='positif' if v<initial else ('nul' if v==initial else 'negatif'),
                        certificat_alpha3_positif=low_cert))
        u=v
    return out


def tests(i:int=1):
    import secrets
    L=BASE**i
    # verify that moving each congruence class by M preserves prefix modes
    for h in range(5):
        M=(1<<(h+1))*BASE*L
        rng=random.Random(h+222)
        for _ in range(5000):
            r=rng.randrange(0,M)
            n=r+M*(1+rng.randrange(1,500))
            a=r;b=n
            for t in range(h+1):
                assert mode(a,L)==mode(b,L)
                a=U(a);b=U(b)
    # Compare exact mode outputs with independent previous enumerations
    for h,expected in [(0,8000),(1,48000),(2,256000)]:
        counts=Counter()
        sumcount=0
        for band in iter_niveau(i,h):
            q=1<<(h+1)
            cnt=band.effectif(q)
            sumcount+=cnt
            counts[band.modes]+=cnt
            for off in (0,cnt//2,cnt-1):
                rr=band.k*L+band.debut+off*q
                c=rr
                for mm in band.modes:
                    assert mm==mode(c,L),(h,rr,mm,mode(c,L))
                    c=U(c)
        assert len(counts)==expected,(h,len(counts),expected)
        assert sumcount==(1<<(h+1))*BASE*L,(h,sumcount)
    for n in (3,7,15,39,101,4461,5461,4984461,357913941):
        if n&1 and n>1:
            rows=deficit_blocks(n,10)
            for r in rows:
                if r['certificat_alpha3_positif']:
                    assert r['deficit_exact_signe']=='positif'
    print('Tous les tests passes.',flush=True)


def main():
    ap=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument('--droite',type=int,default=1)
    ap.add_argument('--horizon',type=int,default=2,help='H transitions; produit des modes aux instants 0..H')
    ap.add_argument('--sortie',type=Path,default=Path('resultats_phi_psi'))
    ap.add_argument('--verifier',action='store_true')
    ap.add_argument('--nombre',type=int,default=None)
    ap.add_argument('--blocs-impairs',type=int,default=10)
    args=ap.parse_args()
    if args.verifier:tests(args.droite)
    if args.nombre is not None:
        print(json.dumps(deficit_blocks(args.nombre,args.blocs_impairs),ensure_ascii=False,indent=2))
    if args.horizon>=0:
        resume(args.droite,args.horizon,args.sortie)

if __name__=='__main__':main()
