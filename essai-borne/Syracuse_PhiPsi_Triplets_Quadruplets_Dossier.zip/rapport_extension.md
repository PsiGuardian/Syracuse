# Syracuse Φ–Ψ — Triplets et quadruplets de mots de première création de tête

**Étude au 18 novembre 2026.** Base : données des 21 trajectoires records, 230 mots, opérateur classique `I(n)=3n+1` / `P(n)=n/2`, lemmes S1–S12. Il ne s'agit pas d'une preuve de Syracuse.

## Portée et méthode

Une *création* est la première atteinte de la longueur décimale suivante. Un mot fini `w` se termine par `I`. Pour une chaîne de `k` mots `W=(w_1,...,w_k)`, on impose exactement, pour chacun des `k` segments : toutes les valeurs intermédiaires sont strictement inférieures à `10^(L+i)` et la valeur finale est au moins `10^(L+i)`. On impose également toutes les parités de la chaîne concaténée. Le départ a exactement `L` chiffres.

Comme dans S4, les contraintes sont une congruence unique `x ≡ r_W (mod 2^(Q+1))` et un intervalle entier `[A_W(L), B_W(L)]`, à condition d'exclure les mots classiques contenant `II` (impossibles, puisque `3n+1` est pair). Le calcul utilise exclusivement les nombres entiers, les fractions rationnelles et les inégalités exactes, sans extrapolation numérique flottante.

Les bornes normalisées sont :

`alpha_W = max(1/10, max_i 10^i * 2^(q_{h_i}) / 3^(p_{h_i}))`

`beta_W = min(1, min_i min_{h avant fin du mot i} 10^i * 2^(q_h) / 3^(p_h))`.

`alpha_W < beta_W` : la chaîne est réalisable pour toute longueur initiale assez grande. `alpha_W > beta_W` : la fenêtre est vide pour toute longueur initiale assez grande. Cas particulier : tout raccordement `II` est exclu à toute longueur. L'égalité de bornes est impossible pour une véritable chaîne de premières créations de tête (lemme S13 ci-dessous).

### Alphabet exact retenu pour l’exhaustivité restreinte

| Mot | Occurrences dans les 230 intervalles |
|---|---:|
| `PIPIPIPIPIPI` | 27 |
| `I` | 17 |
| `PIPIPIPIPI` | 17 |
| `PIPIPIPI` | 8 |
| `PIPPIPIPIPIPIPI` | 7 |
| `PIPIPIPIPIPPIPI` | 5 |
| `PPIPIPIPIPIPIPI` | 5 |
| `PIPPIPIPIPIPIPIPI` | 4 |
| `IPI` | 3 |
| `PIPIPIPPIPIPPIPIPIPI` | 3 |

Ces dix mots comptent ensemble 96 occurrences parmi les 230 intervalles. Leur ordre est conservé dans les catalogues CSV et le programme de vérification.

## Vérification des occurrences historiques

Les 21 trajectoires contiennent **189 triplets consécutifs** et **170 quadruplets consécutifs** de mots. Les 359 occurrences ont été contrôlées à leur longueur initiale propre : respect du mot, de la classe résiduelle et de la fenêtre entière, et état final exact. Les 189 et 170 *occurrences* ont ici des séquences distinctes dans ce corpus ; cette observation n'implique aucune impossibilité de répétition en général.

## Classification exhaustive sur dix mots récurrents

Les dix mots sélectionnés sont les dix plus fréquents parmi les 133 types de mots du corpus, représentant **96 occurrences sur les 230**. Cette classification ne couvre **pas** les 133^3 ni les 133^4 combinaisons de l'alphabet complet.

| Nombre de mots | Total | Admissibles à longueur assez grande | Fenêtres négatives | Contradictions de parité |
|---:|---:|---:|---:|---:|
| 1 | 10 | 10 | 0 | 0 |
| 2 | 100 | **66** | 14 | 20 |
| 3 | 1 000 | **357** | 283 | 360 |
| 4 | 10 000 | **1 745** | 3 375 | 4 880 |

La vérification exacte à 60 chiffres reproduit tous les effectifs positifs de la dernière colonne d'admissibilité (aucune fenêtre positive n'est restée vide à cette longueur). Le caractère « à longueur suffisamment grande » découle de S5, non de cette seule vérification à 60 chiffres.

À 12 chiffres, seules **1 331** des 1 745 chaînes de quatre mots à fenêtre positive possèdent déjà un témoin dans leur classe dyadique. À 20 chiffres, les **1 745** sont réalisées. Cette différence reflète le rôle des congruences et de la taille de l'intervalle : « fenêtre positive » ne signifie pas « témoin à toutes les longueurs ».

## Résultat majeur A : les paires ne déterminent pas les triplets

**417** triplets ont leurs deux paires consécutives admissibles à longueur assez grande. Parmi eux, **60** triplets ont pourtant une fenêtre globale négative.

Un exemple certifié est `IPI | PIPIPIPIPI | PIPIPIPIPI` :

- la paire `IPI | PIPIPIPIPI` a la fenêtre `(640/2187, 1/3)` ;
- la paire `PIPIPIPIPI | PIPIPIPIPI` a la fenêtre `(10240/59049, 16/81)` ;
- le triplet entier a les bornes `alpha=204800/531441 > beta=1/3`.

Il est **impossible à toute longueur initiale L >= 1**, comme on le voit directement avec les deux contraintes incompatibles :

`x <= floor((10^L - 2)/3)` (première opération `I`, avant création du premier record),

`x >= ceil((204800*10^L - 527345)/531441)` (valeur finale créant le troisième record).

La différence des bornes réelles est strictement positive puisque `82959*10^L > 519153` pour tout `L>=1`.

## Résultat majeur B : les triplets ne déterminent pas les quadruplets

**1 938** quadruplets possèdent deux sous-triplets consécutifs admissibles. **193** d'entre eux ont une composition globale interdite.

L'exemple le plus simple est le mot `W5=PIPIPIPIPIPI` répété quatre fois. Chaque triplet `W5^3` est réalisable à longueur suffisamment grande. Le quadruplet `W5^4`, lui, est impossible pour toute longueur :

`alpha(W5^4)=1/10 > beta(W5^4)=8388608000/94143178827`.

Cela reformule la preuve du lemme S7 en tant que **contre-exemple à une règle de compatibilité d'ordre 3** : trois créations admissibles n'assurent pas une quatrième.

## Lemmatisation supplémentaire

- **S13 — Dichotomie stricte des fenêtres normalisées.** Pour toute chaîne non vide de mots de première création (respectant les parités), `alpha_W != beta_W`. Les contraintes limites sont strictement positives ou strictement négatives. Preuve : la valuation en base 5 d'une pente liée à l'étape `i` est exactement `i`; une borne inférieure égale à une borne supérieure doit donc concerner la même étape, où l'égalité de `2^q/3^p` à deux préfixes distincts est impossible par unicité de factorisation.
- **S14 — Non-suffisance de la compatibilité par paires.** Exemple explicite ci-dessus, avec certificat entier valable pour toute longueur.
- **S15 — Non-suffisance de la compatibilité par triplets.** Exemple `W5^4`, conséquence de S7 et désormais interprétée comme contrainte d'ordre 4.
- **S16 — Hérédité des chaînes réalisables.** Toute sous-chaîne consécutive d'une chaîne réalisée est réalisable, depuis l'état de record correspondant, mais la réciproque n'est pas vraie. L'ensemble des chaînes réalisées est fermé par extraction de facteurs consécutifs, non par recollement arbitraire.
- **S17 — Borne sur la répétition d'un paquet de mots.** Si un paquet de `k` mots de premières créations, avec coefficient affine `g=3^p/2^q`, est répété `R` fois entre des records tardifs, et si `rho=g/10^k>1`, alors `rho^R<8/5`. C'est l'extension de S12 aux paquets de plusieurs mots.

## Conclusion et limites

Les contraintes Φ–Ψ ne se résument pas aux arêtes des cinq portes ni aux paires de mots : des incompatibilités nouvelles apparaissent aux profondeurs 3 et 4. Les interdictions proviennent soit des parités (raccord `II`), soit du conflit exact de fenêtres de premières créations. Les dénombrements proviennent d'un alphabet expérimental fixé de 10 mots, tandis que S13–S17 expriment des faits universels pour des chaînes finies sous leurs hypothèses.

Ces résultats ne classifient pas les suites infinies d'un entier initial fixé et n'établissent pas la conjecture de Syracuse. L'étape suivante pourra examiner les alphabets élargis et les dépendances de portée supérieure, avec le même vérificateur exact.

## Reproductibilité

Le programme `analyse_triplets_quadruplets.py` lit les CSV sources du corpus, recalcule les mots admissibles et leurs fenêtres, exporte les **1 000 triplets**, **10 000 quadruplets**, **189 triplets observés**, **170 quadruplets observés**, et le bilan `resultats.json`. Les calculs utilisent les fractions rationnelles `Fraction`, les congruences entières et la simulation classique pour contrôler des témoins.
