#!/usr/bin/env python3
"""Classification exacte de chaines finies de mots de premiere creation de tete.
Aucune dependance tierce. Le calcul prend les CSV d'etude fournis.
Les residus sont ceux de la transformation classique n -> 3n+1 / n/2.
"""
import csv, os, json, itertools, math
from fractions import Fraction
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = Path('/mnt/data/Syracuse_PhiPsi_Analyse_230_Mots/230_intervalles_phi_psi_enrichis.csv')
SRC_WORDS = Path('/mnt/data/Syracuse_PhiPsi_Analyse_230_Mots/133_mots_classes_dyadiques.csv')


def ceildiv(a,b): return -((-a)//b)


def structure(words,L=None,with_prefix=False):
    """Retourne admissibilite limite exacte et, si L, borne de depart et cardinal.
    Mot w termine par I. La ieme tete de record est 10**(L+i).
    Les 10^L sont utilisees seulement pour les bornes entieres.
    """
    p=q=0; A=1; B=0; D=1
    last_op=None; parity_contradiction=False
    a=Fraction(1,10); b=Fraction(1,1)
    lo=10**(L-1) if L is not None else None
    hi=10**L-1 if L is not None else None
    prefixes=[]
    for i,word in enumerate(words):
        if not word or word[-1]!='I' or any(c not in 'IP' for c in word): raise ValueError(word)
        for j,c in enumerate(word):
            if last_op=='I' and c=='I': parity_contradiction=True
            last_op=c
            # Compute input parity congruence from last step's predecessor on completion.
            if c=='I':
                A*=3; B=3*B+D; p+=1
            else:
                D*=2; q+=1
            fc = Fraction((10**i)*D,A)
            if c == 'I' and j==len(word)-1:
                if fc>a: a=fc
                if L is not None: lo=max(lo,ceildiv(D*10**(L+i)-B,A))
            else:
                if fc<b: b=fc
                if L is not None: hi=min(hi,(D*10**(L+i)-B-1)//A)
            if with_prefix:
                prefixes.append((i,j,c,A,B,D))
    # To realize final I, predecessor must be odd; get numerator before terminal I
    # Reverse last affine update (3Aprev=A, 3Bprev+D=B).
    P=A//3; Bprev=(B-D)//3
    modulo=2*D
    residue=((D-Bprev)*pow(P,-1,modulo))%modulo
    count=0; first=None; last=None
    if L is not None and lo<=hi and not parity_contradiction:
        t0=ceildiv(lo-residue,modulo)
        t1=(hi-residue)//modulo
        if t1>=t0:
            count=t1-t0+1; first=residue+t0*modulo; last=residue+t1*modulo
    return dict(alpha=a,beta=b,window=not parity_contradiction and a<b,boundary=not parity_contradiction and a==b,forbidden_limit=parity_contradiction or a>b,parity_contradiction=parity_contradiction,lo=lo,hi=hi,
        residue=residue,modulo=modulo,number=count,first=first,last=last,
        p=p,q=q,A=A,B=B,D=D,prefixes=prefixes)


def compact(rec):
    return {k:(str(v) if isinstance(v,Fraction) else v) for k,v in rec.items() if k!='prefixes'}


def words_trajectory(rows):
    rows.sort(key=lambda x:int(x['numero_tete']))
    return [r['mot_IP'] for r in rows]


def find_observed():
    by=defaultdict(list)
    for r in csv.DictReader(SRC.open()): by[r['depart']].append(r)
    triples=[]; quads=[]; checks=0
    for depart,rows in by.items():
        rows.sort(key=lambda x:int(x['numero_tete']))
        L=int(rows[0]['longueur_depart'])
        for k,collector in ((3,triples),(4,quads)):
            for j in range(len(rows)-k+1):
                words=[r['mot_IP'] for r in rows[j:j+k]]
                L0=L+j
                st=structure(words,L0)
                x=int(rows[j]['debut_etat'])
                if not (st['lo']<=x<=st['hi'] and x%st['modulo']==st['residue'] and st['number']>0):
                    raise AssertionError((depart,k,j,words,st,x))
                # Check exact affine at entire chain and first record value.
                if (st['A']*x+st['B'])//st['D'] != int(rows[j+k-1]['fin_etat']):
                    raise AssertionError('final mismatch')
                checks+=1
                collector.append(dict(depart=depart, initial_length=L, source_index=j+1,
                                      start_length=L0, words=words, length_total=sum(map(len,words)),
                                      q=st['q'], starts=st['number'], alpha=st['alpha'], beta=st['beta'],
                                      final_state=rows[j+k-1]['fin_etat']))
    return triples,quads,checks


def select_words():
    allw=list(csv.DictReader(SRC_WORDS.open()))
    return [x['mot_IP'] for x in allw[:10]]


def exhaustive(words, k, L=60):
    rows=[]; stats=Counter()
    for chain in itertools.product(words,repeat=k):
        st=structure(chain,L)
        stats['total']+=1
        kind='parity' if st['parity_contradiction'] else ('positive' if st['window'] else ('zero' if st['boundary'] else 'negative'))
        stats['width_'+kind]+=1
        if st['number']>0:stats['realized_at_L']+=1
        rows.append((chain,st))
    return rows,stats


def pair_insufficiency(words,L=60):
    pair={c:structure(c,L) for c in itertools.product(words,repeat=2)}
    trip={c:structure(c,L) for c in itertools.product(words,repeat=3)}
    examples=[]
    for c,st in trip.items():
        if pair[c[:2]]['window'] and pair[c[1:]]['window'] and st['forbidden_limit']:
            examples.append((c,st,pair[c[:2]],pair[c[1:]]))
    examples.sort(key=lambda a:(sum(map(len,a[0])),a[0]))
    # A quadruple may have both contiguous triples positive, but forbidden globally.
    quadruple=[]
    trip_ok={c:st for c,st in trip.items() if st['window']}
    for c in itertools.product(words,repeat=4):
        if c[:3] in trip_ok and c[1:] in trip_ok:
            st=structure(c,L)
            if st['forbidden_limit']:
                quadruple.append((c,st))
    quadruple.sort(key=lambda a:(sum(map(len,a[0])),a[0]))
    return examples,quadruple


def run():
    tr,qd,checks=find_observed()
    chosen=select_words()
    row3,stats3=exhaustive(chosen,3)
    row4,stats4=exhaustive(chosen,4)
    forbidden3,forbidden4=pair_insufficiency(chosen)
    w5='PIPIPIPIPIPI'
    rep=[(k,structure([w5]*k,60)) for k in range(1,6)]
    # Cross-check one selected exact sample via direct simulation up to its last record.
    def simulate(x,words):
        k=0; L=len(str(x)); last=x
        for i,w in enumerate(words):
            bound=10**(L+i)
            for j,op in enumerate(w):
                if op=='I':
                    assert x%2==1
                    x=3*x+1
                else:
                    assert x%2==0
                    x//=2
                if j<len(w)-1: assert x<bound
                else:assert x>=bound
                k+=1
        return x,k
    for chain,st in row3[:25]+row4[:25]:
        if st['first'] is not None:
            final,steps=simulate(st['first'],chain)
            assert final==(st['A']*st['first']+st['B'])//st['D']
    for rows,name in ((tr,'triplets_observes.csv'),(qd,'quadruplets_observes.csv')):
        with (ROOT/name).open('w',newline='') as fh:
            fields=['depart','initial_length','source_index','start_length','word1','word2','word3']+(['word4'] if name.startswith('quad') else [])+['total_operations','q_divisions','number_candidate','alpha','beta']
            wr=csv.DictWriter(fh,fieldnames=fields);wr.writeheader()
            for a in rows:
                v=dict(depart=a['depart'],initial_length=a['initial_length'],source_index=a['source_index'],start_length=a['start_length'],total_operations=a['length_total'],q_divisions=a['q'],number_candidate=a['starts'],alpha=str(a['alpha']),beta=str(a['beta']))
                for i,w in enumerate(a['words']):v['word'+str(i+1)]=w
                wr.writerow(v)
    for rows,name in ((row3,'catalogue_1000_triplets_L60.csv'),(row4,'catalogue_10000_quadruplets_L60.csv')):
        with (ROOT/name).open('w',newline='') as fh:
            fields=['mot'+str(i+1) for i in range(len(rows[0][0]))]+['classe_limite','alpha','beta','largeur','modulo','residu','borne_inf_L60','borne_sup_L60','effectif_L60','premier_exemple_L60']
            wr=csv.DictWriter(fh,fieldnames=fields);wr.writeheader()
            for chain,st in rows:
                v={'classe_limite':'parite_impossible' if st['parity_contradiction'] else 'positive' if st['window'] else 'zero' if st['boundary'] else 'interdite_fenetre', 'alpha':str(st['alpha']),'beta':str(st['beta']), 'largeur':str(st['beta']-st['alpha']), 'modulo':str(st['modulo']), 'residu':str(st['residue']), 'borne_inf_L60':str(st['lo']),'borne_sup_L60':str(st['hi']),'effectif_L60':str(st['number']),'premier_exemple_L60':str(st['first'] or '')}
                for i,w in enumerate(chain):v['mot'+str(i+1)]=w
                wr.writerow(v)
    stats=dict(observed_triplets=len(tr),observed_quadruplets=len(qd),observed_verified=checks,distinct_observed_triplets=len(set(tuple(a['words']) for a in tr)),distinct_observed_quadruplets=len(set(tuple(a['words']) for a in qd)),ten_words=chosen,triples=stats3,quadruples=stats4,forbidden3_count=len(forbidden3),forbidden4_count=len(forbidden4),example3=[dict(words=list(a[0]),alpha=str(a[1]['alpha']),beta=str(a[1]['beta']),pair12_width=str(a[2]['beta']-a[2]['alpha']),pair23_width=str(a[3]['beta']-a[3]['alpha'])) for a in forbidden3[:8]],example4=[dict(words=list(a[0]),alpha=str(a[1]['alpha']),beta=str(a[1]['beta'])) for a in forbidden4[:8]],w5=[dict(k=k,alpha=str(s['alpha']),beta=str(s['beta']),count_L60=s['number']) for k,s in rep])
    (ROOT/'resultats.json').write_text(json.dumps(stats,indent=2,ensure_ascii=False,default=int))
    print(json.dumps(stats,indent=2,ensure_ascii=False,default=int))

if __name__=='__main__':run()
