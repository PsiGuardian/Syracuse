from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
P=Path(__file__).resolve().parent
labels=['1 mot','2 mots','3 mots','4 mots']
counts=[10,100,1000,10000]
valid=[10,66,357,1745]
parity=[0,20,360,4880]
windows=[0,14,283,3375]
fig,ax=plt.subplots(figsize=(9.5,5.2))
xs=range(1,5)
a=[100*v/t for v,t in zip(valid,counts)]
b=[100*v/t for v,t in zip(parity,counts)]
c=[100*v/t for v,t in zip(windows,counts)]
ax.bar(xs,a,label='Admissibles')
ax.bar(xs,b,bottom=a,label='Contradictions de parité')
ax.bar(xs,c,bottom=[a[i]+b[i] for i in range(4)],label='Fenêtres incompatibles')
for x,v in zip(xs,a):
 ax.text(x,v/2,f'{v:g} %',ha='center',va='center',fontsize=11,weight='bold')
ax.set_ylim(0,105)
ax.set_xticks(list(xs),labels)
ax.set_ylabel('Part des chaînes examinées (%)')
ax.set_title('Syracuse Φ–Ψ — Admissibilité des chaînes sur dix mots récurrents')
ax.legend(ncol=3,loc='upper center',bbox_to_anchor=(.5,-.07))
fig.tight_layout()
fig.savefig(P/'admissibilite_profondeur.png',dpi=165,bbox_inches='tight')
plt.close(fig)
