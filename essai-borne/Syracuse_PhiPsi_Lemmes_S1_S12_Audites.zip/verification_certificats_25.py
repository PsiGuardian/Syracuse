from pathlib import Path
from fractions import Fraction
from pathlib import Path
import csv

def ceild(a,b): return -((-a)//b)

def fct(w):
 p=q=B=0
 out=[(1,1,0)]
 for ch in w:
  if ch=='I': B=3*B+2**q;p+=1
  elif ch=='P': q+=1
  else: raise ValueError(ch)
  out.append((3**p,2**q,B))
 return out,p,q

def calc(row,L):
 w0=row['mot_temoin_avant']; w1=row['mot_temoin_apres']; w=w0+w1
 states,p,q=fct(w); j0=len(w0); j1=len(w)
 lo=10**(L-1);hi=10**L-1
 def bound(h,lower=None,upper=None):
  nonlocal lo,hi
  A,D,B=states[h]
  if lower is not None:lo=max(lo,ceild(D*lower-B,A))
  if upper is not None:hi=min(hi,(D*upper-B)//A)
 def gate(h,signature,k):
  d,c=map(int,signature.split('|')[:2]);pow10=10**k
  tlo=max(0,ceild(c*pow10-1,3));thi=min(pow10-1,((c+1)*pow10-2)//3)
  bound(h,lower=d*pow10+tlo, upper=d*pow10+thi)
 for h in range(j0): bound(h, upper=10**L-1)
 bound(j0, lower=10**L)
 for h in range(j0+1,j1):bound(h,upper=10**(L+1)-1)
 bound(j1, lower=10**(L+1))
 gate(j0-1,row['porte_avant'],L-1)
 gate(j1-1,row['porte_apres'],L)
 A,D,B=states[-2];M=2**(q+1);r=((D-B)*pow(A,-1,M))%M
 n=max(0,(hi-r)//M-ceild(lo-r,M)+1)
 return n,lo,hi,r,M

rows=list(csv.DictReader(open(str(Path(__file__).resolve().parent/'25_jonctions_portes_fideles.csv'))))
for L in [8,10,12,20]:
 errs=[]
 for i,r in enumerate(rows):
  c,*_=calc(r,L)
  if c!=int(r['candidats_L'+str(L)]):errs.append((i, r['porte_avant'],r['porte_apres'],c,r['candidats_L'+str(L)]))
 print('L',L,'rows',len(rows),'mismatch',len(errs),errs[:5])

def normalized(row):
 w0=row['mot_temoin_avant'];w1=row['mot_temoin_apres'];states,p,q=fct(w0+w1);j0=len(w0); j1=len(w0+w1)
 a=Fraction(1,10);b=Fraction(1)
 def bound(h,low=None,up=None):
  nonlocal a,b
  A,D,B=states[h];g=Fraction(A,D)
  if low is not None: a=max(a,Fraction(low)/g)
  if up is not None:b=min(b,Fraction(up)/g)
 for h in range(j0):bound(h,up=1)
 bound(j0,low=1)
 for h in range(j0+1,j1):bound(h,up=10)
 bound(j1,low=10)
 for h,s,diff in [(j0-1,row['porte_avant'],10),(j1-1,row['porte_apres'],1)]:
  d,c=map(int,s.split('|')[:2]);bound(h,low=Fraction(3*d+c,3*diff),up=Fraction(3*d+c+1,3*diff))
 return a,b
errors=[]
for i,row in enumerate(rows):
 a,b=normalized(row)
 if (a,b)!=(Fraction(row['alpha']),Fraction(row['beta'])):errors.append((i,str(a),str(b),row['alpha'],row['beta']))
print('Normalized rational certificate errors',len(errors));print(errors[:5]);print('all strictly positive',(all(normalized(r)[0]<normalized(r)[1] for r in rows)))
