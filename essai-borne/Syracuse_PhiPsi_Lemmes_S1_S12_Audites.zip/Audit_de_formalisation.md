# Syracuse Φ–Ψ — Audit de formalisation avant l’étude des triplets et quadruplets

## Réponse

Les résultats S1–S8 ont bien été rédigés, mais **l'inventaire n'était pas complet** au moment de la réponse précédente. De plus, R1–R6 recoupent plusieurs résultats de S1–S8, et l'existence d'un fichier LaTeX ne signifie pas qu'un théorème a fait l'objet d'une validation scientifique externe.

Nous ajoutons **S9 à S12** dans un manuscrit révisé :

- **S9 — Transport exact des différences et des chiffres de pied communs** au travers d'un mot classique quelconque (p opérations impaires et q divisions).
- **S10 — Loi de variation des effectifs entre longueurs** : à chaîne finie fixe, fenêtre de largeur positive et L assez grand, C_W(L)=c_W 10^L+e_W(L), avec correction bornée et éventuellement périodique. En conséquence C_W(L+1)=10 C_W(L)+O_W(1).
- **S11 — Récurrence exacte des mantisses de tête** entre créations record consécutives : z_{j+1}=(g_w/10) z_j+b_w/10^{d_j}.
- **S12 — Borne quantitative sur les répétitions d'un même mot expansif normalisé** : si rho=g_w/10>1, alors rho^k<8/5 pour une répétition de k premières créations tardives.

## Inventaire antérieur et recouvrements

| Ensemble | Statut | Observation |
| --- | --- | --- |
| T1–T7 | Rédigé | Variations élémentaires, têtes, superpositions, jonctions |
| T8–T15 | Rédigé | Maxima, classes de parité, bornes et dénombrements |
| R1–R6 | Rédigé | Portes de tête, congruences, mots de réarmement |
| S1–S8 | Rédigé | Composition, classes et fenêtres, stabilisation, W5, portes |
| S9–S12 | Ajouté et compilé | Transport, quasi-périodicité, mantisses, borne de répétition |

Ces numérotations ne correspondent pas à 33 résultats indépendants : il existe des recouvrements, notamment R3/S3, R4/S1 et R5/S4.

## Contrôles indépendants du certificat S8

Le certificat de complétude des **25 couples de portes** repose sur des calculs rationnels finis. Les 25 paires sont distinctes, chacune possède une fenêtre limite alpha < beta. Une seconde implémentation des inégalités de première création, des portes décimales et de la congruence dyadique reproduit exactement les **25 effectifs** annoncés pour chacune des longueurs L=8, L=10, L=12 et L=20. Les 25 intervalles normalisés alpha/beta ont également été recalculés à l'identique. Ces contrôles étayent les certificats, mais ne constituent pas une relecture mathématique indépendante par les pairs.

## Portée et limites

- S4 formalise déjà les contraintes de **toute chaîne finie** de mots, y compris des triplets et quadruplets. Leur extension expérimentale doit donc se concentrer sur le dénombrement, les interdictions et les certificats explicites, non sur une nouvelle définition des règles.
- S5 et S10 supposent **une chaîne fixe** lorsque L grandit. Leur résultat ne permet pas de remplacer L fixé par un horizon temporel infini croissant.
- S8 établit une complétude locale des 25 paires de portes, mais aucune propriété équivalente pour les triplets n'en découle automatiquement.
- S6 et S12 excluent certaines répétitions de mots de première création ; ils ne résolvent pas la conjecture de Syracuse.
- On ne peut pas affirmer avoir énuméré *tous les lemmes imaginables* découlant d'un ensemble infini de relations : l'audit concerne ici les conséquences structurantes actuellement identifiées et explicitées.

## Documents

- `Lemmes_S1_S12_Revision.tex` : manuscrit révisé.
- `Lemmes_S1_S12_Revision.pdf` : PDF compilé.
- `verification_certificats_25.py` : recalcul des 25 fenêtres et effectifs.
- `25_jonctions_portes_fideles.csv` : certificats source.
