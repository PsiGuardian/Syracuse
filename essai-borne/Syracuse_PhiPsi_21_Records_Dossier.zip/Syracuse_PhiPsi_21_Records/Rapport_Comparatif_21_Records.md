# Syracuse Φ–Ψ — Analyse comparative de 21 trajectoires records (1 à 21 chiffres)

**Objet :** décomposer exactement chaque record fourni en créations inédites de tête, remontées, pertes, mots I/P et jonctions de suffixes de droite à gauche.

## Conventions et vérification

- `I` : transformation classique impaire `3n+1`. `P` : division `n/2`.
- `U(n)` : `(3n+1)/2` si impair et `n/2` si pair.
- `N+` : longueur du maximum moins longueur initiale. Une première *longueur maximale* peut survenir avant la *valeur numérique maximale*.
- `H=L+ν₂(a)` concerne la première divergence de **parité sous U** des suffixes `S_L=N mod 10^L` et `S_(L+1)=S_L+a10^L`; ce n’est pas l’instant d’une nouvelle tête sur la trajectoire entière.
- Trajectoires calculées en arithmétique entière jusqu’à 1 ; colonnes « jusqu’au maximum » arrêtées au premier maximum numérique.
- Les 42 valeurs de gains classique et accéléré du tableau de départ ont été retrouvées exactement.

## 1. Comparatif des 21 records

| Chiffres | Nombre initial | N+ C | N+ U | Premier rang longueur max | Rang valeur max | I | P | Montées | Pertes | Têtes perdues aussitôt |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | `7` | +1 | +1 | 1 | 5 | 3 | 2 | 1 | 0 | 0/1 |
| 2 | `27` | +2 | +2 | 36 | 77 | 33 | 44 | 12 | 10 | 2/2 |
| 3 | `703` | +3 | +3 | 75 | 82 | 35 | 47 | 15 | 12 | 2/3 |
| 4 | `9663` | +4 | +4 | 44 | 48 | 23 | 25 | 13 | 9 | 3/4 |
| 5 | `77671` | +5 | +4 | 69 | 71 | 33 | 38 | 17 | 12 | 4/5 |
| 6 | `704511` | +5 | +5 | 61 | 69 | 33 | 36 | 15 | 10 | 4/5 |
| 7 | `6631675` | +7 | +7 | 150 | 163 | 72 | 91 | 40 | 33 | 7/7 |
| 8 | `80049391` | +8 | +8 | 162 | 164 | 73 | 91 | 36 | 28 | 7/8 |
| 9 | `319804831` | +10 | +9 | 167 | 167 | 77 | 90 | 31 | 21 | 10/10 |
| 10 | `8528817511` | +10 | +9 | 205 | 212 | 94 | 118 | 44 | 34 | 9/10 |
| 11 | `77566362559` | +10 | +10 | 277 | 300 | 129 | 171 | 67 | 57 | 9/10 |
| 12 | `871673828443` | +12 | +12 | 193 | 212 | 97 | 115 | 42 | 30 | 11/12 |
| 13 | `9016346070511` | +14 | +14 | 352 | 356 | 155 | 201 | 77 | 63 | 13/14 |
| 14 | `64848224337147` | +14 | +13 | 331 | 341 | 149 | 192 | 63 | 49 | 14/14 |
| 15 | `737482236053119` | +14 | +14 | 403 | 411 | 177 | 234 | 74 | 60 | 13/14 |
| 16 | `8562235014026655` | +16 | +16 | 446 | 450 | 194 | 256 | 89 | 73 | 15/16 |
| 17 | `93264792503458119` | +17 | +17 | 466 | 472 | 204 | 268 | 87 | 70 | 16/17 |
| 18 | `891563131061253151` | +18 | +18 | 530 | 539 | 231 | 308 | 106 | 88 | 17/18 |
| 19 | `1980976057694848447` | +19 | +19 | 659 | 690 | 292 | 398 | 135 | 116 | 19/19 |
| 20 | `71149323674102624415` | +20 | +20 | 502 | 520 | 227 | 293 | 102 | 82 | 19/20 |
| 21 | `274133054632352106267` | +21 | +20 | 570 | 570 | 247 | 323 | 114 | 93 | 21/21 |

## 2. Identités universelles employées

Pour chaque trajectoire classique, chaque variation de longueur vaut `-1`, `0` ou `+1` :

```text
N+ = #(montées locales de longueur) − #(pertes locales de longueur)
```

La création d’une tête à la frontière `10^L` lors d’une étape impaire est équivalente à `3n+1 >= 10^L`. La tête reste après la division suivante si et seulement si `3n+1 >= 2×10^L`.

La relation de superposition exacte (jusqu’au premier rang de divergence) est :

```text
S_(L+1) = S_L + a×10^L
H = L + ν₂(a)       (si a ≠ 0)
U^h(S_(L+1)) − U^h(S_L) = a×10^L×3^(m_h)/2^h   (0<=h<=H)
```

Elle établit la première divergence de parité, mais **n’établit pas** que les suffixes causent à eux seuls l’apparition d’une nouvelle tête sur la trajectoire initiale.

## 3. Principaux résultats comparatifs

- Premières créations de tête, somme sur les 21 trajectoires : **230** ; toutes les montées locales avant le maximum : **1180** ; pertes : **950**.
- Créations temporaires immédiatement perdues : **215** sur **230** créations inédites ; les autres persistent au moins après une division.
- Jonctions décimales comparées : **210**, dont **192** ajoutent un chiffre non nul.
- Corridors complets `I^rP^t` avant le maximum numérique (opérateur U) : **626**.

## 4. Représentations comparatives

![Gains](graphiques/Comparatif_Gains_21_Records.png)

![Montées et pertes](graphiques/Comparatif_Montees_Pertes.png)

![Chronologie des rangs de maximum](graphiques/Comparatif_Rangs_Maxima.png)

![Matrice chronologique des créations de tête](graphiques/Matrice_Chronologie_21_Trajectoires.png)

![Matrice des jonctions](graphiques/Matrice_Jonctions_Superposition.png)


## 4 bis. Impact global des 210 jonctions sur N+

La superposition Phi–Psi prévoit exactement la première divergence de parité sous U (`H=L+ν₂(a)`). Pour quantifier les effets ultérieurs, nous avons reconstruit les trajectoires de **chaque suffixe** jusqu’à 1 et mesuré `N+(S_(L+1))-N+(S_L)`.

- Sur **210** jonctions : **105** gardent le même gain N+, **72** l’augmentent, **33** le réduisent.
- Variation observée : **-3 à +19** positions de tête, relativement au gain du suffixe précédent.
- Une jonction de chiffre nul produit `ΔN+=0`, puisque les deux nombres comparés sont alors identiques.

![Impact des jonctions](graphiques/Matrice_Impact_Jonctions_Nplus.png)

### Jonction supérieure de chaque record

| Longueur finale | Chiffre de tête ajouté | H de première divergence sous U | N+ du suffixe antérieur | N+ du nombre complet | Variation |
|---:|---:|---:|---:|---:|---:|
| 2 | 2 | 2 | +1 | +2 | +1 |
| 3 | 7 | 2 | +1 | +3 | +2 |
| 4 | 9 | 3 | +1 | +4 | +3 |
| 5 | 7 | 4 | +1 | +5 | +4 |
| 6 | 7 | 5 | +2 | +5 | +3 |
| 7 | 6 | 7 | +3 | +7 | +4 |
| 8 | 8 | 10 | +2 | +8 | +6 |
| 9 | 3 | 8 | +3 | +10 | +7 |
| 10 | 8 | 12 | +2 | +10 | +8 |
| 11 | 7 | 10 | +2 | +10 | +8 |
| 12 | 8 | 14 | +2 | +12 | +10 |
| 13 | 9 | 12 | +1 | +14 | +13 |
| 14 | 6 | 14 | +2 | +14 | +12 |
| 15 | 7 | 14 | +2 | +14 | +12 |
| 16 | 8 | 18 | +2 | +16 | +14 |
| 17 | 9 | 16 | +3 | +17 | +14 |
| 18 | 8 | 20 | +2 | +18 | +16 |
| 19 | 1 | 18 | +3 | +19 | +16 |
| 20 | 7 | 19 | +1 | +20 | +19 |
| 21 | 2 | 21 | +3 | +21 | +18 |

**Précaution logique :** ces variations ne sont pas des constantes universelles associées au chiffre `a` ou à `H` ; elles dépendent du nombre entier, et leurs valeurs ont été obtenues par itération exacte. Le résultat décrit les records sélectionnés, sans démontrer de loi de variation générale des maxima.

- `donnees/effets_jonctions_sur_gain_maximal_210.csv` : toutes les valeurs, maxima, rangs et variations pour les 210 paires de suffixes.

## 5. Limite logique

Les égalités de composition, les franchissements et les délais de divergence sont exacts sur tout horizon fini. Le fait de les vérifier pour 21 trajectoires records ne constitue pas une démonstration des comportements asymptotiques pour tous les nombres.

## 6. Cas individuels

- [1 chiffres : `7`](cas_individuels/01_chiffres_7_rapport.md) — +1, 1 nouvelles têtes, 0 jonctions.
- [2 chiffres : `27`](cas_individuels/02_chiffres_27_rapport.md) — +2, 2 nouvelles têtes, 1 jonctions.
- [3 chiffres : `703`](cas_individuels/03_chiffres_703_rapport.md) — +3, 3 nouvelles têtes, 2 jonctions.
- [4 chiffres : `9663`](cas_individuels/04_chiffres_9663_rapport.md) — +4, 4 nouvelles têtes, 3 jonctions.
- [5 chiffres : `77671`](cas_individuels/05_chiffres_77671_rapport.md) — +5, 5 nouvelles têtes, 4 jonctions.
- [6 chiffres : `704511`](cas_individuels/06_chiffres_704511_rapport.md) — +5, 5 nouvelles têtes, 5 jonctions.
- [7 chiffres : `6631675`](cas_individuels/07_chiffres_6631675_rapport.md) — +7, 7 nouvelles têtes, 6 jonctions.
- [8 chiffres : `80049391`](cas_individuels/08_chiffres_80049391_rapport.md) — +8, 8 nouvelles têtes, 7 jonctions.
- [9 chiffres : `319804831`](cas_individuels/09_chiffres_319804831_rapport.md) — +10, 10 nouvelles têtes, 8 jonctions.
- [10 chiffres : `8528817511`](cas_individuels/10_chiffres_8528817511_rapport.md) — +10, 10 nouvelles têtes, 9 jonctions.
- [11 chiffres : `77566362559`](cas_individuels/11_chiffres_77566362559_rapport.md) — +10, 10 nouvelles têtes, 10 jonctions.
- [12 chiffres : `871673828443`](cas_individuels/12_chiffres_871673828443_rapport.md) — +12, 12 nouvelles têtes, 11 jonctions.
- [13 chiffres : `9016346070511`](cas_individuels/13_chiffres_9016346070511_rapport.md) — +14, 14 nouvelles têtes, 12 jonctions.
- [14 chiffres : `64848224337147`](cas_individuels/14_chiffres_64848224337147_rapport.md) — +14, 14 nouvelles têtes, 13 jonctions.
- [15 chiffres : `737482236053119`](cas_individuels/15_chiffres_737482236053119_rapport.md) — +14, 14 nouvelles têtes, 14 jonctions.
- [16 chiffres : `8562235014026655`](cas_individuels/16_chiffres_8562235014026655_rapport.md) — +16, 16 nouvelles têtes, 15 jonctions.
- [17 chiffres : `93264792503458119`](cas_individuels/17_chiffres_93264792503458119_rapport.md) — +17, 17 nouvelles têtes, 16 jonctions.
- [18 chiffres : `891563131061253151`](cas_individuels/18_chiffres_891563131061253151_rapport.md) — +18, 18 nouvelles têtes, 17 jonctions.
- [19 chiffres : `1980976057694848447`](cas_individuels/19_chiffres_1980976057694848447_rapport.md) — +19, 19 nouvelles têtes, 18 jonctions.
- [20 chiffres : `71149323674102624415`](cas_individuels/20_chiffres_71149323674102624415_rapport.md) — +20, 20 nouvelles têtes, 19 jonctions.
- [21 chiffres : `274133054632352106267`](cas_individuels/21_chiffres_274133054632352106267_rapport.md) — +21, 21 nouvelles têtes, 20 jonctions.

## 7. Datasets

- `donnees/synthese_21_records.csv` : synthèse quantitative ;
- `donnees/creations_tete_tous_records.csv` : toutes les premières créations et leurs mots d’opérations I/P ;
- `donnees/montees_locales_tous_records.csv` : toutes les montées, y compris les réapparitions ;
- `donnees/jonctions_superposition_tous_records.csv` : superposition de tous les suffixes ;
- `donnees/corridors_termines_avant_max.csv` : corridors U complets avec r, t, r′ ;
- `donnees/etats_tous_records_complets.csv` : trajectoires entières jusqu’à 1 pour chaque nombre.
