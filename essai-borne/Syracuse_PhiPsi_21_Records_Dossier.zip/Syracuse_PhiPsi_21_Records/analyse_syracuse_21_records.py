#!/usr/bin/env python3
"""Etude reproductible des 21 trajectoires records Syracuse / Phi-Psi.
Bibliothèque standard pour les calculs; matplotlib pour les schémas.
Aucune borne de convergence universelle n'est inférée.
"""
from __future__ import annotations
import csv, json, math, zipfile
from pathlib import Path
from collections import Counter, defaultdict
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path('/mnt/data/Syracuse_PhiPsi_21_Records')
ROOT.mkdir(parents=True,exist_ok=True)
(RootCases:=ROOT/'cas_individuels').mkdir(exist_ok=True)
(RootGraphs:=ROOT/'graphiques').mkdir(exist_ok=True)
(RootData:=ROOT/'donnees').mkdir(exist_ok=True)
STARTS=[7,27,703,9663,77671,704511,6631675,80049391,319804831,8528817511,77566362559,871673828443,9016346070511,64848224337147,737482236053119,8562235014026655,93264792503458119,891563131061253151,1980976057694848447,71149323674102624415,274133054632352106267]
EXPECTED_U=[1,2,3,4,4,5,7,8,9,9,10,12,14,13,14,16,17,18,19,20,20]
EXPECTED_C=[1,2,3,4,5,5,7,8,10,10,10,12,14,14,14,16,17,18,19,20,21]
assert len(STARTS)==21

def write_csv(path, rows, columns=None):
    rows=list(rows)
    if not rows:
        return
    keys=columns if columns is not None else list(rows[0].keys())
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(rows)

def v2(x):
    if x<=0:raise ValueError(x)
    return (x & -x).bit_length()-1

def C(n):return 3*n+1 if n&1 else n//2

def U(n):return (3*n+1)//2 if n&1 else n//2

def group(s):return f'{s:,}'.replace(',',' ')

summary=[]; records_all=[]; segments_all=[]; joins_all=[]; full_all=[]; odd_blocks_all=[]; case_data=[]
for n,exp_u,exp_c in zip(STARTS,EXPECTED_U,EXPECTED_C):
    d=len(str(n)); tag=f'{d:02d}_chiffres_{n}'
    xs=[n];ops=[]
    while xs[-1]!=1:
        x=xs[-1];ops.append('I' if x&1 else 'P');xs.append(C(x))
        if len(xs)>200000:raise RuntimeError('Limite de securite de parcours')
    lens=[len(str(x)) for x in xs]
    deltas=[0]+[lens[t]-lens[t-1] for t in range(1,len(xs))]
    assert set(deltas).issubset({-1,0,1})
    mx=max(xs);tmax=xs.index(mx);lmax=len(str(mx));max_u=n;us=[n]
    while us[-1]!=1:
        us.append(U(us[-1]));max_u=max(max_u,us[-1])
        if len(us)>200000:raise RuntimeError('Limite U')
    gain_c=lmax-d;gain_u=len(str(max_u))-d
    assert gain_c==exp_c and gain_u==exp_u,(d,gain_c,gain_u)
    ip=Counter(ops[:tmax]);bd=Counter(deltas[1:tmax+1]);assert bd[1]-bd[-1]==gain_c
    first_finallength=lens.index(lmax)

    # Every first crossing of an unvisited decimal length (N+).
    milestones=[];best=d;previous=0;case_events=[]
    for t in range(1,tmax+1):
        if lens[t]>best:
            assert lens[t]==best+1 and ops[t-1]=='I'
            t0=previous
            word=''.join(ops[t0:t]);dec=deltas[t0+1:t+1];upper=lens[t]
            rr={'chiffres_initiaux':d,'nombre_initial':str(n), 'gain':upper-d, 'nouvelle_longueur':upper,
                'rang_classique':t,'rang_record_precedent':t0,'iterations_intervalle':t-t0,
                'operations_I':word.count('I'),'operations_P':word.count('P'),
                'montees_intervalle':dec.count(1),'pertes_intervalle':dec.count(-1),
                'neutres_intervalle':dec.count(0),
                'nombre_avant_3n_plus_1':str(xs[t-1]), 'nombre_apres_3n_plus_1':str(xs[t]),
                'v2_3n_plus_1':v2(xs[t]),
                'longueur_juste_apres_division':len(str(xs[t+1])),
                'tete_perdue_a_division_suivante':int(len(str(xs[t+1]))<upper),
                'mot_IP_intervalle':word}
            assert rr['montees_intervalle']-rr['pertes_intervalle']==1
            records_all.append(rr);milestones.append(rr);best=upper;previous=t
    assert len(milestones)==gain_c
    assert milestones[-1]['rang_classique']==first_finallength
    # Every local digit-count increase before numerical peak.
    for t in range(1,tmax+1):
        if deltas[t]==1:
            case_events.append({'chiffres_initiaux':d,'nombre_initial':str(n),'rang':t,
                                'longueur_avant':lens[t-1],'longueur_apres':lens[t],
                                'nombre_avant':str(xs[t-1]),'nombre_apres':str(xs[t]),
                                'nouvelle_longueur_jamais_atteinte':int(any(r['rang_classique']==t for r in milestones)),
                                'v2_3n_plus_1':v2(xs[t]),
                                'tete_perdue_a_division_suivante':int(len(str(xs[t+1]))<lens[t])})
    segments=[]
    for i,r in enumerate(milestones):
        segments.append({k:r[k] for k in ['chiffres_initiaux','gain','nouvelle_longueur','rang_classique','rang_record_precedent','operations_I','operations_P','montees_intervalle','pertes_intervalle','neutres_intervalle','v2_3n_plus_1','mot_IP_intervalle']})
    segments_all.extend(segments)
    # Suffix superpositions, exact parity divergence H = L+v2(a), and numerical divergence check.
    joins=[]
    for L in range(1,d):
        a=(n//10**L)%10;small=n%10**L;large=n%10**(L+1)
        h=L+v2(a) if a else None
        if a:
            x=small;y=large;cnt=0;m=0
            while (x&1)==(y&1):
                assert y-x==a*(10**L)*(3**m)//(2**cnt)
                p=x&1;m+=p;x=U(x);y=U(y);cnt+=1
                if cnt>50000:raise RuntimeError('Non divergence')
            assert cnt==h
            assert (y-x)&1
            # At the instant of first parity mismatch the delta is odd.
        j={'chiffres_initiaux':d,'nombre_initial':str(n),'position_L':L,'chiffre_ajoute_a':a,
           'suffixe_L':str(small),'suffixe_L_plus_1':str(large),'v2_a':v2(a) if a else '',
           'premier_rang_divergence_parite_U':h if a else '',
           'aucune_divergence_chiffre_nul':int(a==0),
           'controle_par_calcul':h if a else ''}
        joins.append(j);joins_all.append(j)
    # Odd corridor windows under U until the first classical numerical peak.
    # Convert full classic states into U sequence positions and their matching classical ranks.
    cursor=0;uidx=0;uvals=[n];uranks=[0];uops=[]
    while cursor<tmax:
        x=xs[cursor]
        if x&1:
            cursor+=2
            if cursor>len(xs)-1:raise AssertionError('Operation impaire sans division')
            assert xs[cursor]==U(x)
            uops.append('I')
        else:
            cursor+=1
            uops.append('P')
        uvals.append(xs[cursor]);uranks.append(cursor)
    # May overstep tmax by one because tmax itself is 3n+1 (even).
    assert uranks[-1] in {tmax,tmax+1}
    corridors=[];pos=0
    while pos<len(uops):
        if uops[pos]!='I':
            # never happens for initial odds if segment boundaries correctly aligned
            pos+=1;continue
        startpos=pos
        while pos<len(uops) and uops[pos]=='I':pos+=1
        r=pos-startpos
        t0=pos
        while pos<len(uops) and uops[pos]=='P':pos+=1
        t=pos-t0
        if not t or pos>=len(uops):continue
        u0=uvals[startpos]; v=uvals[pos]
        q=(u0+1)//2**r
        expected_v=(3**r*q-1)//(2**t)
        assert u0%2 and v%2 and expected_v==v
        rp=v2(v+1)
        co={'chiffres_initiaux':d,'nombre_initial':str(n),'rang_classique_debut':uranks[startpos],
            'rang_classique_fin':uranks[pos], 'rang_U_debut':startpos,'rang_U_fin':pos,
            'r_impaires':r,'t_paires':t,'r_suivant':rp,'nombre_impair_initial':str(u0),
            'nombre_impair_suivant':str(v),'direction':('descente' if v<u0 else 'montee' if v>u0 else 'egalite'),
            'gain_longueur_impair_a_impair':len(str(v))-len(str(u0))}
        corridors.append(co);odd_blocks_all.append(co)

    s={'chiffres_initiaux':d,'nombre_initial':str(n),
       'gain_classique':gain_c,'gain_accelere':gain_u,'longueur_max_classique':lmax,
       'maximum_classique':str(mx),'rang_premiere_valeur_max':tmax,
       'rang_premier_franchissement_longueur_max':first_finallength,
       'iterations_I_jusquau_max':ip['I'],'iterations_P_jusquau_max':ip['P'],
       'montées_locales_jusquau_max':bd[1],'pertes_locales_jusquau_max':bd[-1],
       'neutres_jusquau_max':bd[0], 'nouvelles_tetes':len(milestones),
       'tetes_perdues_immediatement':sum(e['tete_perdue_a_division_suivante'] for e in milestones),
       'remontees_longueur_deja_atteinte':bd[1]-len(milestones),
       'iterations_completes_jusqua_un':len(ops),
       'maximum_accelere':str(max_u), 'iterations_accelerees_jusqua_un':len(us)-1,
       'nombre_jonctions':len(joins), 'jonctions_non_nulles':sum(j['chiffre_ajoute_a']!=0 for j in joins),
       'corridors_Ir_Pt_complets_avant_max':len(corridors)}
    summary.append(s)
    full=[{'chiffres_initiaux':d,'nombre_initial':str(n),'rang_classique':t,
           'operation_precedente':ops[t-1] if t else 'depart','valeur':str(x),
           'longueur':lens[t], 'variation_longueur':deltas[t],
           'record_longueur_cumule':max(lens[:t+1]),
           'avant_ou_au_max_numerique':int(t<=tmax)} for t,x in enumerate(xs)]
    full_all.extend(full)
    write_csv(RootCases/f'{tag}_etats_complets.csv',full)
    write_csv(RootCases/f'{tag}_creations_tete.csv',milestones)
    write_csv(RootCases/f'{tag}_montees_locales.csv',case_events)
    if joins:write_csv(RootCases/f'{tag}_jonctions.csv',joins)
    if corridors:write_csv(RootCases/f'{tag}_corridors.csv',corridors)
    # Per-number timeline chart (only before peak, markers indicate first length record)
    fig,ax=plt.subplots(figsize=(10.6,4.1))
    ax.step(range(tmax+1),lens[:tmax+1],where='post',lw=1.15,label='Longueur décimale')
    ax.scatter([r['rang_classique'] for r in milestones],[r['nouvelle_longueur'] for r in milestones],s=18,zorder=5,label='Nouvelle tête')
    ax.axvline(first_finallength,ls='--',lw=.9,alpha=.7,label='Première longueur maximale')
    if first_finallength!=tmax:ax.axvline(tmax,ls=':',lw=.9,label='Valeur maximale')
    ax.set_title(f'{d} chiffres : {group(n)}  |  N+ = +{gain_c}  |  rang max {tmax}')
    ax.set_xlabel('Itération classique');ax.set_ylabel('Nombre de chiffres')
    ax.grid(alpha=.22);ax.legend(fontsize=8,loc='best')
    fig.tight_layout();fig.savefig(RootGraphs/f'{tag}_longueurs.png',dpi=125);plt.close(fig)
    case_data.append((s,milestones,joins,corridors))

write_csv(RootData/'synthese_21_records.csv',summary)
write_csv(RootData/'creations_tete_tous_records.csv',records_all)
write_csv(RootData/'montees_locales_tous_records.csv', [d for _,m,_,_ in [] for d in m] if False else [
    {**{'chiffres_initiaux':int(p.name.split('_')[0])}, **{}} for p in []]) if False else None
# combine all local rise events from case files
localevents=[]
for n in STARTS:
    d=len(str(n));p=RootCases/f'{d:02d}_chiffres_{n}_montees_locales.csv'
    with p.open(newline='',encoding='utf-8') as f:localevents.extend(csv.DictReader(f))
write_csv(RootData/'montees_locales_tous_records.csv',localevents)
write_csv(RootData/'etats_tous_records_complets.csv',full_all)
write_csv(RootData/'jonctions_superposition_tous_records.csv',joins_all)
write_csv(RootData/'corridors_termines_avant_max.csv',odd_blocks_all)

# 21-row comparison charts
lengths=[d['chiffres_initiaux'] for d in summary]
fig,ax=plt.subplots(figsize=(12.2,5.6))
ax.plot(lengths,[s['gain_classique'] for s in summary],marker='o',label='Gain classique',lw=1.8)
ax.plot(lengths,[s['gain_accelere'] for s in summary],marker='s',label='Gain accéléré',lw=1.5)
ax.plot(lengths,lengths,ls='--',label='Référence N+ = longueur initiale',alpha=.6)
ax.set(xlabel='Nombre de chiffres initiaux',ylabel='Chiffres de tête gagnés',title='Syracuse : croissance des 21 records de longueur')
ax.set_xticks(lengths);ax.grid(alpha=.25);ax.legend()
fig.tight_layout();fig.savefig(RootGraphs/'Comparatif_Gains_21_Records.png',dpi=160);plt.close(fig)

fig,ax=plt.subplots(figsize=(12.6,6.5))
ups=[s['montées_locales_jusquau_max'] for s in summary];downs=[s['pertes_locales_jusquau_max'] for s in summary]
ax.bar(lengths,ups,label='Montées de longueur',alpha=.84)
ax.bar(lengths,[-x for x in downs],label='Pertes de longueur',alpha=.7)
for d,u,v in zip(lengths,ups,downs):
    ax.text(d,u+1,f'+{u-v}',ha='center',fontsize=8)
ax.set_xticks(lengths);ax.set(xlabel='Longueur initiale',ylabel='Nombre d’événements de longueur (pertes négatives)',title='Montées, pertes et bilan net jusqu’au maximum numérique')
ax.axhline(0,linewidth=.8);ax.grid(axis='y',alpha=.2);ax.legend()
fig.tight_layout();fig.savefig(RootGraphs/'Comparatif_Montees_Pertes.png',dpi=160);plt.close(fig)

fig,ax=plt.subplots(figsize=(13.0,5.6))
ax.plot(lengths,[s['rang_premier_franchissement_longueur_max'] for s in summary],marker='o',label='Première longueur maximale')
ax.plot(lengths,[s['rang_premiere_valeur_max'] for s in summary],marker='s',label='Maximum numérique')
ax.set_xticks(lengths);ax.set(xlabel='Longueur initiale',ylabel='Itération classique',title='Deux jalons distincts : première longueur maximale et valeur maximale')
ax.grid(alpha=.24);ax.legend()
fig.tight_layout();fig.savefig(RootGraphs/'Comparatif_Rangs_Maxima.png',dpi=160);plt.close(fig)

# heatmap of normalized first head times relative to first occurrence of maximal length
arr=[[float('nan')]*21 for _ in range(21)]
for s,m,_,_ in case_data:
    d=s['chiffres_initiaux']; T=s['rang_premier_franchissement_longueur_max']
    for r in m:arr[d-1][r['gain']-1]=r['rang_classique']/max(1,T)
fig,ax=plt.subplots(figsize=(12.6,7.3))
im=ax.imshow(arr,origin='lower',aspect='auto',cmap='viridis',vmin=0,vmax=1)
ax.set_yticks(range(21),[str(j) for j in range(1,22)]);ax.set_xticks(range(21),[f'+{j}' for j in range(1,22)],rotation=45)
ax.set(xlabel='Nouvelle position de tête N+',ylabel='Longueur initiale',title='Chronologie normalisée de la première apparition de chaque nouvelle tête')
fig.colorbar(im,ax=ax,label='Rang / premier rang de longueur maximale')
fig.tight_layout();fig.savefig(RootGraphs/'Matrice_Chronologie_21_Trajectoires.png',dpi=160);plt.close(fig)

# superposition delays, plotted as delays relative to position (0..3 = valuation digit), gaps for zero
arr2=[[float('nan')]*21 for _ in range(21)]
for j in joins_all:
    if j['chiffre_ajoute_a']!=0:arr2[j['chiffres_initiaux']-1][j['position_L']-1]=j['premier_rang_divergence_parite_U']-j['position_L']
fig,ax=plt.subplots(figsize=(12.6,7.3))
im=ax.imshow(arr2,origin='lower',aspect='auto',cmap='plasma',vmin=0,vmax=3)
ax.set_yticks(range(21),[str(j) for j in range(1,22)]);ax.set_xticks(range(21),[str(j) for j in range(1,22)])
ax.set(xlabel='Position L du chiffre ajouté (depuis les unités)',ylabel='Longueur initiale',title='Superposition Φ–Ψ : excès de délai H−L=ν₂(a) ; cases blanches : chiffre nul ou absent')
fig.colorbar(im,ax=ax,label='Nombre supplémentaire de transitions U')
fig.tight_layout();fig.savefig(RootGraphs/'Matrice_Jonctions_Superposition.png',dpi=160);plt.close(fig)

# summary MD with 21 cases, full event tables individual
lines=[
'# Syracuse Φ–Ψ — Analyse comparative de 21 trajectoires records (1 à 21 chiffres)',
'', '**Objet :** décomposer exactement chaque record fourni en créations inédites de tête, remontées, pertes, mots I/P et jonctions de suffixes de droite à gauche.',
'', '## Conventions et vérification',
'', '- `I` : transformation classique impaire `3n+1`. `P` : division `n/2`.',
'- `U(n)` : `(3n+1)/2` si impair et `n/2` si pair.',
'- `N+` : longueur du maximum moins longueur initiale. Une première *longueur maximale* peut survenir avant la *valeur numérique maximale*.',
'- `H=L+ν₂(a)` concerne la première divergence de **parité sous U** des suffixes `S_L=N mod 10^L` et `S_(L+1)=S_L+a10^L`; ce n’est pas l’instant d’une nouvelle tête sur la trajectoire entière.',
'- Trajectoires calculées en arithmétique entière jusqu’à 1 ; colonnes « jusqu’au maximum » arrêtées au premier maximum numérique.',
'- Les 42 valeurs de gains classique et accéléré du tableau de départ ont été retrouvées exactement.',
'', '## 1. Comparatif des 21 records',
'', '| Chiffres | Nombre initial | N+ C | N+ U | Premier rang longueur max | Rang valeur max | I | P | Montées | Pertes | Têtes perdues aussitôt |',
'|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|'
]
for s in summary:
    lines.append(f"| {s['chiffres_initiaux']} | `{s['nombre_initial']}` | +{s['gain_classique']} | +{s['gain_accelere']} | {s['rang_premier_franchissement_longueur_max']} | {s['rang_premiere_valeur_max']} | {s['iterations_I_jusquau_max']} | {s['iterations_P_jusquau_max']} | {s['montées_locales_jusquau_max']} | {s['pertes_locales_jusquau_max']} | {s['tetes_perdues_immediatement']}/{s['nouvelles_tetes']} |")
lines += [
'', '## 2. Identités universelles employées',
'', 'Pour chaque trajectoire classique, chaque variation de longueur vaut `-1`, `0` ou `+1` :',
'', '```text', 'N+ = #(montées locales de longueur) − #(pertes locales de longueur)', '```',
'', 'La création d’une tête à la frontière `10^L` lors d’une étape impaire est équivalente à `3n+1 >= 10^L`. La tête reste après la division suivante si et seulement si `3n+1 >= 2×10^L`.',
'', 'La relation de superposition exacte (jusqu’au premier rang de divergence) est :',
'', '```text', 'S_(L+1) = S_L + a×10^L', 'H = L + ν₂(a)       (si a ≠ 0)', 'U^h(S_(L+1)) − U^h(S_L) = a×10^L×3^(m_h)/2^h   (0<=h<=H)', '```',
'', 'Elle établit la première divergence de parité, mais **n’établit pas** que les suffixes causent à eux seuls l’apparition d’une nouvelle tête sur la trajectoire initiale.',
'', '## 3. Principaux résultats comparatifs',
'', f"- Premières créations de tête, somme sur les 21 trajectoires : **{sum(s['nouvelles_tetes'] for s in summary)}** ; toutes les montées locales avant le maximum : **{sum(s['montées_locales_jusquau_max'] for s in summary)}** ; pertes : **{sum(s['pertes_locales_jusquau_max'] for s in summary)}**.",
 f"- Créations temporaires immédiatement perdues : **{sum(s['tetes_perdues_immediatement'] for s in summary)}** sur **{sum(s['nouvelles_tetes'] for s in summary)}** créations inédites ; les autres persistent au moins après une division.",
 f"- Jonctions décimales comparées : **{len(joins_all)}**, dont **{sum(j['chiffre_ajoute_a']!=0 for j in joins_all)}** ajoutent un chiffre non nul.",
 f"- Corridors complets `I^rP^t` avant le maximum numérique (opérateur U) : **{len(odd_blocks_all)}**.",
 '', '## 4. Représentations comparatives',
 '', '![Gains](graphiques/Comparatif_Gains_21_Records.png)',
 '', '![Montées et pertes](graphiques/Comparatif_Montees_Pertes.png)',
 '', '![Chronologie des rangs de maximum](graphiques/Comparatif_Rangs_Maxima.png)',
 '', '![Matrice chronologique des créations de tête](graphiques/Matrice_Chronologie_21_Trajectoires.png)',
 '', '![Matrice des jonctions](graphiques/Matrice_Jonctions_Superposition.png)',
 '', '## 5. Limite logique',
 '', 'Les égalités de composition, les franchissements et les délais de divergence sont exacts sur tout horizon fini. Le fait de les vérifier pour 21 trajectoires records ne constitue pas une démonstration des comportements asymptotiques pour tous les nombres.',
 '', '## 6. Cas individuels',
 '']
for s,m,js,cs in case_data:
    d=s['chiffres_initiaux'];tag=f"{d:02d}_chiffres_{s['nombre_initial']}"
    lines.append(f"- [{d} chiffres : `{s['nombre_initial']}`](cas_individuels/{tag}_rapport.md) — +{s['gain_classique']}, {len(m)} nouvelles têtes, {len(js)} jonctions.")
lines += ['', '## 7. Datasets', '', '- `donnees/synthese_21_records.csv` : synthèse quantitative ;', '- `donnees/creations_tete_tous_records.csv` : toutes les premières créations et leurs mots d’opérations I/P ;', '- `donnees/montees_locales_tous_records.csv` : toutes les montées, y compris les réapparitions ;', '- `donnees/jonctions_superposition_tous_records.csv` : superposition de tous les suffixes ;', '- `donnees/corridors_termines_avant_max.csv` : corridors U complets avec r, t, r′ ;','- `donnees/etats_tous_records_complets.csv` : trajectoires entières jusqu’à 1 pour chaque nombre.']
(RootReport:=ROOT/'Rapport_Comparatif_21_Records.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')

for s,events,joins,corridors in case_data:
    d=s['chiffres_initiaux'];n=s['nombre_initial'];tag=f'{d:02d}_chiffres_{n}'
    doc=[f'# Cas {d} chiffres — {group(int(n))}', '',
      f"- Départ : `{n}` ; maximum classique : `{s['maximum_classique']}` ; **N+ = +{s['gain_classique']}**.",
      f"- Premier rang où la longueur maximale est atteinte : **{s['rang_premier_franchissement_longueur_max']}** ; premier rang du maximum numérique : **{s['rang_premiere_valeur_max']}**.",
      f"- De t=0 au maximum : **I={s['iterations_I_jusquau_max']}**, **P={s['iterations_P_jusquau_max']}**, **{s['montées_locales_jusquau_max']}** montées, **{s['pertes_locales_jusquau_max']}** pertes, **{s['neutres_jusquau_max']}** pas neutres.",
      f"- Nouvelles têtes immédiatement perdues après division : **{s['tetes_perdues_immediatement']}/{s['nouvelles_tetes']}**.",
      f"- Trajectoire entière : {s['iterations_completes_jusqua_un']} opérations classiques avant d'atteindre 1.",
      '',f'![Chronologie](../graphiques/{tag}_longueurs.png)',
      '', '## 1. Chaque création inédite de tête, y compris les opérations contributrices',
      '', '| Gain | Nouvelle longueur | Rang | Intervalle | I | P | Montées | Pertes | ν₂ | Perte immédiate | Valeur atteinte |',
      '|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|---:|']
    for r in events:
        doc.append(f"| +{r['gain']} | {r['nouvelle_longueur']} | {r['rang_classique']} | {r['rang_record_precedent']+1}–{r['rang_classique']} | {r['operations_I']} | {r['operations_P']} | {r['montees_intervalle']} | {r['pertes_intervalle']} | {r['v2_3n_plus_1']} | {'oui' if r['tete_perdue_a_division_suivante'] else 'non'} | `{r['nombre_apres_3n_plus_1']}` |")
    doc += ['', '## 2. Mots exacts I/P entre deux records', '', 'La dernière opération de chaque mot est toujours `I`, c’est-à-dire une création par multiplication et addition.']
    for r in events:doc.append(f"- **+{r['gain']}**, rangs {r['rang_record_precedent']+1}–{r['rang_classique']} : `{r['mot_IP_intervalle']}`")
    doc += ['', '## 3. Jonctions de superposition entre suffixes successifs', '',
            '| Position L | Chiffre ajouté a | H=L+ν₂(a) | S_L | S_(L+1) |',
            '|---:|---:|---:|---:|---:|']
    for j in joins:
        doc.append(f"| {j['position_L']} | {j['chiffre_ajoute_a']} | {j['premier_rang_divergence_parite_U'] if j['chiffre_ajoute_a'] else 'aucun (a=0)'} | `{j['suffixe_L']}` | `{j['suffixe_L_plus_1']}` |")
    doc += ['', 'La jonction `H` exprime uniquement la première divergence de parité de deux trajectoires sous `U`. Ce n’est pas le rang de création d’une tête de la trajectoire principale.',
           '', '## 4. Corridors Φ–Ψ I^r P^t complets avant le maximum', '',
           '| Rang classique début–fin | r | t | r′ suivant | Direction impair→impair | Variation de longueur |',
           '|---|---:|---:|---:|---|---:|']
    for co in corridors:doc.append(f"| {co['rang_classique_debut']}–{co['rang_classique_fin']} | {co['r_impaires']} | {co['t_paires']} | {co['r_suivant']} | {co['direction']} | {co['gain_longueur_impair_a_impair']:+d} |")
    if not corridors:doc.append('| Aucun corridor complet avant le maximum | — | — | — | — | — |')
    doc += ['', '## 5. Portée du résultat', '', 'Analyse arithmétique exacte de ce départ et de ses suffixes à horizon fini, sans extrapolation de convergence universelle.']
    (RootCases/f'{tag}_rapport.md').write_text('\n'.join(doc)+'\n',encoding='utf-8')

# Write compact machine-readable JSON for verification.
control={'input_numbers':len(STARTS),'summary':[{'digits':s['chiffres_initiaux'],'start':s['nombre_initial'],'classical_gain':s['gain_classique'],'accelerated_gain':s['gain_accelere'],'peak_rank':s['rang_premiere_valeur_max']} for s in summary],
         'totals':{'first_head_creations':sum(s['nouvelles_tetes'] for s in summary),
                   'local_rises':sum(s['montées_locales_jusquau_max'] for s in summary),
                   'local_falls':sum(s['pertes_locales_jusquau_max'] for s in summary),
                   'initial_digit_sum':sum(s['gain_classique'] for s in summary),
                   'superposition_junctions':len(joins_all),
                   'nonzero_junctions':sum(j['chiffre_ajoute_a']!=0 for j in joins_all),
                   'complete_corridors':len(odd_blocks_all)}}
assert control['totals']['first_head_creations']==control['totals']['initial_digit_sum']
assert control['totals']['local_rises']-control['totals']['local_falls']==control['totals']['initial_digit_sum']
(RootData/'controle.json').write_text(json.dumps(control,ensure_ascii=False,indent=2),encoding='utf-8')

# copy this source into root for reproducibility
from shutil import copy2
copy2(__file__,ROOT/'analyse_syracuse_21_records.py')
ZIP=Path('/mnt/data/Syracuse_PhiPsi_21_Records_Dossier.zip')
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(ROOT.parent))
print(json.dumps({'zip':str(ZIP),'report':str(RootReport),'summary':str(RootData/'synthese_21_records.csv'),'controls':control['totals'],'num_files':len(list(ROOT.rglob('*'))),'zip_bytes':ZIP.stat().st_size},ensure_ascii=False,indent=2))
