from pathlib import Path
from collections import Counter
import csv,json,zipfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path('/mnt/data/Syracuse_PhiPsi_21_Records'); DATA=ROOT/'donnees';GRAPHS=ROOT/'graphiques';CASES=ROOT/'cas_individuels'
STARTS=[7,27,703,9663,77671,704511,6631675,80049391,319804831,8528817511,77566362559,871673828443,9016346070511,64848224337147,737482236053119,8562235014026655,93264792503458119,891563131061253151,1980976057694848447,71149323674102624415,274133054632352106267]

def C(n):return 3*n+1 if n&1 else n//2

def peak_data(n):
    peak=n; tpeak=0; t=0
    while n!=1:
        n=C(n);t+=1
        if n>peak:peak=n;tpeak=t
    return peak,tpeak
cache={}
def memo(n):
    if n not in cache:cache[n]=peak_data(n)
    return cache[n]

def writer(path,data):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
rows=[];grouped={}
for start in STARTS:
    d=len(str(start));local=[]
    for L in range(1,d):
        a=(start//10**L)%10;lo=start%10**L;hi=start%10**(L+1)
        max_lo,t_lo=memo(lo);max_hi,t_hi=memo(hi)
        gain_lo=len(str(max_lo))-len(str(lo))
        gain_hi=len(str(max_hi))-len(str(hi))
        row={'chiffres_initiaux':d,'nombre_initial':start,'position_L':L,'chiffre_ajoute':a,
            'suffixe_avant':lo,'suffixe_apres':hi,'H_divergence_parite_U':L+((a&-a).bit_length()-1) if a else '',
            'Nplus_suffixe_avant':gain_lo,'Nplus_suffixe_apres':gain_hi,
            'delta_Nplus_apres_moins_avant':gain_hi-gain_lo,
            'max_classique_suffixe_avant':max_lo,'max_classique_suffixe_apres':max_hi,
            'rang_max_suffixe_avant':t_lo,'rang_max_suffixe_apres':t_hi,
            'variation_longueur_maximale_absolue':len(str(max_hi))-len(str(max_lo))}
        assert (a==0)==(lo==hi)
        if a==0:assert row['delta_Nplus_apres_moins_avant']==0
        local.append(row);rows.append(row)
    grouped[d]=local
    if local:
        writer(CASES/f'{d:02d}_chiffres_{start}_effets_jonctions.csv',local)
        path=CASES/f'{d:02d}_chiffres_{start}_rapport.md'
        text=path.read_text(encoding='utf-8')
        insert=['','## 4 bis. Effets mesurés de chaque jonction sur le gain maximal N+', '',
            'Cette comparaison est réalisée entre les **trajectoires complètes de deux suffixes successifs** ; elle ne démontre pas que le délai H détermine à lui seul le maximum après divergence de parité.',
            '', '| Position L | Chiffre a | H sous U | N+ avant | N+ après | ΔN+ |', '|---:|---:|---:|---:|---:|---:|']
        for r in local:
            insert.append(f"| {r['position_L']} | {r['chiffre_ajoute']} | {r['H_divergence_parite_U'] if r['chiffre_ajoute'] else 'aucun'} | +{r['Nplus_suffixe_avant']} | +{r['Nplus_suffixe_apres']} | {r['delta_Nplus_apres_moins_avant']:+d} |")
        insert += ['', 'L’ajout d’un chiffre peut modifier fortement le gain maximal sans modifier la loi locale des transitions : ce sont les trajectoires futures, après rupture de parité, qui diffèrent.', '']
        text=text.replace('## 5. Portée du résultat','\n'.join(insert)+'\n## 5. Portée du résultat')
        path.write_text(text,encoding='utf-8')

writer(DATA/'effets_jonctions_sur_gain_maximal_210.csv',rows)
impact=Counter(r['delta_Nplus_apres_moins_avant'] for r in rows)
arr=[[float('nan')]*21 for _ in range(21)]
for r in rows:
    arr[r['chiffres_initiaux']-1][r['position_L']-1]=r['delta_Nplus_apres_moins_avant']
fig,ax=plt.subplots(figsize=(12.8,7.1))
im=ax.imshow(arr,origin='lower',aspect='auto',cmap='coolwarm',vmin=-19,vmax=19)
ax.set_yticks(range(21),list(map(str,range(1,22))));ax.set_xticks(range(21),list(map(str,range(1,22))))
ax.set(xlabel='Position décimale ajoutée L (depuis les unités)',ylabel='Nombre de chiffres initial',title='Impact mesuré des 210 jonctions : variation de N+ entre suffixes')
fig.colorbar(im,ax=ax,label='N+(S_(L+1)) − N+(S_L)')
fig.tight_layout();fig.savefig(GRAPHS/'Matrice_Impact_Jonctions_Nplus.png',dpi=160);plt.close(fig)
report=ROOT/'Rapport_Comparatif_21_Records.md'
content=report.read_text(encoding='utf-8')
chapter=['','## 4 bis. Impact global des 210 jonctions sur N+', '',
 'La superposition Phi–Psi prévoit exactement la première divergence de parité sous U (`H=L+ν₂(a)`). Pour quantifier les effets ultérieurs, nous avons reconstruit les trajectoires de **chaque suffixe** jusqu’à 1 et mesuré `N+(S_(L+1))-N+(S_L)`.', '',
 f"- Sur **{len(rows)}** jonctions : **{impact[0]}** gardent le même gain N+, **{sum(v for k,v in impact.items() if k>0)}** l’augmentent, **{sum(v for k,v in impact.items() if k<0)}** le réduisent.",
 f"- Variation observée : **{min(impact)} à +{max(impact)}** positions de tête, relativement au gain du suffixe précédent.",
 '- Une jonction de chiffre nul produit `ΔN+=0`, puisque les deux nombres comparés sont alors identiques.',
 '', '![Impact des jonctions](graphiques/Matrice_Impact_Jonctions_Nplus.png)', '',
 '### Jonction supérieure de chaque record', '',
 '| Longueur finale | Chiffre de tête ajouté | H de première divergence sous U | N+ du suffixe antérieur | N+ du nombre complet | Variation |',
 '|---:|---:|---:|---:|---:|---:|']
for d in range(2,22):
    r=grouped[d][-1]
    chapter.append(f"| {d} | {r['chiffre_ajoute']} | {r['H_divergence_parite_U']} | +{r['Nplus_suffixe_avant']} | +{r['Nplus_suffixe_apres']} | {r['delta_Nplus_apres_moins_avant']:+d} |")
chapter += ['', '**Précaution logique :** ces variations ne sont pas des constantes universelles associées au chiffre `a` ou à `H` ; elles dépendent du nombre entier, et leurs valeurs ont été obtenues par itération exacte. Le résultat décrit les records sélectionnés, sans démontrer de loi de variation générale des maxima.', '', '- `donnees/effets_jonctions_sur_gain_maximal_210.csv` : toutes les valeurs, maxima, rangs et variations pour les 210 paires de suffixes.', '']
content=content.replace('## 5. Limite logique','\n'.join(chapter)+'\n## 5. Limite logique')
report.write_text(content,encoding='utf-8')
q=DATA/'controle.json';co=json.loads(q.read_text(encoding='utf-8'))
co['totals']['jonctions_gain_egal']=impact[0];co['totals']['jonctions_gain_augmente']=sum(v for k,v in impact.items() if k>0);co['totals']['jonctions_gain_diminue']=sum(v for k,v in impact.items() if k<0)
q.write_text(json.dumps(co,indent=2,ensure_ascii=False),encoding='utf-8')
from shutil import copy2
copy2(__file__,ROOT/'add_syracuse_jonctions_effects.py')
ZIP=Path('/mnt/data/Syracuse_PhiPsi_21_Records_Dossier.zip')
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(ROOT.parent))
print({'impact':dict(sorted(impact.items())),'zip_files':len(zipfile.ZipFile(ZIP).namelist()),'bytes':ZIP.stat().st_size})
