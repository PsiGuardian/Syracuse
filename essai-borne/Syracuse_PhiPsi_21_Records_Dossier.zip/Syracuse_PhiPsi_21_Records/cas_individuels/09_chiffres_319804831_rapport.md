# Cas 9 chiffres — 319 804 831

- Départ : `319804831` ; maximum classique : `1414236446719942480` ; **N+ = +10**.
- Premier rang où la longueur maximale est atteinte : **167** ; premier rang du maximum numérique : **167**.
- De t=0 au maximum : **I=77**, **P=90**, **31** montées, **21** pertes, **115** pas neutres.
- Nouvelles têtes immédiatement perdues après division : **10/10**.
- Trajectoire entière : 592 opérations classiques avant d'atteindre 1.

![Chronologie](../graphiques/09_chiffres_319804831_longueurs.png)

## 1. Chaque création inédite de tête, y compris les opérations contributrices

| Gain | Nouvelle longueur | Rang | Intervalle | I | P | Montées | Pertes | ν₂ | Perte immédiate | Valeur atteinte |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|---:|
| +1 | 10 | 3 | 1–3 | 2 | 1 | 1 | 0 | 1 | oui | `1439121742` |
| +2 | 11 | 23 | 4–23 | 9 | 11 | 2 | 1 | 1 | oui | `13831168606` |
| +3 | 12 | 51 | 24–51 | 12 | 16 | 4 | 3 | 1 | oui | `112158967246` |
| +4 | 13 | 71 | 52–71 | 9 | 11 | 4 | 3 | 2 | oui | `1077941871268` |
| +5 | 14 | 96 | 72–96 | 11 | 14 | 3 | 2 | 1 | oui | `11654917521406` |
| +6 | 15 | 108 | 97–108 | 6 | 6 | 3 | 2 | 1 | oui | `132756794892286` |
| +7 | 16 | 118 | 109–118 | 5 | 5 | 3 | 2 | 1 | oui | `1008121911213310` |
| +8 | 17 | 130 | 119–130 | 6 | 6 | 3 | 2 | 1 | oui | `11483138644914130` |
| +9 | 18 | 155 | 131–155 | 11 | 14 | 5 | 4 | 1 | oui | `124157932222326910` |
| +10 | 19 | 167 | 156–167 | 6 | 6 | 3 | 2 | 4 | oui | `1414236446719942480` |

## 2. Mots exacts I/P entre deux records

La dernière opération de chaque mot est toujours `I`, c’est-à-dire une création par multiplication et addition.
- **+1**, rangs 1–3 : `IPI`
- **+2**, rangs 4–23 : `PIPIPIPPIPIPPIPIPIPI`
- **+3**, rangs 24–51 : `PIPIPIPIPPIPPIPPIPPIPIPIPIPI`
- **+4**, rangs 52–71 : `PIPIPIPPIPIPIPPIPIPI`
- **+5**, rangs 72–96 : `PPIPPIPIPIPIPIPIPIPPIPIPI`
- **+6**, rangs 97–108 : `PIPIPIPIPIPI`
- **+7**, rangs 109–118 : `PIPIPIPIPI`
- **+8**, rangs 119–130 : `PIPIPIPIPIPI`
- **+9**, rangs 131–155 : `PIPPIPIPIPIPPIPIPIPPIPIPI`
- **+10**, rangs 156–167 : `PIPIPIPIPIPI`

## 3. Jonctions de superposition entre suffixes successifs

| Position L | Chiffre ajouté a | H=L+ν₂(a) | S_L | S_(L+1) |
|---:|---:|---:|---:|---:|
| 1 | 3 | 1 | `1` | `31` |
| 2 | 8 | 5 | `31` | `831` |
| 3 | 4 | 5 | `831` | `4831` |
| 4 | 0 | aucun (a=0) | `4831` | `4831` |
| 5 | 8 | 8 | `4831` | `804831` |
| 6 | 9 | 6 | `804831` | `9804831` |
| 7 | 1 | 7 | `9804831` | `19804831` |
| 8 | 3 | 8 | `19804831` | `319804831` |

La jonction `H` exprime uniquement la première divergence de parité de deux trajectoires sous `U`. Ce n’est pas le rang de création d’une tête de la trajectoire principale.

## 4. Corridors Φ–Ψ I^r P^t complets avant le maximum

| Rang classique début–fin | r | t | r′ suivant | Direction impair→impair | Variation de longueur |
|---|---:|---:|---:|---|---:|
| 0–11 | 5 | 1 | 2 | montee | +1 |
| 11–16 | 2 | 1 | 8 | montee | +0 |
| 16–33 | 8 | 1 | 1 | montee | +1 |
| 33–36 | 1 | 1 | 1 | descente | +0 |
| 36–39 | 1 | 1 | 1 | descente | -1 |
| 39–42 | 1 | 1 | 8 | descente | +0 |
| 42–59 | 8 | 1 | 3 | montee | +1 |
| 59–66 | 3 | 1 | 3 | montee | +1 |
| 66–73 | 3 | 1 | 1 | montee | +0 |
| 73–76 | 1 | 1 | 7 | descente | +0 |
| 76–91 | 7 | 1 | 21 | montee | +1 |
| 91–134 | 21 | 1 | 4 | montee | +3 |
| 134–143 | 4 | 1 | 3 | montee | +1 |
| 143–150 | 3 | 1 | 9 | montee | +0 |


## 4 bis. Effets mesurés de chaque jonction sur le gain maximal N+

Cette comparaison est réalisée entre les **trajectoires complètes de deux suffixes successifs** ; elle ne démontre pas que le délai H détermine à lui seul le maximum après divergence de parité.

| Position L | Chiffre a | H sous U | N+ avant | N+ après | ΔN+ |
|---:|---:|---:|---:|---:|---:|
| 1 | 3 | 1 | +0 | +2 | +2 |
| 2 | 8 | 5 | +2 | +2 | +0 |
| 3 | 4 | 5 | +2 | +1 | -1 |
| 4 | 0 | aucun | +1 | +1 | +0 |
| 5 | 8 | 8 | +1 | +2 | +1 |
| 6 | 9 | 6 | +2 | +2 | +0 |
| 7 | 1 | 7 | +2 | +3 | +1 |
| 8 | 3 | 8 | +3 | +10 | +7 |

L’ajout d’un chiffre peut modifier fortement le gain maximal sans modifier la loi locale des transitions : ce sont les trajectoires futures, après rupture de parité, qui diffèrent.

## 5. Portée du résultat

Analyse arithmétique exacte de ce départ et de ses suffixes à horizon fini, sans extrapolation de convergence universelle.
