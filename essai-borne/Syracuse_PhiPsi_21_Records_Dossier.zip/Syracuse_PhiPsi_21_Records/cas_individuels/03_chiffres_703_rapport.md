# Cas 3 chiffres — 703

- Départ : `703` ; maximum classique : `250504` ; **N+ = +3**.
- Premier rang où la longueur maximale est atteinte : **75** ; premier rang du maximum numérique : **82**.
- De t=0 au maximum : **I=35**, **P=47**, **15** montées, **12** pertes, **55** pas neutres.
- Nouvelles têtes immédiatement perdues après division : **2/3**.
- Trajectoire entière : 170 opérations classiques avant d'atteindre 1.

![Chronologie](../graphiques/03_chiffres_703_longueurs.png)

## 1. Chaque création inédite de tête, y compris les opérations contributrices

| Gain | Nouvelle longueur | Rang | Intervalle | I | P | Montées | Pertes | ν₂ | Perte immédiate | Valeur atteinte |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|---:|
| +1 | 4 | 1 | 1–1 | 1 | 0 | 1 | 0 | 1 | non | `2110` |
| +2 | 5 | 9 | 2–9 | 4 | 4 | 1 | 0 | 1 | oui | `10690` |
| +3 | 6 | 75 | 10–75 | 27 | 39 | 10 | 9 | 2 | oui | `148444` |

## 2. Mots exacts I/P entre deux records

La dernière opération de chaque mot est toujours `I`, c’est-à-dire une création par multiplication et addition.
- **+1**, rangs 1–1 : `I`
- **+2**, rangs 2–9 : `PIPIPIPI`
- **+3**, rangs 10–75 : `PIPPIPPIPIPIPIPIPIPPIPIPPIPPIPIPIPPPIPPPPIPIPIPIPPIPIPIPIPIPPIPIPI`

## 3. Jonctions de superposition entre suffixes successifs

| Position L | Chiffre ajouté a | H=L+ν₂(a) | S_L | S_(L+1) |
|---:|---:|---:|---:|---:|
| 1 | 0 | aucun (a=0) | `3` | `3` |
| 2 | 7 | 2 | `3` | `703` |

La jonction `H` exprime uniquement la première divergence de parité de deux trajectoires sous `U`. Ce n’est pas le rang de création d’une tête de la trajectoire principale.

## 4. Corridors Φ–Ψ I^r P^t complets avant le maximum

| Rang classique début–fin | r | t | r′ suivant | Direction impair→impair | Variation de longueur |
|---|---:|---:|---:|---|---:|
| 0–13 | 6 | 1 | 1 | montee | +1 |
| 13–16 | 1 | 1 | 6 | descente | +0 |
| 16–29 | 6 | 1 | 2 | montee | +1 |
| 29–34 | 2 | 1 | 1 | montee | +0 |
| 34–37 | 1 | 1 | 3 | descente | +0 |
| 37–45 | 3 | 2 | 1 | descente | +0 |
| 45–50 | 1 | 3 | 4 | descente | -1 |
| 50–59 | 4 | 1 | 5 | montee | +0 |
| 59–70 | 5 | 1 | 3 | montee | +1 |
| 70–77 | 3 | 1 | 3 | montee | +0 |


## 4 bis. Effets mesurés de chaque jonction sur le gain maximal N+

Cette comparaison est réalisée entre les **trajectoires complètes de deux suffixes successifs** ; elle ne démontre pas que le délai H détermine à lui seul le maximum après divergence de parité.

| Position L | Chiffre a | H sous U | N+ avant | N+ après | ΔN+ |
|---:|---:|---:|---:|---:|---:|
| 1 | 0 | aucun | +1 | +1 | +0 |
| 2 | 7 | 2 | +1 | +3 | +2 |

L’ajout d’un chiffre peut modifier fortement le gain maximal sans modifier la loi locale des transitions : ce sont les trajectoires futures, après rupture de parité, qui diffèrent.

## 5. Portée du résultat

Analyse arithmétique exacte de ce départ et de ses suffixes à horizon fini, sans extrapolation de convergence universelle.
