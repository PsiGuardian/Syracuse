# Cas 11 chiffres — 77 566 362 559

- Départ : `77566362559` ; maximum classique : `916613029076867799856` ; **N+ = +10**.
- Premier rang où la longueur maximale est atteinte : **277** ; premier rang du maximum numérique : **300**.
- De t=0 au maximum : **I=129**, **P=171**, **67** montées, **57** pertes, **176** pas neutres.
- Nouvelles têtes immédiatement perdues après division : **9/10**.
- Trajectoire entière : 755 opérations classiques avant d'atteindre 1.

![Chronologie](../graphiques/11_chiffres_77566362559_longueurs.png)

## 1. Chaque création inédite de tête, y compris les opérations contributrices

| Gain | Nouvelle longueur | Rang | Intervalle | I | P | Montées | Pertes | ν₂ | Perte immédiate | Valeur atteinte |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|---:|
| +1 | 12 | 1 | 1–1 | 1 | 0 | 1 | 0 | 1 | non | `232699087678` |
| +2 | 13 | 9 | 2–9 | 4 | 4 | 1 | 0 | 1 | oui | `1178039131378` |
| +3 | 14 | 55 | 10–55 | 19 | 27 | 11 | 10 | 2 | oui | `10201256640484` |
| +4 | 15 | 116 | 56–116 | 25 | 36 | 9 | 8 | 1 | oui | `125778148554742` |
| +5 | 16 | 144 | 117–144 | 12 | 16 | 7 | 6 | 1 | oui | `1019953385102590` |
| +6 | 17 | 156 | 145–156 | 6 | 6 | 3 | 2 | 1 | oui | `11617906527184210` |
| +7 | 18 | 173 | 157–173 | 8 | 9 | 5 | 4 | 1 | oui | `148877118603233638` |
| +8 | 19 | 209 | 174–209 | 15 | 21 | 8 | 7 | 1 | oui | `1018630947716603134` |
| +9 | 20 | 221 | 210–221 | 6 | 6 | 3 | 2 | 1 | oui | `11602843138834432594` |
| +10 | 21 | 277 | 222–277 | 23 | 33 | 14 | 13 | 2 | oui | `127163778119827618012` |

## 2. Mots exacts I/P entre deux records

La dernière opération de chaque mot est toujours `I`, c’est-à-dire une création par multiplication et addition.
- **+1**, rangs 1–1 : `I`
- **+2**, rangs 2–9 : `PIPIPIPI`
- **+3**, rangs 10–55 : `PIPPIPIPPIPIPIPPPIPIPIPIPIPPIPPPPIPIPIPIPIPIPI`
- **+4**, rangs 56–116 : `PPIPPIPIPPIPIPPIPIPPIPPIPIPPIPIPIPIPIPPIPPPIPIPIPIPPIPIPIPIPI`
- **+5**, rangs 117–144 : `PIPIPPIPIPPIPIPPIPPIPIPIPIPI`
- **+6**, rangs 145–156 : `PIPIPIPIPIPI`
- **+7**, rangs 157–173 : `PIPPIPIPIPIPIPIPI`
- **+8**, rangs 174–209 : `PIPIPPPIPPPPIPIPIPIPIPIPPIPIPIPIPIPI`
- **+9**, rangs 210–221 : `PIPIPIPIPIPI`
- **+10**, rangs 222–277 : `PIPPIPIPIPIPIPPPIPPIPIPIPIPIPPPIPPPIPIPPIPPIPIPIPIPIPIPI`

## 3. Jonctions de superposition entre suffixes successifs

| Position L | Chiffre ajouté a | H=L+ν₂(a) | S_L | S_(L+1) |
|---:|---:|---:|---:|---:|
| 1 | 5 | 1 | `9` | `59` |
| 2 | 5 | 2 | `59` | `559` |
| 3 | 2 | 4 | `559` | `2559` |
| 4 | 6 | 5 | `2559` | `62559` |
| 5 | 3 | 5 | `62559` | `362559` |
| 6 | 6 | 7 | `362559` | `6362559` |
| 7 | 6 | 8 | `6362559` | `66362559` |
| 8 | 5 | 8 | `66362559` | `566362559` |
| 9 | 7 | 9 | `566362559` | `7566362559` |
| 10 | 7 | 10 | `7566362559` | `77566362559` |

La jonction `H` exprime uniquement la première divergence de parité de deux trajectoires sous `U`. Ce n’est pas le rang de création d’une tête de la trajectoire principale.

## 4. Corridors Φ–Ψ I^r P^t complets avant le maximum

| Rang classique début–fin | r | t | r′ suivant | Direction impair→impair | Variation de longueur |
|---|---:|---:|---:|---|---:|
| 0–13 | 6 | 1 | 2 | montee | +1 |
| 13–18 | 2 | 1 | 3 | montee | +0 |
| 18–26 | 3 | 2 | 5 | descente | +0 |
| 26–37 | 5 | 1 | 1 | montee | +1 |
| 37–42 | 1 | 3 | 7 | descente | -1 |
| 42–57 | 7 | 1 | 1 | montee | +1 |
| 57–60 | 1 | 1 | 2 | descente | +0 |
| 60–65 | 2 | 1 | 2 | montee | +0 |
| 65–70 | 2 | 1 | 2 | montee | +0 |
| 70–75 | 2 | 1 | 1 | montee | +0 |
| 75–78 | 1 | 1 | 2 | descente | +0 |
| 78–83 | 2 | 1 | 5 | montee | +0 |
| 83–94 | 5 | 1 | 1 | montee | +0 |
| 94–98 | 1 | 2 | 4 | descente | +0 |
| 98–107 | 4 | 1 | 7 | montee | +0 |
| 107–122 | 7 | 1 | 2 | montee | +1 |
| 122–127 | 2 | 1 | 2 | montee | +0 |
| 127–132 | 2 | 1 | 1 | montee | +0 |
| 132–135 | 1 | 1 | 12 | descente | +0 |
| 135–160 | 12 | 1 | 9 | montee | +2 |
| 160–180 | 9 | 2 | 1 | montee | +1 |
| 180–185 | 1 | 3 | 6 | descente | -1 |
| 185–198 | 6 | 1 | 13 | montee | +1 |
| 198–225 | 13 | 1 | 5 | montee | +2 |
| 225–237 | 5 | 2 | 1 | montee | +0 |
| 237–240 | 1 | 1 | 5 | descente | +0 |
| 240–252 | 5 | 2 | 1 | montee | +1 |
| 252–256 | 1 | 2 | 2 | descente | -1 |
| 256–261 | 2 | 1 | 1 | montee | +0 |
| 261–264 | 1 | 1 | 7 | descente | +0 |
| 264–279 | 7 | 1 | 3 | montee | +1 |
| 279–287 | 3 | 2 | 7 | descente | +0 |


## 4 bis. Effets mesurés de chaque jonction sur le gain maximal N+

Cette comparaison est réalisée entre les **trajectoires complètes de deux suffixes successifs** ; elle ne démontre pas que le délai H détermine à lui seul le maximum après divergence de parité.

| Position L | Chiffre a | H sous U | N+ avant | N+ après | ΔN+ |
|---:|---:|---:|---:|---:|---:|
| 1 | 5 | 1 | +1 | +1 | +0 |
| 2 | 5 | 2 | +1 | +1 | +0 |
| 3 | 2 | 4 | +1 | +2 | +1 |
| 4 | 6 | 5 | +2 | +1 | -1 |
| 5 | 3 | 5 | +1 | +2 | +1 |
| 6 | 6 | 7 | +2 | +2 | +0 |
| 7 | 6 | 8 | +2 | +2 | +0 |
| 8 | 5 | 8 | +2 | +2 | +0 |
| 9 | 7 | 9 | +2 | +2 | +0 |
| 10 | 7 | 10 | +2 | +10 | +8 |

L’ajout d’un chiffre peut modifier fortement le gain maximal sans modifier la loi locale des transitions : ce sont les trajectoires futures, après rupture de parité, qui diffèrent.

## 5. Portée du résultat

Analyse arithmétique exacte de ce départ et de ses suffixes à horizon fini, sans extrapolation de convergence universelle.
