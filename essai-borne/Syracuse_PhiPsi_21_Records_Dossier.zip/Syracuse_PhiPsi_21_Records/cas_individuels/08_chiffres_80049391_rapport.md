# Cas 8 chiffres — 80 049 391

- Départ : `80049391` ; maximum classique : `2185143829170100` ; **N+ = +8**.
- Premier rang où la longueur maximale est atteinte : **162** ; premier rang du maximum numérique : **164**.
- De t=0 au maximum : **I=73**, **P=91**, **36** montées, **28** pertes, **100** pas neutres.
- Nouvelles têtes immédiatement perdues après division : **7/8**.
- Trajectoire entière : 572 opérations classiques avant d'atteindre 1.

![Chronologie](../graphiques/08_chiffres_80049391_longueurs.png)

## 1. Chaque création inédite de tête, y compris les opérations contributrices

| Gain | Nouvelle longueur | Rang | Intervalle | I | P | Montées | Pertes | ν₂ | Perte immédiate | Valeur atteinte |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|---:|
| +1 | 9 | 1 | 1–1 | 1 | 0 | 1 | 0 | 1 | non | `240148174` |
| +2 | 10 | 14 | 2–14 | 6 | 7 | 1 | 0 | 1 | oui | `1367718910` |
| +3 | 11 | 24 | 15–24 | 5 | 5 | 2 | 1 | 1 | oui | `10386115486` |
| +4 | 12 | 80 | 25–80 | 23 | 33 | 11 | 10 | 2 | oui | `113828797852` |
| +5 | 13 | 100 | 81–100 | 9 | 11 | 5 | 4 | 1 | oui | `1093990345810` |
| +6 | 14 | 120 | 101–120 | 9 | 11 | 5 | 4 | 1 | oui | `10514166004222` |
| +7 | 15 | 132 | 121–132 | 6 | 6 | 3 | 2 | 1 | oui | `119762922141862` |
| +8 | 16 | 162 | 133–162 | 13 | 17 | 7 | 6 | 1 | oui | `1456762552780066` |

## 2. Mots exacts I/P entre deux records

La dernière opération de chaque mot est toujours `I`, c’est-à-dire une création par multiplication et addition.
- **+1**, rangs 1–1 : `I`
- **+2**, rangs 2–14 : `PIPIPIPPIPIPI`
- **+3**, rangs 15–24 : `PIPIPIPIPI`
- **+4**, rangs 25–80 : `PIPIPIPIPPPIPIPPIPIPIPPIPIPPPIPPIPIPIPPIPIPPIPIPIPPIPIPI`
- **+5**, rangs 81–100 : `PPIPIPIPPIPIPIPIPIPI`
- **+6**, rangs 101–120 : `PIPPIPIPIPIPIPPIPIPI`
- **+7**, rangs 121–132 : `PIPIPIPIPIPI`
- **+8**, rangs 133–162 : `PIPIPPPIPIPIPIPPIPIPIPPIPIPIPI`

## 3. Jonctions de superposition entre suffixes successifs

| Position L | Chiffre ajouté a | H=L+ν₂(a) | S_L | S_(L+1) |
|---:|---:|---:|---:|---:|
| 1 | 9 | 1 | `1` | `91` |
| 2 | 3 | 2 | `91` | `391` |
| 3 | 9 | 3 | `391` | `9391` |
| 4 | 4 | 6 | `9391` | `49391` |
| 5 | 0 | aucun (a=0) | `49391` | `49391` |
| 6 | 0 | aucun (a=0) | `49391` | `49391` |
| 7 | 8 | 10 | `49391` | `80049391` |

La jonction `H` exprime uniquement la première divergence de parité de deux trajectoires sous `U`. Ce n’est pas le rang de création d’une tête de la trajectoire principale.

## 4. Corridors Φ–Ψ I^r P^t complets avant le maximum

| Rang classique début–fin | r | t | r′ suivant | Direction impair→impair | Variation de longueur |
|---|---:|---:|---:|---|---:|
| 0–9 | 4 | 1 | 12 | montee | +1 |
| 9–35 | 12 | 2 | 2 | montee | +1 |
| 35–40 | 2 | 1 | 3 | montee | +0 |
| 40–47 | 3 | 1 | 2 | montee | +1 |
| 47–53 | 2 | 2 | 1 | descente | -1 |
| 53–56 | 1 | 1 | 3 | descente | +0 |
| 56–63 | 3 | 1 | 2 | montee | +0 |
| 63–68 | 2 | 1 | 3 | montee | +0 |
| 68–75 | 3 | 1 | 3 | montee | +1 |
| 75–82 | 3 | 1 | 3 | montee | +0 |
| 82–89 | 3 | 1 | 7 | montee | +0 |
| 89–104 | 7 | 1 | 5 | montee | +1 |
| 104–115 | 5 | 1 | 11 | montee | +1 |
| 115–139 | 11 | 2 | 4 | montee | +1 |
| 139–148 | 4 | 1 | 3 | montee | +0 |
| 148–155 | 3 | 1 | 5 | montee | +1 |


## 4 bis. Effets mesurés de chaque jonction sur le gain maximal N+

Cette comparaison est réalisée entre les **trajectoires complètes de deux suffixes successifs** ; elle ne démontre pas que le délai H détermine à lui seul le maximum après divergence de parité.

| Position L | Chiffre a | H sous U | N+ avant | N+ après | ΔN+ |
|---:|---:|---:|---:|---:|---:|
| 1 | 9 | 1 | +0 | +2 | +2 |
| 2 | 3 | 2 | +2 | +1 | -1 |
| 3 | 9 | 3 | +1 | +1 | +0 |
| 4 | 4 | 6 | +1 | +2 | +1 |
| 5 | 0 | aucun | +2 | +2 | +0 |
| 6 | 0 | aucun | +2 | +2 | +0 |
| 7 | 8 | 10 | +2 | +8 | +6 |

L’ajout d’un chiffre peut modifier fortement le gain maximal sans modifier la loi locale des transitions : ce sont les trajectoires futures, après rupture de parité, qui diffèrent.

## 5. Portée du résultat

Analyse arithmétique exacte de ce départ et de ses suffixes à horizon fini, sans extrapolation de convergence universelle.
