# Cas 4 chiffres — 9 663

- Départ : `9663` ; maximum classique : `27114424` ; **N+ = +4**.
- Premier rang où la longueur maximale est atteinte : **44** ; premier rang du maximum numérique : **48**.
- De t=0 au maximum : **I=23**, **P=25**, **13** montées, **9** pertes, **26** pas neutres.
- Nouvelles têtes immédiatement perdues après division : **3/4**.
- Trajectoire entière : 184 opérations classiques avant d'atteindre 1.

![Chronologie](../graphiques/04_chiffres_9663_longueurs.png)

## 1. Chaque création inédite de tête, y compris les opérations contributrices

| Gain | Nouvelle longueur | Rang | Intervalle | I | P | Montées | Pertes | ν₂ | Perte immédiate | Valeur atteinte |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|---:|
| +1 | 5 | 1 | 1–1 | 1 | 0 | 1 | 0 | 1 | non | `28990` |
| +2 | 6 | 9 | 2–9 | 4 | 4 | 1 | 0 | 1 | oui | `146770` |
| +3 | 7 | 24 | 10–24 | 7 | 8 | 4 | 3 | 1 | oui | `1253878` |
| +4 | 8 | 44 | 25–44 | 9 | 11 | 5 | 4 | 1 | oui | `12050854` |

## 2. Mots exacts I/P entre deux records

La dernière opération de chaque mot est toujours `I`, c’est-à-dire une création par multiplication et addition.
- **+1**, rangs 1–1 : `I`
- **+2**, rangs 2–9 : `PIPIPIPI`
- **+3**, rangs 10–24 : `PIPPIPIPIPIPIPI`
- **+4**, rangs 25–44 : `PIPIPPIPIPPIPIPIPIPI`

## 3. Jonctions de superposition entre suffixes successifs

| Position L | Chiffre ajouté a | H=L+ν₂(a) | S_L | S_(L+1) |
|---:|---:|---:|---:|---:|
| 1 | 6 | 2 | `3` | `63` |
| 2 | 6 | 3 | `63` | `663` |
| 3 | 9 | 3 | `663` | `9663` |

La jonction `H` exprime uniquement la première divergence de parité de deux trajectoires sous `U`. Ce n’est pas le rang de création d’une tête de la trajectoire principale.

## 4. Corridors Φ–Ψ I^r P^t complets avant le maximum

| Rang classique début–fin | r | t | r′ suivant | Direction impair→impair | Variation de longueur |
|---|---:|---:|---:|---|---:|
| 0–13 | 6 | 1 | 8 | montee | +1 |
| 13–30 | 8 | 1 | 2 | montee | +1 |
| 30–35 | 2 | 1 | 7 | montee | +0 |


## 4 bis. Effets mesurés de chaque jonction sur le gain maximal N+

Cette comparaison est réalisée entre les **trajectoires complètes de deux suffixes successifs** ; elle ne démontre pas que le délai H détermine à lui seul le maximum après divergence de parité.

| Position L | Chiffre a | H sous U | N+ avant | N+ après | ΔN+ |
|---:|---:|---:|---:|---:|---:|
| 1 | 6 | 2 | +1 | +2 | +1 |
| 2 | 6 | 3 | +2 | +1 | -1 |
| 3 | 9 | 3 | +1 | +4 | +3 |

L’ajout d’un chiffre peut modifier fortement le gain maximal sans modifier la loi locale des transitions : ce sont les trajectoires futures, après rupture de parité, qui diffèrent.

## 5. Portée du résultat

Analyse arithmétique exacte de ce départ et de ses suffixes à horizon fini, sans extrapolation de convergence universelle.
