# Cas 6 chiffres — 704 511

- Départ : `704511` ; maximum classique : `56991483520` ; **N+ = +5**.
- Premier rang où la longueur maximale est atteinte : **61** ; premier rang du maximum numérique : **69**.
- De t=0 au maximum : **I=33**, **P=36**, **15** montées, **10** pertes, **44** pas neutres.
- Nouvelles têtes immédiatement perdues après division : **4/5**.
- Trajectoire entière : 242 opérations classiques avant d'atteindre 1.

![Chronologie](../graphiques/06_chiffres_704511_longueurs.png)

## 1. Chaque création inédite de tête, y compris les opérations contributrices

| Gain | Nouvelle longueur | Rang | Intervalle | I | P | Montées | Pertes | ν₂ | Perte immédiate | Valeur atteinte |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|---:|
| +1 | 7 | 1 | 1–1 | 1 | 0 | 1 | 0 | 1 | non | `2113534` |
| +2 | 8 | 9 | 2–9 | 4 | 4 | 1 | 0 | 1 | oui | `10699774` |
| +3 | 9 | 21 | 10–21 | 6 | 6 | 3 | 2 | 1 | oui | `121877134` |
| +4 | 10 | 41 | 22–41 | 9 | 11 | 4 | 3 | 1 | oui | `1171341646` |
| +5 | 11 | 61 | 42–61 | 9 | 11 | 4 | 3 | 1 | oui | `11257576990` |

## 2. Mots exacts I/P entre deux records

La dernière opération de chaque mot est toujours `I`, c’est-à-dire une création par multiplication et addition.
- **+1**, rangs 1–1 : `I`
- **+2**, rangs 2–9 : `PIPIPIPI`
- **+3**, rangs 10–21 : `PIPIPIPIPIPI`
- **+4**, rangs 22–41 : `PIPIPIPPIPPIPIPIPIPI`
- **+5**, rangs 42–61 : `PIPIPIPPIPIPPIPIPIPI`

## 3. Jonctions de superposition entre suffixes successifs

| Position L | Chiffre ajouté a | H=L+ν₂(a) | S_L | S_(L+1) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 1 | `1` | `11` |
| 2 | 5 | 2 | `11` | `511` |
| 3 | 4 | 5 | `511` | `4511` |
| 4 | 0 | aucun (a=0) | `4511` | `4511` |
| 5 | 7 | 5 | `4511` | `704511` |

La jonction `H` exprime uniquement la première divergence de parité de deux trajectoires sous `U`. Ce n’est pas le rang de création d’une tête de la trajectoire principale.

## 4. Corridors Φ–Ψ I^r P^t complets avant le maximum

| Rang classique début–fin | r | t | r′ suivant | Direction impair→impair | Variation de longueur |
|---|---:|---:|---:|---|---:|
| 0–29 | 14 | 1 | 1 | montee | +3 |
| 29–32 | 1 | 1 | 8 | descente | -1 |
| 32–49 | 8 | 1 | 2 | montee | +1 |
| 49–54 | 2 | 1 | 8 | montee | +1 |


## 4 bis. Effets mesurés de chaque jonction sur le gain maximal N+

Cette comparaison est réalisée entre les **trajectoires complètes de deux suffixes successifs** ; elle ne démontre pas que le délai H détermine à lui seul le maximum après divergence de parité.

| Position L | Chiffre a | H sous U | N+ avant | N+ après | ΔN+ |
|---:|---:|---:|---:|---:|---:|
| 1 | 1 | 1 | +0 | +0 | +0 |
| 2 | 5 | 2 | +0 | +2 | +2 |
| 3 | 4 | 5 | +2 | +2 | +0 |
| 4 | 0 | aucun | +2 | +2 | +0 |
| 5 | 7 | 5 | +2 | +5 | +3 |

L’ajout d’un chiffre peut modifier fortement le gain maximal sans modifier la loi locale des transitions : ce sont les trajectoires futures, après rupture de parité, qui diffèrent.

## 5. Portée du résultat

Analyse arithmétique exacte de ce départ et de ses suffixes à horizon fini, sans extrapolation de convergence universelle.
