# Cas 12 chiffres — 871 673 828 443

- Départ : `871673828443` ; maximum classique : `400558740821250122033728` ; **N+ = +12**.
- Premier rang où la longueur maximale est atteinte : **193** ; premier rang du maximum numérique : **212**.
- De t=0 au maximum : **I=97**, **P=115**, **42** montées, **30** pertes, **140** pas neutres.
- Nouvelles têtes immédiatement perdues après division : **11/12**.
- Trajectoire entière : 650 opérations classiques avant d'atteindre 1.

![Chronologie](../graphiques/12_chiffres_871673828443_longueurs.png)

## 1. Chaque création inédite de tête, y compris les opérations contributrices

| Gain | Nouvelle longueur | Rang | Intervalle | I | P | Montées | Pertes | ν₂ | Perte immédiate | Valeur atteinte |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|---:|
| +1 | 13 | 1 | 1–1 | 1 | 0 | 1 | 0 | 1 | non | `2615021485330` |
| +2 | 14 | 17 | 2–17 | 7 | 9 | 2 | 1 | 2 | oui | `11170023414892` |
| +3 | 15 | 37 | 18–37 | 9 | 11 | 4 | 3 | 1 | oui | `107353306091518` |
| +4 | 16 | 49 | 38–49 | 6 | 6 | 3 | 2 | 1 | oui | `1222821252198718` |
| +5 | 17 | 64 | 50–64 | 7 | 8 | 3 | 2 | 1 | oui | `10446523744369534` |
| +6 | 18 | 76 | 65–76 | 6 | 6 | 3 | 2 | 2 | oui | `118992434525709244` |
| +7 | 19 | 96 | 77–96 | 9 | 11 | 4 | 3 | 2 | oui | `1143617230844499580` |
| +8 | 20 | 134 | 97–134 | 16 | 22 | 4 | 3 | 1 | oui | `11737101523150388734` |
| +9 | 21 | 146 | 135–146 | 6 | 6 | 3 | 2 | 1 | oui | `133692922037134896694` |
| +10 | 22 | 161 | 147–161 | 7 | 8 | 3 | 2 | 1 | oui | `1142134455059429762014` |
| +11 | 23 | 181 | 162–181 | 9 | 11 | 3 | 2 | 1 | oui | `10976871327604861330942` |
| +12 | 24 | 193 | 182–193 | 6 | 6 | 3 | 2 | 1 | oui | `125033424965999123597782` |

## 2. Mots exacts I/P entre deux records

La dernière opération de chaque mot est toujours `I`, c’est-à-dire une création par multiplication et addition.
- **+1**, rangs 1–1 : `I`
- **+2**, rangs 2–17 : `PIPPIPIPIPPIPIPI`
- **+3**, rangs 18–37 : `PPIPIPPIPIPIPIPIPIPI`
- **+4**, rangs 38–49 : `PIPIPIPIPIPI`
- **+5**, rangs 50–64 : `PIPIPIPIPIPPIPI`
- **+6**, rangs 65–76 : `PIPIPIPIPIPI`
- **+7**, rangs 77–96 : `PPIPIPIPIPPIPIPIPIPI`
- **+8**, rangs 97–134 : `PPIPIPIPIPIPPIPIPPIPIPIPPPIPIPPIPIPIPI`
- **+9**, rangs 135–146 : `PIPIPIPIPIPI`
- **+10**, rangs 147–161 : `PIPIPPIPIPIPIPI`
- **+11**, rangs 162–181 : `PIPIPIPIPPIPIPIPPIPI`
- **+12**, rangs 182–193 : `PIPIPIPIPIPI`

## 3. Jonctions de superposition entre suffixes successifs

| Position L | Chiffre ajouté a | H=L+ν₂(a) | S_L | S_(L+1) |
|---:|---:|---:|---:|---:|
| 1 | 4 | 3 | `3` | `43` |
| 2 | 4 | 4 | `43` | `443` |
| 3 | 8 | 6 | `443` | `8443` |
| 4 | 2 | 5 | `8443` | `28443` |
| 5 | 8 | 8 | `28443` | `828443` |
| 6 | 3 | 6 | `828443` | `3828443` |
| 7 | 7 | 7 | `3828443` | `73828443` |
| 8 | 6 | 9 | `73828443` | `673828443` |
| 9 | 1 | 9 | `673828443` | `1673828443` |
| 10 | 7 | 10 | `1673828443` | `71673828443` |
| 11 | 8 | 14 | `71673828443` | `871673828443` |

La jonction `H` exprime uniquement la première divergence de parité de deux trajectoires sous `U`. Ce n’est pas le rang de création d’une tête de la trajectoire principale.

## 4. Corridors Φ–Ψ I^r P^t complets avant le maximum

| Rang classique début–fin | r | t | r′ suivant | Direction impair→impair | Variation de longueur |
|---|---:|---:|---:|---|---:|
| 0–5 | 2 | 1 | 3 | montee | +0 |
| 5–12 | 3 | 1 | 3 | montee | +1 |
| 12–19 | 3 | 1 | 2 | montee | +0 |
| 19–24 | 2 | 1 | 18 | montee | +0 |
| 24–61 | 18 | 1 | 8 | montee | +3 |
| 61–78 | 8 | 1 | 4 | montee | +1 |
| 78–87 | 4 | 1 | 5 | montee | +0 |
| 87–98 | 5 | 1 | 5 | montee | +1 |
| 98–109 | 5 | 1 | 2 | montee | +1 |
| 109–114 | 2 | 1 | 3 | montee | +0 |
| 114–122 | 3 | 2 | 2 | descente | +0 |
| 122–127 | 2 | 1 | 12 | montee | +0 |
| 127–152 | 12 | 1 | 9 | montee | +1 |
| 152–171 | 9 | 1 | 3 | montee | +2 |
| 171–178 | 3 | 1 | 10 | montee | +0 |
| 178–199 | 10 | 1 | 1 | montee | +1 |
| 199–202 | 1 | 1 | 3 | descente | +0 |
| 202–209 | 3 | 1 | 2 | montee | +0 |


## 4 bis. Effets mesurés de chaque jonction sur le gain maximal N+

Cette comparaison est réalisée entre les **trajectoires complètes de deux suffixes successifs** ; elle ne démontre pas que le délai H détermine à lui seul le maximum après divergence de parité.

| Position L | Chiffre a | H sous U | N+ avant | N+ après | ΔN+ |
|---:|---:|---:|---:|---:|---:|
| 1 | 4 | 3 | +1 | +1 | +0 |
| 2 | 4 | 4 | +1 | +1 | +0 |
| 3 | 8 | 6 | +1 | +2 | +1 |
| 4 | 2 | 5 | +2 | +2 | +0 |
| 5 | 8 | 8 | +2 | +4 | +2 |
| 6 | 3 | 6 | +4 | +1 | -3 |
| 7 | 7 | 7 | +1 | +2 | +1 |
| 8 | 6 | 9 | +2 | +1 | -1 |
| 9 | 1 | 9 | +1 | +2 | +1 |
| 10 | 7 | 10 | +2 | +2 | +0 |
| 11 | 8 | 14 | +2 | +12 | +10 |

L’ajout d’un chiffre peut modifier fortement le gain maximal sans modifier la loi locale des transitions : ce sont les trajectoires futures, après rupture de parité, qui diffèrent.

## 5. Portée du résultat

Analyse arithmétique exacte de ce départ et de ses suffixes à horizon fini, sans extrapolation de convergence universelle.
