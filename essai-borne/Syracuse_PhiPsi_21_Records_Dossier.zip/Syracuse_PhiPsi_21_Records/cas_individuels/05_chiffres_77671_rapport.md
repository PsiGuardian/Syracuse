# Cas 5 chiffres — 77 671

- Départ : `77671` ; maximum classique : `1570824736` ; **N+ = +5**.
- Premier rang où la longueur maximale est atteinte : **69** ; premier rang du maximum numérique : **71**.
- De t=0 au maximum : **I=33**, **P=38**, **17** montées, **12** pertes, **42** pas neutres.
- Nouvelles têtes immédiatement perdues après division : **4/5**.
- Trajectoire entière : 231 opérations classiques avant d'atteindre 1.

![Chronologie](../graphiques/05_chiffres_77671_longueurs.png)

## 1. Chaque création inédite de tête, y compris les opérations contributrices

| Gain | Nouvelle longueur | Rang | Intervalle | I | P | Montées | Pertes | ν₂ | Perte immédiate | Valeur atteinte |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|---:|
| +1 | 6 | 1 | 1–1 | 1 | 0 | 1 | 0 | 1 | non | `233014` |
| +2 | 7 | 14 | 2–14 | 6 | 7 | 1 | 0 | 1 | oui | `1327102` |
| +3 | 8 | 24 | 15–24 | 5 | 5 | 3 | 2 | 1 | oui | `10077694` |
| +4 | 9 | 36 | 25–36 | 6 | 6 | 3 | 2 | 1 | oui | `114791254` |
| +5 | 10 | 69 | 37–69 | 14 | 19 | 8 | 7 | 1 | oui | `1047216490` |

## 2. Mots exacts I/P entre deux records

La dernière opération de chaque mot est toujours `I`, c’est-à-dire une création par multiplication et addition.
- **+1**, rangs 1–1 : `I`
- **+2**, rangs 2–14 : `PIPIPPIPIPIPI`
- **+3**, rangs 15–24 : `PIPIPIPIPI`
- **+4**, rangs 25–36 : `PIPIPIPIPIPI`
- **+5**, rangs 37–69 : `PIPIPPIPPIPPIPIPIPIPIPPIPIPPIPIPI`

## 3. Jonctions de superposition entre suffixes successifs

| Position L | Chiffre ajouté a | H=L+ν₂(a) | S_L | S_(L+1) |
|---:|---:|---:|---:|---:|
| 1 | 7 | 1 | `1` | `71` |
| 2 | 6 | 3 | `71` | `671` |
| 3 | 7 | 3 | `671` | `7671` |
| 4 | 7 | 4 | `7671` | `77671` |

La jonction `H` exprime uniquement la première divergence de parité de deux trajectoires sous `U`. Ce n’est pas le rang de création d’une tête de la trajectoire principale.

## 4. Corridors Φ–Ψ I^r P^t complets avant le maximum

| Rang classique début–fin | r | t | r′ suivant | Direction impair→impair | Variation de longueur |
|---|---:|---:|---:|---|---:|
| 0–7 | 3 | 1 | 17 | montee | +1 |
| 7–42 | 17 | 1 | 1 | montee | +2 |
| 42–45 | 1 | 1 | 1 | descente | +0 |
| 45–48 | 1 | 1 | 5 | descente | +0 |
| 48–59 | 5 | 1 | 2 | montee | +1 |
| 59–64 | 2 | 1 | 4 | montee | +0 |


## 4 bis. Effets mesurés de chaque jonction sur le gain maximal N+

Cette comparaison est réalisée entre les **trajectoires complètes de deux suffixes successifs** ; elle ne démontre pas que le délai H détermine à lui seul le maximum après divergence de parité.

| Position L | Chiffre a | H sous U | N+ avant | N+ après | ΔN+ |
|---:|---:|---:|---:|---:|---:|
| 1 | 7 | 1 | +0 | +2 | +2 |
| 2 | 6 | 3 | +2 | +2 | +0 |
| 3 | 7 | 3 | +2 | +1 | -1 |
| 4 | 7 | 4 | +1 | +5 | +4 |

L’ajout d’un chiffre peut modifier fortement le gain maximal sans modifier la loi locale des transitions : ce sont les trajectoires futures, après rupture de parité, qui diffèrent.

## 5. Portée du résultat

Analyse arithmétique exacte de ce départ et de ses suffixes à horizon fini, sans extrapolation de convergence universelle.
