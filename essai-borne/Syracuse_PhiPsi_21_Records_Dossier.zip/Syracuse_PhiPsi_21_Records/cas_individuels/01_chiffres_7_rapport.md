# Cas 1 chiffres — 7

- Départ : `7` ; maximum classique : `52` ; **N+ = +1**.
- Premier rang où la longueur maximale est atteinte : **1** ; premier rang du maximum numérique : **5**.
- De t=0 au maximum : **I=3**, **P=2**, **1** montées, **0** pertes, **4** pas neutres.
- Nouvelles têtes immédiatement perdues après division : **0/1**.
- Trajectoire entière : 16 opérations classiques avant d'atteindre 1.

![Chronologie](../graphiques/01_chiffres_7_longueurs.png)

## 1. Chaque création inédite de tête, y compris les opérations contributrices

| Gain | Nouvelle longueur | Rang | Intervalle | I | P | Montées | Pertes | ν₂ | Perte immédiate | Valeur atteinte |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|---:|
| +1 | 2 | 1 | 1–1 | 1 | 0 | 1 | 0 | 1 | non | `22` |

## 2. Mots exacts I/P entre deux records

La dernière opération de chaque mot est toujours `I`, c’est-à-dire une création par multiplication et addition.
- **+1**, rangs 1–1 : `I`

## 3. Jonctions de superposition entre suffixes successifs

| Position L | Chiffre ajouté a | H=L+ν₂(a) | S_L | S_(L+1) |
|---:|---:|---:|---:|---:|

La jonction `H` exprime uniquement la première divergence de parité de deux trajectoires sous `U`. Ce n’est pas le rang de création d’une tête de la trajectoire principale.

## 4. Corridors Φ–Ψ I^r P^t complets avant le maximum

| Rang classique début–fin | r | t | r′ suivant | Direction impair→impair | Variation de longueur |
|---|---:|---:|---:|---|---:|
| Aucun corridor complet avant le maximum | — | — | — | — | — |

## 5. Portée du résultat

Analyse arithmétique exacte de ce départ et de ses suffixes à horizon fini, sans extrapolation de convergence universelle.
