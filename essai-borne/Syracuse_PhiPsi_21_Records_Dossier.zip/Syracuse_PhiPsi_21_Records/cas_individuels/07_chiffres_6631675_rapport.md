# Cas 7 chiffres — 6 631 675

- Départ : `6631675` ; maximum classique : `60342610919632` ; **N+ = +7**.
- Premier rang où la longueur maximale est atteinte : **150** ; premier rang du maximum numérique : **163**.
- De t=0 au maximum : **I=72**, **P=91**, **40** montées, **33** pertes, **90** pas neutres.
- Nouvelles têtes immédiatement perdues après division : **7/7**.
- Trajectoire entière : 576 opérations classiques avant d'atteindre 1.

![Chronologie](../graphiques/07_chiffres_6631675_longueurs.png)

## 1. Chaque création inédite de tête, y compris les opérations contributrices

| Gain | Nouvelle longueur | Rang | Intervalle | I | P | Montées | Pertes | ν₂ | Perte immédiate | Valeur atteinte |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|---:|
| +1 | 8 | 1 | 1–1 | 1 | 0 | 1 | 0 | 1 | oui | `19895026` |
| +2 | 9 | 19 | 2–19 | 8 | 10 | 4 | 3 | 1 | oui | `127471966` |
| +3 | 10 | 44 | 20–44 | 11 | 14 | 5 | 4 | 2 | oui | `1378251772` |
| +4 | 11 | 59 | 45–59 | 7 | 8 | 4 | 3 | 1 | oui | `11774361850` |
| +5 | 12 | 123 | 60–123 | 26 | 38 | 17 | 16 | 1 | oui | `108880515070` |
| +6 | 13 | 135 | 124–135 | 6 | 6 | 3 | 2 | 1 | oui | `1240217116990` |
| +7 | 14 | 150 | 136–150 | 7 | 8 | 3 | 2 | 1 | oui | `10595136073678` |

## 2. Mots exacts I/P entre deux records

La dernière opération de chaque mot est toujours `I`, c’est-à-dire une création par multiplication et addition.
- **+1**, rangs 1–1 : `I`
- **+2**, rangs 2–19 : `PIPPIPIPPIPIPIPIPI`
- **+3**, rangs 20–44 : `PIPIPIPIPPIPPPIPIPIPIPIPI`
- **+4**, rangs 45–59 : `PPIPIPIPIPIPIPI`
- **+5**, rangs 60–123 : `PIPPPIPIPIPIPPIPPIPIPPIPPIPPIPIPIPIPPPIPPIPIPPIPIPIPIPIPIPIPPIPI`
- **+6**, rangs 124–135 : `PIPIPIPIPIPI`
- **+7**, rangs 136–150 : `PIPIPIPIPIPPIPI`

## 3. Jonctions de superposition entre suffixes successifs

| Position L | Chiffre ajouté a | H=L+ν₂(a) | S_L | S_(L+1) |
|---:|---:|---:|---:|---:|
| 1 | 7 | 1 | `5` | `75` |
| 2 | 6 | 3 | `75` | `675` |
| 3 | 1 | 3 | `675` | `1675` |
| 4 | 3 | 4 | `1675` | `31675` |
| 5 | 6 | 6 | `31675` | `631675` |
| 6 | 6 | 7 | `631675` | `6631675` |

La jonction `H` exprime uniquement la première divergence de parité de deux trajectoires sous `U`. Ce n’est pas le rang de création d’une tête de la trajectoire principale.

## 4. Corridors Φ–Ψ I^r P^t complets avant le maximum

| Rang classique début–fin | r | t | r′ suivant | Direction impair→impair | Variation de longueur |
|---|---:|---:|---:|---|---:|
| 0–5 | 2 | 1 | 2 | montee | +0 |
| 5–10 | 2 | 1 | 9 | montee | +0 |
| 10–29 | 9 | 1 | 1 | montee | +2 |
| 29–33 | 1 | 2 | 6 | descente | -1 |
| 33–46 | 6 | 1 | 8 | montee | +1 |
| 46–64 | 8 | 2 | 4 | montee | +1 |
| 64–73 | 4 | 1 | 1 | montee | +0 |
| 73–76 | 1 | 1 | 2 | descente | +0 |
| 76–81 | 2 | 1 | 1 | montee | +0 |
| 81–84 | 1 | 1 | 1 | descente | +0 |
| 84–87 | 1 | 1 | 4 | descente | +0 |
| 87–97 | 4 | 2 | 1 | montee | +0 |
| 97–100 | 1 | 1 | 2 | descente | +0 |
| 100–105 | 2 | 1 | 7 | montee | +0 |
| 105–120 | 7 | 1 | 13 | montee | +1 |
| 120–147 | 13 | 1 | 5 | montee | +2 |
| 147–158 | 5 | 1 | 3 | montee | +0 |


## 4 bis. Effets mesurés de chaque jonction sur le gain maximal N+

Cette comparaison est réalisée entre les **trajectoires complètes de deux suffixes successifs** ; elle ne démontre pas que le délai H détermine à lui seul le maximum après divergence de parité.

| Position L | Chiffre a | H sous U | N+ avant | N+ après | ΔN+ |
|---:|---:|---:|---:|---:|---:|
| 1 | 7 | 1 | +1 | +1 | +0 |
| 2 | 6 | 3 | +1 | +1 | +0 |
| 3 | 1 | 3 | +1 | +0 | -1 |
| 4 | 3 | 4 | +0 | +1 | +1 |
| 5 | 6 | 6 | +1 | +3 | +2 |
| 6 | 6 | 7 | +3 | +7 | +4 |

L’ajout d’un chiffre peut modifier fortement le gain maximal sans modifier la loi locale des transitions : ce sont les trajectoires futures, après rupture de parité, qui diffèrent.

## 5. Portée du résultat

Analyse arithmétique exacte de ce départ et de ses suffixes à horizon fini, sans extrapolation de convergence universelle.
