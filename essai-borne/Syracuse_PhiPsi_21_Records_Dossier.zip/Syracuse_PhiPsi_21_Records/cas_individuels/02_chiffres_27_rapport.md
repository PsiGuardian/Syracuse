# Cas 2 chiffres — 27

- Départ : `27` ; maximum classique : `9232` ; **N+ = +2**.
- Premier rang où la longueur maximale est atteinte : **36** ; premier rang du maximum numérique : **77**.
- De t=0 au maximum : **I=33**, **P=44**, **12** montées, **10** pertes, **55** pas neutres.
- Nouvelles têtes immédiatement perdues après division : **2/2**.
- Trajectoire entière : 111 opérations classiques avant d'atteindre 1.

![Chronologie](../graphiques/02_chiffres_27_longueurs.png)

## 1. Chaque création inédite de tête, y compris les opérations contributrices

| Gain | Nouvelle longueur | Rang | Intervalle | I | P | Montées | Pertes | ν₂ | Perte immédiate | Valeur atteinte |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|---:|
| +1 | 3 | 3 | 1–3 | 2 | 1 | 1 | 0 | 2 | oui | `124` |
| +2 | 4 | 36 | 4–36 | 14 | 19 | 4 | 3 | 1 | oui | `1186` |

## 2. Mots exacts I/P entre deux records

La dernière opération de chaque mot est toujours `I`, c’est-à-dire une création par multiplication et addition.
- **+1**, rangs 1–3 : `IPI`
- **+2**, rangs 4–36 : `PPIPIPIPIPIPPIPPIPIPPIPIPIPPIPIPI`

## 3. Jonctions de superposition entre suffixes successifs

| Position L | Chiffre ajouté a | H=L+ν₂(a) | S_L | S_(L+1) |
|---:|---:|---:|---:|---:|
| 1 | 2 | 2 | `7` | `27` |

La jonction `H` exprime uniquement la première divergence de parité de deux trajectoires sous `U`. Ce n’est pas le rang de création d’une tête de la trajectoire principale.

## 4. Corridors Φ–Ψ I^r P^t complets avant le maximum

| Rang classique début–fin | r | t | r′ suivant | Direction impair→impair | Variation de longueur |
|---|---:|---:|---:|---|---:|
| 0–5 | 2 | 1 | 5 | montee | +0 |
| 5–16 | 5 | 1 | 1 | montee | +1 |
| 16–19 | 1 | 1 | 2 | descente | -1 |
| 19–24 | 2 | 1 | 3 | montee | +1 |
| 24–31 | 3 | 1 | 4 | montee | +0 |
| 31–40 | 4 | 1 | 1 | montee | +0 |
| 40–44 | 1 | 2 | 3 | descente | +0 |
| 44–51 | 3 | 1 | 2 | montee | +0 |
| 51–56 | 2 | 1 | 6 | montee | +0 |
| 56–70 | 6 | 2 | 4 | montee | +0 |


## 4 bis. Effets mesurés de chaque jonction sur le gain maximal N+

Cette comparaison est réalisée entre les **trajectoires complètes de deux suffixes successifs** ; elle ne démontre pas que le délai H détermine à lui seul le maximum après divergence de parité.

| Position L | Chiffre a | H sous U | N+ avant | N+ après | ΔN+ |
|---:|---:|---:|---:|---:|---:|
| 1 | 2 | 2 | +1 | +2 | +1 |

L’ajout d’un chiffre peut modifier fortement le gain maximal sans modifier la loi locale des transitions : ce sont les trajectoires futures, après rupture de parité, qui diffèrent.

## 5. Portée du résultat

Analyse arithmétique exacte de ce départ et de ses suffixes à horizon fini, sans extrapolation de convergence universelle.
