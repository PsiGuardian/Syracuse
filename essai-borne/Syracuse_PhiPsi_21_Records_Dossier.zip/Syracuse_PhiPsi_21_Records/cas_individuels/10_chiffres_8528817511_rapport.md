# Cas 10 chiffres — 8 528 817 511

- Départ : `8528817511` ; maximum classique : `18144594937356598024` ; **N+ = +10**.
- Premier rang où la longueur maximale est atteinte : **205** ; premier rang du maximum numérique : **212**.
- De t=0 au maximum : **I=94**, **P=118**, **44** montées, **34** pertes, **134** pas neutres.
- Nouvelles têtes immédiatement perdues après division : **9/10**.
- Trajectoire entière : 726 opérations classiques avant d'atteindre 1.

![Chronologie](../graphiques/10_chiffres_8528817511_longueurs.png)

## 1. Chaque création inédite de tête, y compris les opérations contributrices

| Gain | Nouvelle longueur | Rang | Intervalle | I | P | Montées | Pertes | ν₂ | Perte immédiate | Valeur atteinte |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|---:|
| +1 | 11 | 1 | 1–1 | 1 | 0 | 1 | 0 | 1 | non | `25586452534` |
| +2 | 12 | 14 | 2–14 | 6 | 7 | 1 | 0 | 1 | oui | `145722842962` |
| +3 | 13 | 29 | 15–29 | 7 | 8 | 4 | 3 | 2 | oui | `1244905693612` |
| +4 | 14 | 67 | 30–67 | 16 | 22 | 8 | 7 | 1 | oui | `12776639000110` |
| +5 | 15 | 100 | 68–100 | 14 | 19 | 7 | 6 | 2 | oui | `116558586619900` |
| +6 | 16 | 117 | 101–117 | 8 | 9 | 4 | 3 | 1 | oui | `1493634544557010` |
| +7 | 17 | 150 | 118–150 | 14 | 19 | 5 | 4 | 1 | oui | `13626113365069054` |
| +8 | 18 | 160 | 151–160 | 5 | 5 | 2 | 1 | 1 | oui | `103473298365993142` |
| +9 | 19 | 182 | 161–182 | 10 | 12 | 6 | 5 | 2 | oui | `1491697948050178036` |
| +10 | 20 | 205 | 183–205 | 10 | 13 | 4 | 3 | 2 | oui | `10752352555470576604` |

## 2. Mots exacts I/P entre deux records

La dernière opération de chaque mot est toujours `I`, c’est-à-dire une création par multiplication et addition.
- **+1**, rangs 1–1 : `I`
- **+2**, rangs 2–14 : `PIPIPPIPIPIPI`
- **+3**, rangs 15–29 : `PIPPIPIPIPIPIPI`
- **+4**, rangs 30–67 : `PPIPIPPIPPIPIPPIPIPIPIPPIPIPIPPIPIPIPI`
- **+5**, rangs 68–100 : `PIPIPIPPPPPIPIPIPIPIPPIPIPIPIPIPI`
- **+6**, rangs 101–117 : `PPIPIPIPIPIPIPIPI`
- **+7**, rangs 118–150 : `PIPPIPIPIPIPPIPIPPIPPIPPIPIPIPIPI`
- **+8**, rangs 151–160 : `PIPIPIPIPI`
- **+9**, rangs 161–182 : `PIPIPPIPIPIPPIPIPIPIPI`
- **+10**, rangs 183–205 : `PPIPPPIPIPIPIPIPIPIPIPI`

## 3. Jonctions de superposition entre suffixes successifs

| Position L | Chiffre ajouté a | H=L+ν₂(a) | S_L | S_(L+1) |
|---:|---:|---:|---:|---:|
| 1 | 1 | 1 | `1` | `11` |
| 2 | 5 | 2 | `11` | `511` |
| 3 | 7 | 3 | `511` | `7511` |
| 4 | 1 | 4 | `7511` | `17511` |
| 5 | 8 | 8 | `17511` | `817511` |
| 6 | 8 | 9 | `817511` | `8817511` |
| 7 | 2 | 8 | `8817511` | `28817511` |
| 8 | 5 | 8 | `28817511` | `528817511` |
| 9 | 8 | 12 | `528817511` | `8528817511` |

La jonction `H` exprime uniquement la première divergence de parité de deux trajectoires sous `U`. Ce n’est pas le rang de création d’une tête de la trajectoire principale.

## 4. Corridors Φ–Ψ I^r P^t complets avant le maximum

| Rang classique début–fin | r | t | r′ suivant | Direction impair→impair | Variation de longueur |
|---|---:|---:|---:|---|---:|
| 0–7 | 3 | 1 | 5 | montee | +1 |
| 7–18 | 5 | 1 | 6 | montee | +0 |
| 18–31 | 6 | 1 | 2 | montee | +1 |
| 31–36 | 2 | 1 | 1 | montee | +0 |
| 36–39 | 1 | 1 | 2 | descente | +0 |
| 39–44 | 2 | 1 | 4 | montee | +0 |
| 44–53 | 4 | 1 | 3 | montee | +0 |
| 53–60 | 3 | 1 | 7 | montee | +1 |
| 60–78 | 7 | 4 | 5 | montee | +0 |
| 78–89 | 5 | 1 | 6 | montee | +0 |
| 89–102 | 6 | 1 | 9 | montee | +1 |
| 102–121 | 9 | 1 | 4 | montee | +1 |
| 121–130 | 4 | 1 | 2 | montee | +1 |
| 130–135 | 2 | 1 | 1 | montee | +0 |
| 135–138 | 1 | 1 | 1 | descente | +0 |
| 138–141 | 1 | 1 | 12 | descente | -1 |
| 141–166 | 12 | 1 | 3 | montee | +2 |
| 166–173 | 3 | 1 | 5 | montee | +0 |
| 173–184 | 5 | 1 | 1 | montee | +1 |
| 184–188 | 1 | 2 | 9 | descente | +0 |
| 188–207 | 9 | 1 | 3 | montee | +1 |


## 4 bis. Effets mesurés de chaque jonction sur le gain maximal N+

Cette comparaison est réalisée entre les **trajectoires complètes de deux suffixes successifs** ; elle ne démontre pas que le délai H détermine à lui seul le maximum après divergence de parité.

| Position L | Chiffre a | H sous U | N+ avant | N+ après | ΔN+ |
|---:|---:|---:|---:|---:|---:|
| 1 | 1 | 1 | +0 | +0 | +0 |
| 2 | 5 | 2 | +0 | +2 | +2 |
| 3 | 7 | 3 | +2 | +1 | -1 |
| 4 | 1 | 4 | +1 | +1 | +0 |
| 5 | 8 | 8 | +1 | +2 | +1 |
| 6 | 8 | 9 | +2 | +2 | +0 |
| 7 | 2 | 8 | +2 | +1 | -1 |
| 8 | 5 | 8 | +1 | +2 | +1 |
| 9 | 8 | 12 | +2 | +10 | +8 |

L’ajout d’un chiffre peut modifier fortement le gain maximal sans modifier la loi locale des transitions : ce sont les trajectoires futures, après rupture de parité, qui diffèrent.

## 5. Portée du résultat

Analyse arithmétique exacte de ce départ et de ses suffixes à horizon fini, sans extrapolation de convergence universelle.
