# Syracuse Φ–Ψ — Analyse des 21 montées et des jonctions de superposition

**Nombre initial :** `274133054632352106267` (**21 chiffres**).
**Maximum classique :** `113298124744388651798242538014293435290632` (**42 chiffres**) au rang **570**.
**Méthode :** recalcul exact de la trajectoire pour analyser les jalons ; il ne s’agit pas d’une nouvelle preuve de convergence.

## 1. Bilan exact

- 247 étapes impaires `I: 3n+1`, 323 divisions `P: n/2` entre t=0 et t=570 ;
- 114 montées de longueur, 93 diminutions, 363 transitions sans changement : **114 − 93 = +21** ;
- 21 premières créations de longueur et 93 montées vers une longueur déjà rencontrée ;
- chacune des 21 premières créations est suivie immédiatement d’une division qui fait perdre le nouveau chiffre de tête (le nombre pair est strictement inférieur à `2×10^(L−1)` lorsqu’il a L chiffres).

### Condition de création

Lorsque `x` a `L` chiffres et est impair, l’opération `3x+1` produit `L+1` chiffres si et seulement si `3x+1 >= 10^L`. Cette condition correspond au report décimal vers une nouvelle cellule de tête. La division suivante décide si cette tête subsiste.

## 2. Les 21 jalons, avec opérations contributrices

| Tête nouvelle | Rang classique | Depuis le rang | 3n+1 (I) | /2 (P) | Montées locales | Pertes locales | v₂(3n+1) | Valeur obtenue |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 22 | 3 | 0 | 2 | 1 | 1 | 0 | 2 | `1233598745845584478204` |
| 23 | 18 | 3 | 7 | 8 | 3 | 2 | 1 | `10538595535798020522814` |
| 24 | 66 | 18 | 20 | 28 | 4 | 3 | 1 | `136888811449217703363454` |
| 25 | 76 | 66 | 5 | 5 | 2 | 1 | 1 | `1039499411942496934916242` |
| 26 | 106 | 76 | 13 | 17 | 7 | 6 | 1 | `12644178931780987096912210` |
| 27 | 121 | 106 | 7 | 8 | 4 | 3 | 1 | `108018825483613354613074258` |
| 28 | 138 | 121 | 8 | 9 | 5 | 4 | 3 | `1384202175777318788313242632` |
| 29 | 189 | 138 | 21 | 30 | 9 | 8 | 2 | `13484846486702417584214831740` |
| 30 | 209 | 189 | 9 | 11 | 4 | 3 | 2 | `129600699901251799467822525988` |
| 31 | 247 | 209 | 16 | 22 | 7 | 6 | 2 | `1330109875215032997712923229732` |
| 32 | 293 | 247 | 19 | 27 | 13 | 12 | 1 | `11518116703917169514113886638462` |
| 33 | 305 | 293 | 6 | 6 | 3 | 2 | 2 | `131198548080556508996703489991252` |
| 34 | 405 | 305 | 40 | 60 | 13 | 12 | 1 | `1383501001502551726112324059252798` |
| 35 | 415 | 405 | 5 | 5 | 2 | 1 | 2 | `10505960730160002170165460824950948` |
| 36 | 458 | 415 | 18 | 25 | 10 | 9 | 1 | `121302141055267604857878805509592402` |
| 37 | 473 | 458 | 7 | 8 | 4 | 3 | 1 | `1036280400343243171188206826755775742` |
| 38 | 485 | 473 | 6 | 6 | 3 | 2 | 1 | `11803881435159754246815668386015008082` |
| 39 | 500 | 485 | 7 | 8 | 5 | 4 | 1 | `100840190229274931788226042032089151102` |
| 40 | 512 | 500 | 6 | 6 | 3 | 2 | 3 | `1148632791830334769900262260021765486792` |
| 41 | 545 | 512 | 14 | 19 | 5 | 4 | 1 | `10478735038200272491560149157627188966230` |
| 42 | 570 | 545 | 11 | 14 | 7 | 6 | 3 | `113298124744388651798242538014293435290632` |

## 3. Séquences ordonnées des 21 intervalles

La chronologie est donnée exactement ; `I` = multiplication `3n+1`, `P` = division par 2. La dernière opération de chaque intervalle est la multiplication qui crée une nouvelle longueur.

- **1–3**, nouveau record 22 chiffres : `IPI` (I=2, P=1).
- **4–18**, nouveau record 23 chiffres : `PPIPIPIPIPIPIPI` (I=7, P=8).
- **19–66**, nouveau record 24 chiffres : `PIPIPIPIPIPPIPIPPIPPIPPIPPIPIPIPIPPIPPIPPIPIPIPI` (I=20, P=28).
- **67–76**, nouveau record 25 chiffres : `PIPIPIPIPI` (I=5, P=5).
- **77–106**, nouveau record 26 chiffres : `PIPPIPIPIPPPIPIPIPIPIPPIPIPIPI` (I=13, P=17).
- **107–121**, nouveau record 27 chiffres : `PIPPIPIPIPIPIPI` (I=7, P=8).
- **122–138**, nouveau record 28 chiffres : `PIPPIPIPIPIPIPIPI` (I=8, P=9).
- **139–189**, nouveau record 29 chiffres : `PPPIPPIPPIPPIPIPPIPIPIPIPIPIPPPPIPIPIPIPIPIPIPIPIPI` (I=21, P=30).
- **190–209**, nouveau record 30 chiffres : `PPIPIPIPIPIPPIPIPIPI` (I=9, P=11).
- **210–247**, nouveau record 31 chiffres : `PPIPPIPIPIPPIPIPPIPIPIPIPIPPIPIPPIPIPI` (I=16, P=22).
- **248–293**, nouveau record 32 chiffres : `PPIPPIPIPIPPIPIPPIPPIPIPIPIPPPIPIPPIPIPIPIPIPI` (I=19, P=27).
- **294–305**, nouveau record 33 chiffres : `PIPIPIPIPIPI` (I=6, P=6).
- **306–405**, nouveau record 34 chiffres : `PPIPPPPPPIPIPIPPIPIPIPPIPPPIPIPIPIPIPIPIPIPPIPIPIPPPIPIPPIPIPPPIPIPPIPIPIPPIPIPIPIPIPPIPIPPIPIPIPIPI` (I=40, P=60).
- **406–415**, nouveau record 35 chiffres : `PIPIPIPIPI` (I=5, P=5).
- **416–458**, nouveau record 36 chiffres : `PPIPPIPIPIPIPIPPIPIPPIPPIPIPIPPPIPIPIPIPIPI` (I=18, P=25).
- **459–473**, nouveau record 37 chiffres : `PIPPIPIPIPIPIPI` (I=7, P=8).
- **474–485**, nouveau record 38 chiffres : `PIPIPIPIPIPI` (I=6, P=6).
- **486–500**, nouveau record 39 chiffres : `PIPPIPIPIPIPIPI` (I=7, P=8).
- **501–512**, nouveau record 40 chiffres : `PIPIPIPIPIPI` (I=6, P=6).
- **513–545**, nouveau record 41 chiffres : `PPPIPPIPIPPPIPIPIPIPIPIPIPIPIPIPI` (I=14, P=19).
- **546–570**, nouveau record 42 chiffres : `PIPIPPIPPIPPIPIPIPIPIPIPI` (I=11, P=14).

## 4. Cartographie des 20 jonctions décimales par superposition

Pour chaque `L` de 1 à 20, comparer les suffixes `S_L=N mod 10^L` et `S_(L+1)=N mod 10^(L+1)=S_L+a_L 10^L`.

Si `a_L != 0`, le lemme 5.37 prévoit **exactement** le premier rang de divergence des *parités* entre leurs trajectoires sous l’opérateur condensé `U` :

```text
H_influence = L + v₂(a_L)
U(n) = (3n+1)/2 si n impair, sinon n/2
U^h(S_(L+1)) − U^h(S_L) = a_L 10^L 3^(m_h) / 2^h, pour h < H_influence
```

Lorsqu’un chiffre ajouté est zéro, les deux suffixes sont identiques et il n’existe pas de divergence.

| Position L | Nouveau chiffre a | H_influence (U) |
|---:|---:|---:|
| 1 | 6 | 2 |
| 2 | 2 | 3 |
| 3 | 6 | 4 |
| 4 | 0 | aucune (a=0) |
| 5 | 1 | 5 |
| 6 | 2 | 7 |
| 7 | 5 | 7 |
| 8 | 3 | 8 |
| 9 | 2 | 10 |
| 10 | 3 | 10 |
| 11 | 6 | 12 |
| 12 | 4 | 14 |
| 13 | 5 | 13 |
| 14 | 0 | aucune (a=0) |
| 15 | 3 | 15 |
| 16 | 3 | 16 |
| 17 | 1 | 17 |
| 18 | 4 | 20 |
| 19 | 7 | 19 |
| 20 | 2 | 21 |

### Jonction supérieure : 20 → 21 chiffres

`S_20 = 74133054632352106267`, `S_21 = 274133054632352106267`, `a_20=2`, donc `H=20+v₂(2)=21` itérations **U**.

| Rang classique | S_21 (21 chiffres initialement) | S_20 (20 chiffres initialement) |
|---:|---:|---:|
| 0 | `274133054632352106267` (21 ch.) | `74133054632352106267` (20 ch.) |
| 1 | `822399163897056318802` (21 ch.) | `222399163897056318802` (21 ch.) |
| 2 | `411199581948528159401` (21 ch.) | `111199581948528159401` (21 ch.) |
| 3 | `1233598745845584478204` (22 ch.) | `333598745845584478204` (21 ch.) |
| 4 | `616799372922792239102` (21 ch.) | `166799372922792239102` (21 ch.) |
| 5 | `308399686461396119551` (21 ch.) | `83399686461396119551` (20 ch.) |

**Conclusion de cet exemple :** les deux nombres partagent les décisions de parité jusqu’au rang 20 de `U`, avec première divergence au rang 21, mais leurs *longueurs* peuvent déjà diverger en cours de route (t=3 classique : 22 contre 21 chiffres). Le délai d’influence porte sur les parités, pas sur les tailles ou les apparitions de tête.

## 5. Ce qui relève de Φ–Ψ et ce qui n’en découle pas directement

- **Dans une trajectoire fixée** : le pied détermine l’opération ; les retenues de multiplication se transmettent de droite vers la gauche ; les restes de division se transmettent de gauche vers la droite. Chaque nouveau chiffre de tête vient de la normalisation exacte du produit.
- **Entre trajectoires superposées** (suffixes de différentes longueurs) : la valuation de la différence initiale contrôle exactement la première divergence des parités. Cela décrit une compatibilité des branches, pas une cause supplémentaire des 21 montées d’un seul nombre.
- **Corridors/réarmements** : `v₂(3n+1)` mesure les divisions paires successives suivant chaque création de tête ; ce signal temporel conditionne les reprises de montée.
- **Limite logique** : ces résultats décrivent exactement l’exemple et les règles locales à horizon fini ; ils ne démontrent pas que les maxima des trajectoires ont une borne universelle ni la conjecture de Syracuse.

## 6. Fichiers associés

- `Syracuse_274133054632352106267_Iterations_0_570.csv` — toutes les 571 valeurs et opérations ;
- `Syracuse_274133054632352106267_Creation_Tetes.csv` — les 21 premières atteintes et les mots I/P par intervalle ;
- `Syracuse_274133054632352106267_Superpositions_20_Jonctions.csv` — vérification des vingt raccordements entre suffixes ;
- `Syracuse_274133054632352106267_Schema_Montees.png` — évolution intégrale du nombre de chiffres ;
- `Syracuse_274133054632352106267_Schema_Operations_Intervalles.png` — volumes d’opérations par création ;
- `Syracuse_274133054632352106267_Schema_Superpositions.png` — carte des premiers délais de divergence.

Sources de définition : `Syracuse_PhiPsi_Theoremes_v9.tex` sections 2, 15 et 24 ; `Syracuse_PhiPsi_Lemme_5_37.tex` ; contrôle des corridors : `syracuse_phi_psi_matrice_rearmements.py`. Données numériques reconstruites par arithmétique entière.
