Syracuse Phi-Psi — Audit de la divergence et des cycles

Statut : preuve universelle NON obtenue.

Documents :
- Lemmes_S36_S41_Obstructions.pdf : énoncés et preuves
- Lemmes_S36_S41_Obstructions.tex : source LaTeX
- Rapport_Audit_Etapes_Fermeture.md : rapport d'audit
- verifier_cycles.py : vérificateur exact pour m<=13
- cycles_enumeration_certifiee.csv : effectifs des 579557 mots
- cycles_resume.json : données de vérification

Commande : python3 verifier_cycles.py --max-odd-terms 13 --out .
