# Syracuse Φ–Ψ — Audit de fermeture : divergence et cycles

**Date : 18 novembre 2026. Statut : preuve universelle non obtenue.**

## Cadre de travail

Sources de base : manuscrit Φ–Ψ v9 (opérateur exact), lemme 5.37 (superposition), étude v15 (réalisabilité de tous les mots finis de profondeurs), compléments S23–S35 (cylindres exacts, rigidification et familles à profondeur infinie).

### Résultat 1 — Découpage exact des deux obstacles

Toute trajectoire positive bornée finit dans un cycle. Il suffit donc d'exclure simultanément (a) toute orbite non bornée, (b) tout cycle positif non trivial. Ce découpage ne résout aucun des deux problèmes par lui-même.

### Résultat 2 — Le certificat réellement manquant pour les nouvelles têtes

Pour tout nombre initial à L chiffres, il faut trouver **une même** borne finie K(L) telle qu'aucun de ces nombres ne crée K(L) nouvelles longueurs décimales. C'est équivalent à la bornitude universelle des orbites.

La filtration S30 et la rigidification S31–S32 ne fournissent pas cette borne. Après rigidification, un singleton admissible peut rester un singleton à toutes les profondeurs, si et seulement si son orbite suit effectivement les créations imposées. Une congruence de module croissant n'est donc pas une contradiction arithmétique.

### Résultat 3 — L'obstruction 2-adique

La réalisation de tout préfixe fini par un entier susceptible de changer avec la profondeur ne garantit pas un départ entier positif réalisant la chaîne infinie. Exemple v15 : n_K=2^(K+1)-1 réalise K profondeurs successives égales à 1 ; les résidus tendent 2-adiquement vers -1, non positif.

### Résultat 4 — Critère diophantien exact pour chaque mot cyclique

Soit un cycle de m **termes impairs** u_0,...,u_{m-1}, et a_j=v2(3u_j+1). Écrivons A_0=B_0=0, A_{j+1}=A_j+a_j, B_{j+1}=3B_j+2^{A_j}. Un cycle exigerait :

    (2^A - 3^m) u_0 = B_m,   A = sum(a_j), 2^A>3^m.

Il faut, en particulier, que 2^A-3^m divise B_m ; et que les profondeurs prescrites soient effectivement réalisées. Ces conditions sont nécessaires et suffisantes **pour un mot fixé**, pas uniformément pour tous les mots de toute longueur.

En multipliant les équations du cycle :

    2^A = product_j (3 + 1/u_j).

Pour un cycle non trivial, tous u_j≥3 et donc :

    3^m < 2^A < (10/3)^m.

C'est une réduction de l'ensemble des mots candidats, pas leur exclusion universelle.

### Résultat 5 — Audit exhaustif à m≤13

Le programme `verifier_cycles.py` énumère **579 557** compositions positives de A en m profondeurs, après la restriction ci-dessus, pour 1≤m≤13. Il n'existe aucun quotient entier impair supérieur à 1 satisfaisant l'équation de fermeture dans ce domaine. L'absence de cycles non triviaux de cette taille est certifiée par arithmétique entière.

Ce résultat fini est bien moins fort que les restrictions publiées sur les cycles de Syracuse ; il sert ici à vérifier l'outil de composition Φ–Ψ et ne doit pas être présenté comme une découverte décisive.

### Résultat 6 — Bornes issues du domaine déjà vérifié

La convergence est publiquement vérifiée au moins pour tous les départs inférieurs à X=2^71 (Bařina). Un éventuel cycle non trivial devrait avoir tous ses éléments ≥X. L'identité multiplicative impose alors :

    0 < A ln(2) - m ln(3) <= m ln(1+1/(3X)) < m/(3X).

Pour m<3X ln2, la seule somme A possible est ceil(m log_2(3)), sous réserve de l'inégalité quantitative. Cette contrainte est forte sur de très grands intervalles finis de m, mais ne les couvre pas tous.

## Conclusion — Réponse à la question « avons-nous désormais une preuve ? »

**Non.** Il reste deux propositions universelles distinctes et non démontrées dans les sources :

1. Existence d'une borne K(L) pour toute longueur initiale L, valable simultanément pour tous les nombres de longueur L ;
2. Impossibilité de la divisibilité et des valuations exactes pour tous les mots cycliques de toute longueur m.

La classification des familles à profondeur finie et l'audit des 21 records sont compatibles avec ces objectifs, mais ne les impliquent pas.

## Reproductibilité

Exécuter :

    python3 verifier_cycles.py --max-odd-terms 13 --out .

Fichiers produits : `cycles_enumeration_certifiee.csv` et `cycles_resume.json`. Le programme requiert seulement la bibliothèque standard de Python 3. Il ne fait appel ni aux nombres flottants ni à la vérification exhaustive de tous les entiers positifs.

## Source externe de vérification

D. Bařina, *Improved verification limit for the convergence of the Collatz conjecture*, The Journal of Supercomputing (2025), https://link.springer.com/article/10.1007/s11227-025-07337-0 .
