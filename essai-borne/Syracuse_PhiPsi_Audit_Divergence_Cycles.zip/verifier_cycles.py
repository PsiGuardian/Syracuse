#!/usr/bin/env python3
"""Audit exact de cycles Collatz impairs avec nombre de termes impairs borné.
Aucune hypothèse probabiliste; seulement entiers Python et assertions.
Ne prétend PAS décider l'existence de cycles de toute longueur.
"""
import csv, itertools, math, json, argparse
from pathlib import Path

def compositions(total, k):
    # Décomposition de total en k entiers >=1, par positions de coupure.
    for cuts in itertools.combinations(range(1,total), k-1):
        yield tuple(b-a for a,b in zip((0,)+cuts,cuts+(total,)))

def cycle_candidate(aa):
    A=0; B=0
    for a in aa:
        B=3*B+(1<<A)
        A+=a
    d=(1<<A)-3**len(aa)
    if d<=0 or B%d: return None
    n=B//d
    if n<=1 or n%2==0: return None
    u=n
    for a in aa:
        t=3*u+1
        v=(t&-t).bit_length()-1
        if v!=a: return None
        u=t>>v
    if u!=n: return None
    return n

def vals(m):
    arr=[]
    # strict range of A for a non-trivial odd cycle: 3^m<2^A and 3^m 2^A<10^m
    A=m
    while 3**m >= 1<<A: A+=1
    while 3**m*(1<<A)<10**m:
        arr.append(A); A+=1
    return arr

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--max-odd-terms', type=int,default=13); ap.add_argument('--out',default='/mnt/data/Syracuse_PhiPsi_Cycles_Divergence_Audit')
    args=ap.parse_args(); out=Path(args.out); out.mkdir(exist_ok=True,parents=True)
    rows=[]
    for m in range(1,args.max_odd_terms+1):
        candidates=0; exact=0; candidate_example=[]; words=0
        for A in vals(m):
            for aa in compositions(A,m):
                words+=1
                # Note: count of rational-affine fixed points integer without exact depth verification.
                B=0; q=0
                for a in aa:
                    B=3*B+(1<<q)
                    q+=a
                d=(1<<A)-3**m
                if B%d==0:
                    n=B//d
                    if n>1 and n%2:
                        candidates+=1
                        if len(candidate_example)<4: candidate_example.append((n,aa))
                if cycle_candidate(aa) is not None: exact+=1
        r={'m_odd':m,'A_possible':';'.join(map(str,vals(m))),'mots_examines':words,'points_fixes_entiers_impairs_gt1':candidates,'cycles_valides':exact,'exemples_points_fixes':repr(candidate_example)}
        rows.append(r)
        print(f"m={m:2d}, A={r['A_possible'] or '-':5}, words={words:9d}, integral odd candidates={candidates}, genuine={exact}",flush=True)
    with (out/'cycles_enumeration_certifiee.csv').open('w',newline='',encoding='utf8') as f:
        wr=csv.DictWriter(f,fieldnames=rows[0].keys());wr.writeheader();wr.writerows(rows)
    (out/'cycles_resume.json').write_text(json.dumps({'max_odd_terms':args.max_odd_terms,'rows':rows,'conclusion':'Exclusion exacte dans le domaine enumeré uniquement'},indent=2,ensure_ascii=False),encoding='utf8')
    assert all(r['cycles_valides']==0 for r in rows)
if __name__=='__main__': main()
