#!/usr/bin/env python3
"""Phi-Psi: exact rational transfer, all 133 words without enumerating 133**4.
Classification of asymptotic positive first-new-head windows (not fixed-L statements).
Only stdlib; no statistical extrapolation.  Uses 2D dominance queries for quadruple totals.
"""
import csv, json, time, itertools, math
from pathlib import Path
from fractions import Fraction
from collections import Counter,defaultdict
from bisect import bisect_left, bisect_right
OUT=Path(__file__).resolve().parent
SRC=OUT/'catalogue_source_133_mots.csv'
OUT.mkdir(parents=True,exist_ok=True)

def summarize(s):
    assert s and s[-1]=='I' and set(s)<=set('IP') and 'II' not in s
    p=q=0; m=Fraction(1)
    for pos,c in enumerate(s):
        if c=='I':p+=1
        else:q+=1
        if pos <len(s)-1:
            m=min(m,Fraction(2**q,3**p))
    v=Fraction(2**q,3**p)
    assert v<m, (s,v,m)
    return {'word':s,'p':p,'q':q,'g':1/v,'v':v,'u':m,'beginsI':s[0]=='I'}

def trans(state,word):
    # current state = (alpha,beta,lambda), lambda = 10**j / product(g_i)
    a,b,lam=state
    newa=max(a,lam*word['v'])
    newb=min(b,lam*word['u'])
    if newa>=newb: return None
    return (newa,newb,lam*10*word['v'])

def table2d(words):
    # Count options with v < threshold_v and u > threshold_u.
    vs=sorted(set(w['v'] for w in words))
    us=sorted(set(w['u'] for w in words))
    exact=[[0 for _ in us] for _ in vs]
    for w in words:
        exact[bisect_left(vs,w['v'])][bisect_left(us,w['u'])]+=1
    cum=[[0]*(len(us)+1) for _ in range(len(vs)+1)]
    for i in range(1,len(vs)+1):
        for j in range(len(us)-1,-1,-1):
            cum[i][j]=cum[i-1][j]+cum[i][j+1]-cum[i-1][j+1]+exact[i-1][j]
    def query(st):
        a,b,lam=st
        i=bisect_left(vs,b/lam)
        j=bisect_right(us,a/lam)
        return cum[i][j]
    return query,vs,us

def records():
    data=list(csv.DictReader(open(SRC,encoding='utf-8',newline='')))
    words=[summarize(r['mot_IP']) for r in data]
    start=Fraction(1,10),Fraction(1),Fraction(1)
    singles=[trans(start,w) for w in words]
    assert all(s is not None for s in singles)
    N=len(words)
    options=[(i,w) for i,w in enumerate(words) if not w['beginsI']]
    assert len(options)==130
    query,vs,us=table2d([w for _,w in options])
    pairs=[]; pairtypes=Counter(); indegree=Counter();outdegree=Counter()
    t=time.time()
    for i,s in enumerate(singles):
        for j,w in enumerate(words):
            if w['beginsI']:
                pairtypes['parity']+=1;continue
            ss=trans(s,w)
            if ss is None:
                pairtypes['window']+=1;continue
            pairs.append((i,j,ss));pairtypes['positive']+=1
            indegree[j]+=1;outdegree[i]+=1
    assert sum(pairtypes.values())==N*N
    print('PAIRS',dict(pairtypes),'elapsed',round(time.time()-t,2),flush=True)
    counts_left=Counter();counts_right=Counter();third_tot=0
    triple_rejected_after_positive_pair=0
    # sample false-compatibility triples, e.g. both adjacent pairs positive but triple impossible
    edge={(i,j) for i,j,_ in pairs}
    forbidden3=[]
    # pair states by (j,k) for suffix tests
    for i,j,s in pairs:
        for k,w in options:
            st=trans(s,w)
            if st is None:
                triple_rejected_after_positive_pair+=1
                if len(forbidden3)<30 and (j,k) in edge:
                    forbidden3.append((i,j,k))
                continue
            third_tot+=1
            counts_left[(j,k)]+=1
            counts_right[(i,j)]+=1
    pair_adjacent=sum(indegree[j]*outdegree[j] for j in range(N))
    incompat3=pair_adjacent-third_tot
    print('TRIPLES',third_tot,'both_adjpairs',pair_adjacent,'notglobally',incompat3,'elapsed',round(time.time()-t,2),flush=True)
    # Count all viable QUADRUPLES via 2D dominance query, *without* enumerating last 133 choices.
    fourth_tot=0; triple_recount=0; third_parity_rejected=0
    sample_positive=[];sample_false4=[]; badfour=0
    for i,j,s in pairs:
        for k,w in options:
            st=trans(s,w)
            if st is None:continue
            triple_recount+=1
            fourth_tot+=query(st)
            if len(sample_positive)<12: sample_positive.append((i,j,k,str(st[0]),str(st[1])))
            # For a sample of explicit quadruple obstruction with both triples valid:
            if len(sample_false4)<20 and counts_right[(j,k)]>0:
                for l,z in options:
                    if (j,k) in edge and counts_left[(k,l)] and trans(st,z) is None:
                        # need suffix (j,k,l) independently viable, not (k,l)!
                        pair_state=next((ps for a,b,ps in pairs if a==j and b==k),None)
                        if pair_state is not None and trans(pair_state,z) is not None:
                            sample_false4.append((i,j,k,l));break
    assert third_tot==triple_recount
    both_adjtriples=sum(counts_left[key]*counts_right[key] for key in counts_left)
    incompat4=both_adjtriples-fourth_tot
    print('QUADS',fourth_tot,'both_adjtrip',both_adjtriples,'notglobally',incompat4,'elapsed',round(time.time()-t,2),flush=True)
    # Independent full-prefix reference calculation (no precompiled local extrema).
    def full_prefix_window(indices):
        alpha=Fraction(1,10); beta=Fraction(1)
        p=q=0;prev=None
        for stage,idx in enumerate(indices):
            word=words[idx]['word']
            for j,c in enumerate(word):
                if prev=='I' and c=='I':return False
                prev=c
                if c=='I':p+=1
                else:q+=1
                threshold=Fraction((10**stage)*(2**q),3**p)
                if j==len(word)-1:alpha=max(alpha,threshold)
                else:beta=min(beta,threshold)
        return alpha<beta
    test=Counter()
    for chain in itertools.product(range(10),repeat=3):
        st=singles[chain[0]]
        for index in chain[1:]:
            if words[index]['beginsI']:st=None;break
            st=trans(st,words[index]) if st is not None else None
        assert bool(st)==full_prefix_window(chain),chain
        test['triple_positive']+=bool(st)
    for chain in itertools.product(range(10),repeat=4):
        st=singles[chain[0]]
        for index in chain[1:]:
            if words[index]['beginsI']:st=None;break
            st=trans(st,words[index]) if st is not None else None
        assert bool(st)==full_prefix_window(chain),chain
        test['quad_positive']+=bool(st)
    assert test=={'triple_positive':357,'quad_positive':1745}
    import random
    rng=random.Random(8)
    for _ in range(1500):
        indices=tuple(rng.randrange(N) for _ in range(rng.choice([2,3,4,5])))
        st=singles[indices[0]]
        for index in indices[1:]:
            if words[index]['beginsI']:st=None;break
            st=trans(st,words[index]) if st is not None else None
        assert bool(st)==full_prefix_window(indices),indices
    print('CROSSCHECK',dict(test),'1500 random checks',flush=True)
    # Exports, no large Cartesian enumeration for quadruple totals.
    with open(OUT/'133_classes_mots.csv','w',newline='',encoding='utf-8') as f:
        wr=csv.writer(f);wr.writerow(['index','mot','occurrences_corpus','nombre_operations','p','q','gain_g','seuil_v','plafond_u','commence_par_I'])
        for i,(w,row) in enumerate(zip(words,data)):
            wr.writerow([i+1,w['word'],row['occurrences'],len(w['word']),w['p'],w['q'],str(w['g']),str(w['v']),str(w['u']),int(w['beginsI'])])
    with open(OUT/'17689_paires_classifiees.csv','w',newline='',encoding='utf-8') as f:
        wr=csv.writer(f);wr.writerow(['classe_i','classe_j','etat','alpha','beta','modulo_mot_complet_non_calcule'])
        pairdict={(i,j):st for i,j,st in pairs}
        for i in range(N):
            for j in range(N):
                s=pairdict.get((i,j))
                label='positive' if s else ('parite_II' if words[j]['beginsI'] else 'fenetre_vide_asymptotique')
                wr.writerow([i+1,j+1,label,str(s[0]) if s else '',str(s[1]) if s else '', ''])
    with open(OUT/'133_gre_compatibilite.csv','w',newline='',encoding='utf-8') as f:
        wr=csv.writer(f);wr.writerow(['depart\\suite']+[str(i+1) for i in range(N)])
        for i in range(N):
            wr.writerow([i+1]+[1 if (i,j) in edge else 0 for j in range(N)])
    with open(OUT/'triplets_interdits_malgre_paires.csv','w',newline='',encoding='utf-8') as f:
        wr=csv.writer(f);wr.writerow(['mot1','mot2','mot3'])
        for i,j,k in forbidden3: wr.writerow([words[i]['word'],words[j]['word'],words[k]['word']])
    with open(OUT/'quadruplets_interdits_malgre_triplets.csv','w',newline='',encoding='utf-8') as f:
        wr=csv.writer(f);wr.writerow(['mot1','mot2','mot3','mot4'])
        for i,j,k,l in sample_false4: wr.writerow([words[i]['word'],words[j]['word'],words[k]['word'],words[l]['word']])
    stats={'n_words':N,'words_start_I':N-len(options),'pairs_total':N**2,'pairs_positive':pairtypes['positive'],'pairs_parity_forbidden':pairtypes['parity'],'pairs_window_negative':pairtypes['window'],'triples_total':N**3,'triples_positive':third_tot,'triples_both_adjacent_pairs_positive':pair_adjacent,'triples_bad_despite_adjacent_pairs_positive':incompat3,'quadruples_total':N**4,'quadruples_positive':fourth_tot,'quadruples_both_adjacent_triples_positive':both_adjtriples,'quadruples_bad_despite_adjacent_triples_positive':incompat4,'validation_first_10_triples':357,'validation_first_10_quadruples':1745,'asymptotic_positive_not_fixed_L':True,'elapsed_seconds':round(time.time()-t,2)}
    with open(OUT/'resultats_133.json','w',encoding='utf-8') as f:json.dump(stats,f,indent=2,ensure_ascii=False)
    print('TOTAL',json.dumps(stats,ensure_ascii=False),flush=True)
    return stats
if __name__=='__main__': records()
