# Syracuse Φ–Ψ — Extension aux 133 mots

## Exécution

Sur Python 3.10+ (bibliothèque standard uniquement) :

```bash
python3 extension_133_mots.py
```

Le script lit `catalogue_source_133_mots.csv` dans son répertoire, reconstruit les 133 résumés rationnels, examine les 17 689 paires et les prolongements des paires positives, puis calcule les quadruplets par **comptage bidimensionnel** sans développer les 312 900 721 quadruplets.

Il refait de façon autonome les validations de contrôle : alphabet réduit de dix mots (357 triplets, 1 745 quadruplets) et 1 500 chaînes aléatoires de deux à cinq mots comparées à un calcul indépendant par tous les préfixes.

Les résultats principaux sont inscrits dans `resultats_133.json` ; les CSV exportent les classes de mots, les paires, une matrice 133×133, et des contre-exemples choisis pour les échecs d'ordre 3 et 4.

Le calcul est **exact pour les fenêtres rationnelles lorsque L→∞** avec une chaîne finie fixée. Il ne signifie pas que chaque chaîne classée positive soit déjà réalisable avec un nombre initial de longueur L donné.

## Fichiers

- `Rapport_133_Mots.md` : explication complète et portée mathématique.
- `Lemmes_S18_S22.tex` et `.pdf` : cinq énoncés et démonstrations.
- `catalogue_source_133_mots.csv` : catalogue conservé depuis les 230 intervalles.
- `133_classes_mots.csv` : compilation (g, v, u).
- `17689_paires_classifiees.csv` : trois classes disjointes pour chaque paire.
- `133_gre_compatibilite.csv` et `matrice_133x133.png` : compatibilité limite de chaque paire.
- `resultats_133.json` : comptes certifiés par l'algorithme.
- `triplets_interdits_malgre_paires.csv`, `quadruplets_interdits_malgre_triplets.csv` : échantillons d'obstructions ; ces échantillons ne sont pas les catalogues exhaustifs des chaînes interdites.
- `extension_133_mots.py` : reproductibilité sans dépendances tierces.

## Limite scientifique

Les 133 mots sont l'ensemble des mots **observés** dans le corpus de 21 records, pas un alphabet universel exhaustif des mots de première création de tête. Les invariants Φ–Ψ dans l'état complet et les retenues décimales ne sont pas remplacés par les trois paramètres rationnels : ces derniers suffisent à classifier la **positivité limite des fenêtres** uniquement.
