import csv, json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
R=Path('/mnt/data/Syracuse_PhiPsi_Extension_133_Mots')
s=json.load(open(R/'resultats_133.json'))
rows=list(csv.DictReader(open(R/'133_gre_compatibilite.csv')))
mat=[[int(r[str(i)]) for i in range(1,134)] for r in rows]
fig,ax=plt.subplots(figsize=(9,8),dpi=170)
ax.imshow(mat,origin='lower',aspect='equal',interpolation='nearest',cmap=ListedColormap(['#e2b9b5','#257f84']),vmin=0,vmax=1)
ax.set_xlabel('Classe suivante (1-133)');ax.set_ylabel('Classe precedente (1-133)')
ax.set_title('Admissibilite asymptotique des 17 689 couples de mots')
ax.set_xticks([0,19,39,59,79,99,119,132]); ax.set_xticklabels([1,20,40,60,80,100,120,133])
ax.set_yticks([0,19,39,59,79,99,119,132]); ax.set_yticklabels([1,20,40,60,80,100,120,133])
fig.text(.08,.01,'Vert : fenetre strictement positive ; rose : contradiction de parite ou de fenetre',fontsize=9)
fig.tight_layout(rect=(0,.02,1,1));fig.savefig(R/'matrice_133x133.png',bbox_inches='tight');plt.close(fig)
fig,ax=plt.subplots(figsize=(8.5,4.7),dpi=170)
ks=[1,2,3,4];total=[133**i for i in ks];ad=[133,s['pairs_positive'],s['triples_positive'],s['quadruples_positive']]
ax.plot(ks,[100*x/y for x,y in zip(ad,total)],marker='o',linewidth=2.3)
for x,n,d in zip(ks,ad,total):ax.annotate(f'{100*n/d:.2f} %',(x,100*n/d),xytext=(6,6),textcoords='offset points')
ax.set_xticks(ks);ax.set_ylim(35,105);ax.set_xlabel('Nombre de mots successifs');ax.set_ylabel('Part des chaines a fenetre positive (%)')
ax.set_title('Classification complete des chaines de 1 a 4 mots (alphabet 133)')
ax.grid(True,alpha=.18)
fig.tight_layout();fig.savefig(R/'proportions_profondeur_133.png',bbox_inches='tight');plt.close(fig)
