# Syracuse Φ–Ψ — Extension aux 133 mots et automate rationnel de compatibilité

**18 novembre 2026 — Recherche à horizon fini.** Corpus : 21 départs records, 230 intervalles entre premières créations successives de tête, 133 mots littéraux distincts `I/P`. `I(n)=3n+1` si `n` est impair et `P(n)=n/2` si `n` est pair. Toutes les chaînes étudiées sont construites à partir de cet alphabet **observé**, qui ne contient pas nécessairement tous les mots possibles. L'étude ne constitue pas une preuve de la conjecture de Syracuse.

## 1. Classification exacte de l'alphabet complet

| Longueur de chaîne | Combinaisons théoriques | Fenêtre normalisée strictement positive | Part |
|---:|---:|---:|---:|
| 1 | 133 | 133 | 100 % |
| 2 | 17 689 | 14 879 | 84,1144 % |
| 3 | 2 352 637 | 1 501 332 | 63,8149 % |
| 4 | 312 900 721 | 143 944 861 | 46,0034 % |

Au niveau des couples, 399 chaînes contiennent une jonction `II` interdite pour tout entier ; 2 411 présentent des fenêtres limites vides (et sont impossibles pour toutes les longueurs initiales assez grandes). Les 14 879 autres sont réalisables pour chaque longueur initiale suffisamment grande **dépendant du couple**.

**Mémoire des contraintes :** 1 677 186 triplets possèdent deux paires adjacentes admissibles, mais seulement 1 501 332 triplets sont admissibles globalement : 175 854 triplets sont donc exclus malgré la compatibilité de leurs deux paires. De même, 154 338 634 quadruplets possèdent deux sous-triplets adjacents admissibles, mais seulement 143 944 861 sont globalement admissibles : 10 393 773 quadruplets sont exclus par les contraintes héritées des créations antérieures.

**Portée :** ces effectifs classent les fenêtres asymptotiques pour `L → ∞` et les mots finis de l'alphabet fixé. Une fenêtre négative peut exceptionnellement être réalisée à petite longueur en raison des termes additifs ; seule une contradiction de parité est immédiatement impossible à toutes longueurs. Une fenêtre strictement positive admet des nombres entiers témoins de toute longueur initiale assez grande, mais pas nécessairement à une longueur fixée comme 12 ou 60 chiffres.

## 2. Compilation exacte de chaque mot en trois paramètres rationnels

Soit `w` un mot classique admissible, terminé par `I`, et `p_h,q_h` les nombres de `I,P` dans ses `h` premières opérations. On définit :

- `g_w = 3^{p_|w|}/2^{q_|w|}` : coefficient multiplicatif de la transformation affine du mot ;
- `v_w = 1/g_w = 2^{q_|w|}/3^{p_|w|}` : seuil inférieur de franchissement, sans terme additif ;
- `u_w = min_{0≤h<|w|} 2^{q_h}/3^{p_h}` : plafond permettant d'éviter toute création anticipée.

Pour chacun des 133 mots du corpus, `v_w < u_w`, condition nécessaire à la possibilité d'une première création à longueur assez grande. Cette compilation absorbe l'intégralité des préfixes propres d'un mot dans une borne unique `u_w`. **Elle n'efface pas ses congruences dyadiques**, conservées séparément pour le contrôle à longueur finie.

## 3. Lemme S18 — État minimal de fenêtre normalisée

Pour une chaîne `W=(w_1,…,w_j)`, posons `x/10^L=z` et définissons l'état rationnel :

`E_W=(α_W,β_W,λ_W)` avec `λ_W=10^j / ∏_{i=1}^j g_{w_i}`.

La fenêtre normalisée des départs admissibles asymptotiquement est `α_W < z < β_W`, avec ajustement non significatif des extrémités. L'état initial est `E_∅=(1/10,1,1)`.

Le passage `W → Ww` obéit aux relations exactes :

`α' = max(α_W, λ_W v_w)` ; `β' = min(β_W, λ_W u_w)` ; `λ' = 10 λ_W v_w`.

*Preuve.* À la profondeur `j`, toutes les transformations affines ont pour coefficient linéaire `g_W g_{w[:h]}`. La première création à la dernière opération de `w` demande `g_W g_w x ≥ 10^{L+j}` à l'ordre dominant, d'où `z ≥ λ_W v_w`. Chaque préfixe antérieur doit vérifier `<10^{L+j}`, soit `z < λ_W·(2^{q_h}/3^{p_h})`. La contrainte la plus forte est `λ_W u_w`. Leur intersection avec la fenêtre déjà accumulée donne les deux extrema. La nouvelle échelle de normalisation est `10^{j+1}/(g_Wg_w)=10λ_Wv_w`. Pour une chaîne finie, les termes additifs des transformations affines sont `O(10^{-L})` dans ces comparaisons et ne modifient pas la classification si la fenêtre limite est strictement positive ou négative.

## 4. Lemme S19 — Exclusion irréversible par fermeture des fenêtres

Si `α_W ≥ β_W`, aucune extension `Ww` ne peut posséder une fenêtre limite positive. De plus, au cours de chaque extension, `α` ne peut que croître et `β` ne peut que décroître.

*Preuve.* Les formules de S18 sont des intersections de contraintes, donc `α'≥α` et `β'≤β`. Une fenêtre vide ne peut pas redevenir non vide par l'ajout de contraintes. Cela justifie l'élagage exact des préfixes incompatibles (à horizon fini dans la classification des fenêtres limites).

## 5. Lemme S20 — Test de raccordement par deux inégalités

Soit un préfixe dont la fenêtre est strictement positive, `α<β`, et un mot `w` satisfaisant `v_w<u_w` et ne créant pas `II` à la jonction. Alors le mot suivant est admissible asymptotiquement **si et seulement si** :

`v_w < β/λ` **et** `u_w > α/λ`.

*Preuve.* La fenêtre après raccord vaut `(max(α,λv_w), min(β,λu_w))`. Puisque `α<β` et `v_w<u_w`, elle est non vide exactement sous les deux inégalités strictes. Aucune simulation de Syracuse n'est nécessaire pour cette décision à la limite `L→∞`.

## 6. Lemme S21 — Comptage sans énumération de toutes les extensions

Fixons un alphabet de `m` mots admissibles, et ne retenons que les mots pouvant commencer après un mot terminé par `I` (donc ceux commençant par `P`). À un état `(α,β,λ)`, le nombre exact de prochains mots admissibles est la réponse au problème de dominance bidimensionnel :

`#{w : v_w<β/λ et u_w>α/λ}`.

Après compression des deux coordonnées rationnelles et construction d'une table de sommes préfixes, la requête se traite par deux recherches dichotomiques et une lecture de table, en `O(log m)` comparaisons exactes. C'est une **accélération de l'énumération des classes**, pas une preuve d'existence d'une trajectoire infinie.

**Application :** nous avons classifié les 1 501 332 triplets compatibles et compté leurs prolongements par la requête de dominance, sans énumérer directement les 312 900 721 quadruplets : la somme des comptes vaut exactement **143 944 861**. Les résultats des 10 mots de l'étude précédente sont reproduits : **357** triplets, **1 745** quadruplets.

## 7. Résultat S22 — Les contraintes d'ordre supérieur résistent à un graphe de paires

Pour l'alphabet des 133 mots, les comptes ci-dessus fournissent deux certificats computationnels :

- 175 854 triplets sont localement compatibles au niveau de leurs deux paires, mais globalement incompatibles ;
- 10 393 773 quadruplets sont localement compatibles au niveau de leurs deux triplets, mais globalement incompatibles.

Il est donc incorrect de remplacer les contraintes d'une chaîne par la seule liste des arêtes autorisées entre ses mots, ou même par une liste de triplets autorisés. L'état rationnel `(α,β,λ)` conserve la mémoire arithmétique nécessaire **à la classification asymptotique** de toutes les chaînes finies.

Ce constat pour 2 et 3 mots de mémoire ne démontre pas qu'aucune mémoire bornée ne pourrait suffire pour ce même alphabet ; cette propriété plus forte reste à rechercher.

## 8. Retour à la longueur finie et aux retenues Φ–Ψ

La classification asymptotique est vérifiée, quand nécessaire, au moyen du théorème de fenêtre entière S4. Pour une chaîne complète, le nombre après `h` opérations s'écrit :

`x_h=(3^{p_h}x+B_h)/2^{q_h}`.

Chaque étape non finale avant la prochaine création impose `3^{p_h}x+B_h < 2^{q_h}10^{L+j}`, tandis que l'étape terminale impose `3^{p_h}x+B_h ≥ 2^{q_h}10^{L+j}`. Avec la classe résiduelle unique de parité modulo `2^{Q+1}`, l'ensemble exact des départs est une progression arithmétique coupée par un intervalle entier. Les retenues et restes décimaux de l'opérateur Φ–Ψ sont fidèlement pris en compte dans la valeur entière obtenue, **mais les statistiques de leurs cinq portes terminales ne sont pas directement dénombrées dans ce nouveau catalogue** : l'étude actuelle porte sur les mots complets et leurs fenêtres de création.

## 9. Validation et limites

- 133 mots chargés depuis le catalogue des 230 intervalles ; chaque mot se termine par `I`, n'a pas de `II` interne et vérifie `v_w<u_w`.
- 17 689 couples classifiés explicitement en trois classes disjointes : 14 879 positives, 399 contradictoires par parité, 2 411 à fenêtre limite incompatible.
- 2 352 637 triplets classifiés par prolongement des couples positifs ; 1 501 332 fenêtres positives.
- 312 900 721 quadruplets comptés exactement par prolongements des triplets positifs et requêtes de dominance ; 143 944 861 fenêtres positives.
- Contre-vérification indépendante des dix premiers mots avec le programme S13–S17 : 357 triplets et 1 745 quadruplets. 1 500 chaînes supplémentaires, de deux à cinq mots, ont été confrontées aux fenêtres calculées indépendamment, sans divergence.
- Ce catalogue de 133 mots provient de 21 trajectoires records particulières. Il ne constitue pas un alphabet exhaustif universel de tous les mots de première création de tête.
- Ni les proportions des classes, ni les contraintes finies, ni l'automate rationnel ne démontrent la conjecture de Syracuse.

## 10. Suite mathématique proposée

La prochaine étape pertinente est d'ajouter à chaque état de fenêtre `(α,β,λ)` un **état de frontière Φ–Ψ exact** (retenue entrante dans le chiffre de tête, chiffre source, profondeur de réarmement et congruence). Nous pourrons alors mesurer quelles restrictions proviennent seulement des franchissements décimaux et lesquelles nécessitent les informations de pied/corps/tête. Une autre direction consiste à étudier la stabilisation des fenêtres normalisées le long de familles de chaînes dont la profondeur augmente, sans confondre la limite de chaînes distinctes avec l'orbite d'un entier fixé.

### Données reproductibles

`extension_133_mots.py` (stdlib uniquement), `133_classes_mots.csv`, `17689_paires_classifiees.csv`, `133_gre_compatibilite.csv`, `triplets_interdits_malgre_paires.csv`, `quadruplets_interdits_malgre_triplets.csv`, `resultats_133.json` et graphiques.
