#!/usr/bin/env python3
"""Audit exact des cylindres de parite dans 21 prefxes classiques.
Ne suppose ni convergence universelle ni existence d'une orbite divergente.
Bibliotheque standard Python uniquement.
"""
from __future__ import annotations
import csv
from collections import defaultdict
from pathlib import Path

SOURCE = Path('/mnt/data/Syracuse_PhiPsi_Comparaison_21_Prefixes/donnees/toutes_les_5699_transitions.csv')
DEST = Path(__file__).parent / '21_records_rigidification_parite.csv'

def count_residue(lo:int, hi:int, residue:int, mod:int)->int:
    return (hi-residue)//mod - (lo-1-residue)//mod

def run():
    grouped=defaultdict(list)
    for r in csv.DictReader(SOURCE.open(encoding='utf-8')):
        grouped[int(r['depart'])].append(r)
    out=[]
    for n, data in sorted(grouped.items(), key=lambda t:len(str(t[0]))):
        L=len(str(n)); lo=10**(L-1); hi=10**L-1
        assert [int(v['rang']) for v in data] == list(range(len(data)))
        assert int(data[0]['valeur']) == n
        A=1; B=0; q=0; residue=0; mod=1; first=None; maxhead=0
        for j, row in enumerate(data):
            x=int(row['valeur']); maxhead=max(maxhead,int(row['longueur'])-L)
            assert (A*n+B)==(1<<q)*x, (n,j,'state mismatch')
            if j==len(data)-1:break
            parity=x&1
            newmod=1<<(q+1)
            newres=((parity*(1<<q)-B)*pow(A,-1,newmod))%newmod
            assert (n-newres)%newmod==0
            if newmod >= mod:
                assert newres%mod == residue%mod
                mod,residue=newmod,newres
            else:
                assert residue%newmod==newres
            candidates=count_residue(lo,hi,residue,mod)
            assert candidates >= 1
            if candidates==1 and first is None:
                first={'rang':j,'q':q,'mod':mod,'res':residue,'tetes':maxhead,'candidats':candidates}
            if parity:
                A=3*A;B=3*B+(1<<q)
            else:
                q+=1
        out.append({'chiffres_initiaux':L,'depart':n,'rang_premiere_tete_maximale':len(data)-1,
             'divisions_avant_maximum':q,'rang_rigidification':first['rang'] if first else '',
             'divisions_a_rigidification':first['q'] if first else '',
             'module_a_rigidification':first['mod'] if first else '',
             'residu_unique':first['res'] if first else '',
             'tetes_deja_creees':first['tetes'] if first else '',
             'rigidification_avant_maximum': bool(first)})
    with DEST.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=out[0].keys());w.writeheader();w.writerows(out)
    print('Trajectoires',len(out))
    print('Rigidifiees avant le premier record de longueur maximale:',sum(bool(r['rigidification_avant_maximum']) for r in out))
    print('21 chiffres:',out[-1])
    for row in out:print(row['chiffres_initiaux'],row['rang_rigidification'],row['divisions_a_rigidification'],row['tetes_deja_creees'])
if __name__ == '__main__':run()
