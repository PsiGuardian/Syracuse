# Syracuse Φ–Ψ — Familles congruentielles à profondeur non bornée

**Complément aux lemmes S23–S29 — 18 novembre 2026**

## Résultat central

Soit une suite hypothétique infinie `W = (w1,w2,...)` de mots représentant des **premières créations successives de nouvelles longueurs décimales** de la suite classique. À longueur initiale fixée `L`, l'ensemble des départs qui réalisent les `k` premiers mots est

`C_k(L) = { n : 10^(L-1) <= n < 10^L, n réalise w1,...,wk }`.

Les résultats de frontières exactes S23–S29 décrivent chacun de ces ensembles à horizon fini par un intervalle entier et une classe congruentielle. Deux comportements logiques distincts doivent être séparés :

- **L fixé, k → ∞ :** les ensembles sont emboîtés `C_(k+1)(L) ⊆ C_k(L)` dans un ensemble fini. Si tous les `C_k(L)` restent non vides, un entier positif fixe réalise tous les mots et sa trajectoire est non bornée. Une telle construction constituerait un contre-exemple à la conjecture de Syracuse.
- **L variable, k → ∞ :** de nouveaux entiers peuvent réaliser chaque préfixe. Cela n'implique pas qu'un même entier réalise tous les préfixes. L'information congruentielle donne au plus une limite 2-adique, qui n'est pas nécessairement un entier positif.

Aucune de ces observations ne décide si une trajectoire positive non bornée existe.

## Six nouveaux résultats S30–S35

| Référence | Énoncé | Portée |
|---|---|---|
| **S30** | Filtration décroissante et propriété d'intersection finie à `L` fixé | Théorème abstrait, exact |
| **S31** | Un mot terminé par `I` contenant `Q` divisions définit une classe modulo `2^(Q+1)` ; sa prolongation raffinera cette classe | Parité classique |
| **S32** | Dès que le module dépasse `9·10^(L−1)−1`, il reste au plus un candidat de longueur `L` | Borne universelle explicite |
| **S33** | Les préfixes réalisables de longueur initiale variable peuvent converger 2-adiquement vers un entier non positif | Contre-exemple de suites de profondeurs finies |
| **S34** | Si une chaîne infinie de créations n'utilise qu'un alphabet fini de mots, son bilan logarithmique normalisé reste borné | Nécessité conditionnelle |
| **S35** | Sous la même hypothèse, les facteurs normalisés supérieurs et inférieurs à 1 doivent tous deux réapparaître indéfiniment | Nécessité conditionnelle |

Les preuves détaillées figurent dans `Lemmes_S30_S35.tex` et dans le PDF compilé.

## Rigidification exacte des 21 records

Les 21 trajectoires précédemment étudiées ont été réanalysées à partir de leur table des **5 699 états de préfixes**. À chaque rang, le programme reconstruit le résidu du départ à partir des parités des états déjà rencontrés, puis compte les entiers de sa longueur initiale satisfaisant cette congruence. Il n'utilise pas les futures opérations.

| Chiffres initiaux | Premier rang où il ne reste qu'un départ | Divisions consommées | Créations inédites déjà rencontrées | Fin du préfixe étudié |
|---:|---:|---:|---:|---:|
| 2 | 11 | 6 | 1 | 36 |
| 3 | 16 | 9 | 2 | 75 |
| 5 | 31 | 16 | 3 | 69 |
| 10 | 57 | 32 | 3 | 205 |
| 15 | 88 | 49 | 5 | 403 |
| 20 | 113 | 65 | 4 | 502 |
| 21 | **124** | **69** | **6** | **570** |

**20 des 21 préfixes** ont déjà un unique départ compatible avec leur mot de parité avant la première atteinte de leur longueur maximale. Le préfixe du départ `7` (une itération) s'arrête avant cette rigidification.

Pour `274133054632352106267` : au rang classique **124**, après **69 divisions**, le module est `2^70 = 1180591620717411303424`. L'intervalle de tous les départs à 21 chiffres a une largeur `9·10^20−1` ; il ne peut donc contenir qu'une seule valeur dans cette classe, et le résidu est précisément le départ étudié. La trajectoire atteint finalement ses **42 chiffres au rang 570**. Le fait qu'un départ soit isolé ne prédit pas son maximum futur sans analyse supplémentaire.

## Compensation conditionnelle des créations de tête

Après la première opération, chaque nouvelle longueur créée pour la première fois commence par 1, et son état record `y_j` vérifie

`10^(L+j−1) <= y_j < 1.5·10^(L+j−1)`.

Pour le mot `w_j` entre deux records, écrivons `T_w(y)=g_w y+b_w`, où `g_w=3^p/2^q` et `b_w>=0`. Avec la mantisse `z_j = y_j / 10^(L+j−1)`, l'évolution exacte est

`z_(j+1) = (g_(w_j)/10)·z_j + b_(w_j)/10^(L+j)`.

Sous l'hypothèse que les mots appartiennent à un alphabet **fini**, les `b_w` sont bornés et les facteurs positifs `ρ_w = g_w/10` sont minorés. La somme des corrections logarithmiques est donc bornée, d'où, nécessairement,

`P·ln(3) − Q·ln(2) − k·ln(10) = O(1)`

pour toute succession de `k` nouvelles créations suffisamment tardives, où `P` et `Q` totalisent les multiplications et divisions des mots. C'est une **compensation structurelle des facteurs normalisés**, et non une obligation de descente de l'entier.

Pour les 130 mots du catalogue de 133 **commençant par P**, 67 ont `g_w/10 > 1` et 63 ont `g_w/10 < 1` ; aucun n'a `g_w/10 = 1`. Sur les **209 mots postérieurs à une première création** dans les records étudiés, on compte 98 facteurs normalisés > 1 et 111 < 1. Ces effectifs ne constituent pas une preuve d'un comportement asymptotique universel.

## Une précaution essentielle : les limites ne commutent pas

Le résultat S18–S22 indique que, pour une **chaîne finie fixée**, les décalages additifs deviennent négligeables quand la longueur initiale `L` croît. La constante de l'erreur dépend cependant de cette chaîne ; aucune uniformité en profondeur infinie n'a été établie. Il serait donc incorrect de remplacer :

`Pour chaque k, il existe L assez grand et un départ réalisant les k premiers mots`

par :

`Il existe une longueur L et un départ positif réalisant tous les mots`.

Exemple indépendant des premières créations, tiré des profondeurs dyadiques : pour chaque `K`, le départ positif `2^(K+1)−1` réalise `K` blocs impair→impair de profondeur 1. Les classes résiduelles convergent 2-adiquement vers `−1`, non vers un entier positif. Cet exemple illustre pourquoi les préfixes finis ne suffisent pas à prouver l'existence d'une trajectoire positive infinie particulière.

## Ce que l'étude ne démontre pas

Elle ne démontre ni la convergence de tous les entiers, ni l'existence d'un contre-exemple, ni l'impossibilité de toute suite infinie de créations de tête. Elle ne traite pas non plus, à elle seule, d'éventuels cycles non triviaux qui resteraient bornés. La condition logarithmique sur l'alphabet fini est **nécessaire**, pas suffisante.

La question suivante est donc précise : peut-on utiliser conjointement l'état exact `S23–S29`, la rigidification dyadique et la compensation normalisée pour **exclure ou certifier** une chaîne infinie avec une longueur initiale **fixée** ? C'est le verrou mathématique encore ouvert.
