# Syracuse Φ–Ψ — v18, rigidité combinatoire des mots de corridor

**17 novembre 2026 · Annexe de recherche autonome · Texte français**

## Problème traité

Déterminer si la classe 2-adique construite pour le mot critique supérieur v17 correspond à un même entier positif pour tous les horizons, ou si le plus petit représentant non terminal doit tendre vers l'infini.

## Résultats mathématiques

**Théorème de complexité.** Pour une suite infinie de corridors non ultimement périodique réalisable par un entier positif, avec `r_j ∈ {1,2}` et `t_j ≥ 1`, si `p(L)` est le nombre de facteurs de `L` corridors, alors

`p(L) >= (L ln(4) - ln(u0+5))/ln(9/8)`.

La démonstration repose sur :
1. `u_(j+1)+5 <= (9/8)(u_j+5)` pour chaque corridor de `r<=2` ;
2. deux états possédant le même mot de `L` corridors ont une différence multiple de `2^(2L)` ;
3. si la suite infinie est non ultimement périodique, les deux états ne peuvent être égaux.

**Corollaire.** Un mot de corridor non ultimement périodique avec `r<=2` et `p(L)=L+O(1)` ne peut pas être réalisé par un même entier positif.

**Application critique v17.** Le mot supérieur `r_j=1+ceil((j+1)*theta)-ceil(j*theta)`, `t_j=1`, `theta=1/log2(3/2)-1`, possède `p(L)=L+1` et n'est pas ultimement périodique. Il est donc impossible sur un horizon infini pour un entier positif, malgré la réalisabilité de tous ses préfixes finis. La conclusion vaut aussi pour les mots mécaniques de même pente et de phase arbitraire.

**Ce qui n'est PAS prouvé :** la conjecture de Syracuse, l'impossibilité de tous les cycles non terminaux, ou l'exclusion de toute trajectoire divergente. Les mots plus complexes ou les corridors avec `r>=3` ne sont pas exclus par ce théorème.

## Fichiers

- `Syracuse_PhiPsi_v18_Rigidite_Complexite.pdf` : article mathématique complet (4 pages).
- `Syracuse_PhiPsi_v18_Rigidite_Complexite.tex` : source LaTeX compilable directement avec `pdflatex`.
- `PhiPsi_v18_Certificat_Mot_Critique.py` : programme Python 3 sans dépendance pour construire les symboles **exactement par des comparaisons d'entiers** et contrôler les certificats finis.
- `PhiPsi_v18_Certificats_Facteurs_Repetes.csv` : six témoins certifiés pour L=4,8,16,32,64,128.
- `Syracuse_PhiPsi_Complement_v6_et_Annexes_v17_v18.pdf` : compilation de lecture du complément v6 (27 pages) et des annexes v17 (5 pages) et v18 (4 pages) ; les textes précédents y conservent leur statut et leur numérotation originels.

## Reproduction

```bash
python3 PhiPsi_v18_Certificat_Mot_Critique.py \
  --longueurs 4,8,16,32,64,128 \
  --csv PhiPsi_v18_Certificats_Facteurs_Repetes.csv
```

Le programme n'utilise ni logarithmes flottants ni tirage aléatoire pour les preuves finies : `ceil(j*theta)` est déterminé par le plus petit entier `m` vérifiant `3**m > 2**(m+j)`, puis en retranchant `j`.

## Vérifications effectuées

- Concordance des 301 premiers symboles avec les résultats v17 antérieurs calculés à précision décimale élevée.
- Vérification directe de 100 000 inégalités de transfert sur des entiers impairs.
- Exhaustivité modulo `2^H` des mots de parité pour `H=1..9` sur l'intervalle nécessaire.
- Six certificats de répétition de fenêtres : calcul entier des états, de leurs classes modulo les puissances de 2 et de la première divergence ultérieure.
- PDF compilé, extrait en quatre images et contrôlé visuellement.
