#!/usr/bin/env python3
"""Certificats finis exacts pour le mot critique supérieur Φ–Ψ.

Tous les symboles r_j sont obtenus sans logarithmes flottants :
  theta = log_{3/2}(2)-1
  r_j = 1 + ceil((j+1)*theta)-ceil(j*theta)
Les inégalités 3**m > 2**(m+j) donnent ceil(j*theta) exactement.

Sorties : répétitions de facteurs, horizons de séparation et certificats de
coût initial, dans le modèle accéléré U(n).
"""
import csv, argparse, json


def ceil_j_theta(j):
    if j == 0:
        return 0
    assert j > 0
    # ceil(j * theta) = min{m : 3**m > 2**(m+j)} - j
    # because (theta+1)*log2(3/2) = 1.
    lo=j; hi=2*j
    while lo < hi:
        m=(lo+hi)//2
        if pow(3,m) > (1 << (m+j)):
            hi=m
        else:
            lo=m+1
    return lo-j


def stocks(n):
    marks=[ceil_j_theta(j) for j in range(n+1)]
    return [1+marks[j+1]-marks[j] for j in range(n)]


def witness(L, r):
    # Use starts 1,..,L+2; L+2 entries, <=L+1 distinct Sturmian factors.
    groups={}
    collisions=[]
    for i in range(1,L+3):
        factor=tuple(r[i:i+L])
        if factor in groups:
            collisions.append((groups[factor],i))
        else:
            groups[factor]=i
    if not collisions:
        raise AssertionError(('No repeated factor',L))
    best=None
    for i,j in collisions:
        m=L
        while j+m<len(r) and r[i+m]==r[j+m]:
            m+=1
        if j+m>=len(r):
            raise AssertionError(('Need more symbols',L,j,len(r)))
        K=j+m
        info=(K,i,j,m)
        if best is None or info<best:
            best=info
    return best


def val2(n):
    return (n & -n).bit_length()-1


def actual_states(r,K,q0):
    # r has K+1 symbols, t=1 for each corridor.
    q=q0;u=[]
    for j in range(K):
        assert q>0 and q&1
        a=(1 << r[j])*q-1
        assert a>1
        u.append(a)
        numer=pow(3,r[j])*q+1
        denom=1 << (1+r[j+1])
        assert numer%denom==0
        q=numer//denom
        assert q>0 and q&1
    u.append((1 << r[K])*q-1)
    return u


def qmin_at(r,K):
    A=D=1;C=0;threshold=1; rho0=1; prevmod=2
    for j in range(K):
        if r[j]==1:
            # ensure u_j=2*q_j-1>1, i.e. q_j>=3
            bound=-((-(3*D-C))//A) # ceil((3D-C)/A)
            threshold=max(threshold,bound)
        a=pow(3,r[j]);d=1<<(1+r[j+1]);b=1
        C=a*C+b*D; A*=a;D*=d
        M=2*D
        rho=((D-C)*pow(A,-1,M))%M
        assert rho&1 and rho%prevmod==rho0%prevmod
        rho0,prevmod=rho,M
    qmin=rho+max(0,-((-(threshold-rho))//M))*M
    return qmin,rho,M


def build(Ls, max_n=None):
    max_l=max(Ls)
    n=max_n or (max_l*80+100)
    r=stocks(n)
    rows=[]
    for L in Ls:
        K,i,j,m=witness(L,r)
        q,rho,M=qmin_at(r,K)
        u=actual_states(r,K,q)
        H=sum(r[i:i+L])+L
        assert u[i]!=u[j],(L,i,j,u[i])
        assert (u[i]-u[j])%(1<<H)==0
        assert abs(u[i]-u[j]) >= (1<<H)
        assert H>=2*L
        assert q*12 + 3*(L+2) > (1<<(2*L))
        assert r[i+m]!=r[j+m] and m>=L and K==j+m
        row={
            'longueur_L':L,'premier_debut_i':i,'second_debut_j':j,
            'premiere_difference_symbole_m':m,'horizon_K_certifie':K,
            'nombre_de_transitions_communes_H':H,'modules_parite_bits':H,
            'minoration_necessaire_12q0_plus_3L':str(1<<(2*L)),
            'q0_min_bits':q.bit_length(),'q0_min':str(q),
            'rho_K':str(rho),'module_K_bits':M.bit_length()-1,
            'etat_i':str(u[i]),'etat_j':str(u[j]),
            'difference_etats_bits':abs(u[i]-u[j]).bit_length(),
            'val2_difference':val2(abs(u[i]-u[j])),
            'symbole_i_difference':r[i+m],'symbole_j_difference':r[j+m],
        }
        rows.append(row)
    return rows


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--longueurs',default='4,8,16,32,64,128')
    p.add_argument('--csv',default='/mnt/data/PhiPsi_v18_Certificats_Facteurs_Repetes.csv')
    args=p.parse_args()
    Ls=[int(s) for s in args.longueurs.split(',')]
    rows=build(Ls)
    with open(args.csv,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter=';');w.writeheader();w.writerows(rows)
    for a in rows:
        print('L=',a['longueur_L'],'K=',a['horizon_K_certifie'], 'i,j=',(a['premier_debut_i'],a['second_debut_j']), 'm=',a['premiere_difference_symbole_m'], 'H=',a['nombre_de_transitions_communes_H'],'qbits=',a['q0_min_bits'])
    print('CERTIFICATS ARITHMETIQUES VERIFIES')

if __name__=='__main__':
    main()
