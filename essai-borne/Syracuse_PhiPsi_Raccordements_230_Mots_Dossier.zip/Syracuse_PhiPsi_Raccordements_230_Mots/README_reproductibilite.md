# Syracuse Φ–Ψ — Compositions et raccordements de mots

## Contenu

- `donnees_sources/230_intervalles_phi_psi_enrichis.csv` : corpus d'entrée exact des 21 records (230 premières créations de tête).
- `donnees_sources/133_mots_classes_dyadiques.csv` : classes déjà extraites du corpus.
- `Syracuse_PhiPsi_Raccordements_230_Mots/` : 209 raccordements, 193 couples distincts, 25 portes, 7 familles de répétitions W5, figures et rapport.
- `Syracuse_PhiPsi_Raccordements_230_Mots/Lemmes_S1_S8.tex` : lemmes et théorèmes S1 à S8.
- `analyse_raccordements_phi_psi.py`, `completer_raccordements_phi_psi.py`, `analyse_portes_composees.py` : reproductibilité exacte.

## Recalcul sous Python 3

Après extraction de l'archive, depuis son répertoire racine :

```bash
python3 analyse_raccordements_phi_psi.py
python3 completer_raccordements_phi_psi.py
python3 analyse_portes_composees.py
```

Le calcul arithmétique utilise la bibliothèque standard. Les graphiques sont facultatifs et nécessitent `matplotlib`.

Les trois commandes se lancent dans cet ordre : les deux dernières enrichissent le manuscrit et le rapport issus de la première.

## Portée

- Les critères de congruence et de franchissement sont exacts à **tout horizon fini**.
- La loi asymptotique à mots **fixés** s'obtient en faisant grandir la longueur initiale, pas en affirmant qu'un entier fixé possède une trajectoire infinie.
- La matrice des 25 portes est **localement complète**, mais les chaînes globales restent soumises à des contraintes plus fortes ; aucune preuve de la conjecture de Syracuse n'est revendiquée.
- Le théorème d'apériodicité est conditionnel à une hypothétique orbite possédant une infinité de nouvelles longueurs et exclut seulement des **mots de premières créations ultimement périodiques**.
