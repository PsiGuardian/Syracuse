# Syracuse Φ–Ψ — Raccordements exacts des 230 mots de première création de tête

## Périmètre et règles

Corpus : **21 trajectoires records**, **230 intervalles** (premiers franchissements successifs de longueur), **133 mots littéraux**. Chaque trajectoire s'arrête au premier maximum de longueur, non au retour à 1. Un raccordement est une paire consécutive de mots, et il y en a exactement **209** (230 − 21). Les mots sont pris dans la suite *classique* avec `I:3n+1`, `P:n/2` ; les calculs des parités utilisent l'opérateur condensé lorsqu'il est indiqué.

Les nombres ci-dessous sont des observations certifiées sur ces trajectoires ; la section « lemmes » donne des formules universelles pour **tout horizon fini**.

## Bilan du graphe observé

- 209 raccordements consécutifs et **193 couples ordonnés de mots distincts**.
- 8 types de couples apparaissent plusieurs fois, totalisant 24 occurrences.
- 1 raccordements relient un mot au même mot.
- 120 classes de mots ont au moins un raccord sortant, 130 au moins un raccord entrant.
- Distribution des réarmements `P^a` au début du mot suivant : a=1 : 152, a=2 : 50, a=3 : 7.
- 193 types de couples observés ont une fenêtre **strictement positive dans la limite des longueurs élevées** (le résultat est conditionné au mot fixé).

### Couples de mots les plus récurrents

| Mot précédent | Mot suivant | Observations | Réarmement `a` | Longueurs différentes |
|---|---|---:|---:|---:|
| `I` | `PIPIPIPI` | 8 | 1 | 8 |
| `PIPIPIPIPI` | `PIPIPIPIPIPI` | 4 | 1 | 4 |
| `I` | `PIPIPPIPIPIPI` | 2 | 1 | 2 |
| `PIPIPIPIPIPI` | `PIPIPIPIPIPPIPI` | 2 | 1 | 2 |
| `PIPIPIPIPIPI` | `PIPIPIPIPI` | 2 | 1 | 2 |
| `PIPIPIPIPIPPIPI` | `PIPIPIPIPIPI` | 2 | 1 | 2 |
| `PIPIPIPIPIPI` | `PIPPIPIPIPIPIPI` | 2 | 1 | 2 |
| `PIPPIPIPIPIPIPI` | `PIPIPIPIPIPI` | 2 | 1 | 2 |
| `IPI` | `PPIPIPIPIPIPPIPPIPIPPIPIPIPPIPIPI` | 1 | 2 | 1 |
| `PIPIPIPI` | `PIPPIPPIPIPIPIPIPIPPIPIPPIPPIPIPIPP` | 1 | 1 | 1 |
| `PIPIPIPI` | `PIPPIPIPIPIPIPI` | 1 | 1 | 1 |
| `PIPPIPIPIPIPIPI` | `PIPIPPIPIPPIPIPIPIPI` | 1 | 1 | 1 |

## Loi de composition exacte

Pour tout mot valide `w`, écrire `T_w(x)=(3^p x+B_w)/2^q`. Pour deux mots `w` puis `v`,

`T_(v∘w)(x)=[3^(p_w+p_v) x + 3^(p_v) B_w + 2^(q_w) B_v] / 2^(q_w+q_v)`.

Une concordance de motifs de frontières (mêmes retenues en tête, même profondeur terminale, etc.) ne suffit pas à certifier un raccord : il faut la **classe résiduelle complète** et les **bornes de première création** pour les deux étapes. L'intervalle intersection est une fenêtre entière exacte `[A_(w,v)(L),Z_(w,v)(L)]` intersectée avec une classe unique modulo `2^(q_w+q_v+1)`.

Toutes les **209** observations satisfont cette identité, leur classe résiduelle composée et les contraintes de premier franchissement, sans contradiction arithmétique. Des candidats pour plusieurs longueurs ont été reconstruits et vérifiés directement : 78 contrôles indépendants.

## Le point important : admissibilité ≠ observation

Le graphe des 209 raccords observés est un **sous-graphe** de l'ensemble des raccordements mathématiquement admissibles. Une arête absente du corpus n'est pas interdite. Inversement, assembler deux mots simplement parce que leurs signatures locales coïncident peut inventer une fausse arête : la classe dyadique et les seuils de longueur doivent rester compatibles.

## Stabilité pour l'augmentation décimale L → L+1

À mot composé `v∘w` **fixé** et longueur initiale `L` variable, les états initiaux admissibles satisfont des inégalités affines de la forme `3^p x+B < 2^q 10^(L+j)` ou `≥` pour les premières créations. En posant `z=x/10^L`, les corrections `B/10^L` s'annulent lorsque `L→∞`. On obtient un intervalle fermé à ses frontières `α≤z≤β` à ajuster pour les inégalités strictes. Pour `α<β`, le nombre de départs admissibles croît asymptotiquement comme :

`C_(w,v)(L) = ((β−α)/2^(q_w+q_v+1))·10^L + O(1)`.

Il s'agit d'un théorème de **stabilisation des fenêtres de mots finis**. Il ne certifie pas l'existence d'une seule orbite positive dont les créations se répètent indéfiniment.

## Exemple : W5=PIPIPIPIPIPI

`W5(x)=(729x+1330)/64`, classe initiale `x≡126 mod128`.

Pour la **double composition** `W5 | W5`, les résultats exacts sont :

| Chiffres initiaux L | Candidats admissibles | Premier candidat si non nul |
|---:|---:|---:|
| 6 | 2 | 106494 |
| 8 | 191 | 10002430 |
| 12 | 1905542 | 100000006142 |
| 20 | 190554192369190 | 10000000000000008190 |
| 30 | 1905541923691905592530497 | 100000000000000000000000008190 |

Ces candidats sont construits pour la succession exacte des deux franchissements. Le nombre de mots successifs fixé reste fini.

## Lemmatisation proposée

**S1 — Composition affine des mots** : formule de composition, preuve par substitution.

**S2 — Congruence dyadique du mot composé** : une classe unique modulo `2^(Q+1)` où `Q` compte les divisions avant le dernier `I`, calculable par inversion de `3^p` modulo `2^(Q+1)`.

**S3 — Raccord exact de réarmement** : si le premier mot se termine par `3u+1`, le second commence par `P^a` avec `a=ν₂(3u+1)` ; une signature réduite ne détermine pas `a` indépendamment de la valeur de `u`.

**S4 — Fenêtre entière d'une chaîne de créations** : pour une liste finie de mots et des frontières décimales successives, l'ensemble des départs est une progression arithmétique unique tronquée par un intervalle entier explicite ; nombre exact par divisions entières.

**S5 — Stabilisation asymptotique des fenêtres finies** : à mots fixes, fenêtre normalisée limite ; densité de candidats `((β−α)/2^(Q+1))10^L + O(1)` si `α<β`.

**S6 — Non-clôture par la seule porte de tête** : conserver seulement les cinq portes et les longueurs peut autoriser des compositions non réalisées par un entier ; la congruence complète et les bornes numériques rétablissent la fidélité.

L'intégralité des 209 raccordements (et les couples de mots distincts) est donnée dans les CSV. Les statistiques ne démontrent aucune propriété des orbites infinies.

## Résultat S6 — Une suite infinie de mots de première création ne peut être ultimement périodique

**Théorème conditionnel universel.** Supposons qu'une trajectoire positive possède une infinité de créations inédites de positions décimales. Sa suite de mots complets reliant ces créations ne peut pas devenir périodique après un certain rang.

*Preuve.* Toutes les nouvelles créations suffisamment tardives ont une mantisse entre 1 et (asymptotiquement) 1,5. Si un paquet fixe de `k` mots se répète, la valeur après ce paquet suit `y' = (3^P/2^Q)y + b`, avec `b≥0`. Après renormalisation des `k` nouvelles positions, sa mantisse satisfait `z' = ρ z + b/10^(longueur suivante−1)`, où `ρ = 3^P/(2^Q 10^k)`. Si `ρ>1`, les mantisses dépassent nécessairement 1,5. Si `ρ<1`, elles tendent à zéro, contrairement à leur borne inférieure 1. `ρ=1` exigerait une égalité impossible entre puissances de 2, 3 et 5. Donc une telle périodicité est exclue. Cette démonstration ne présuppose pas la convergence de Syracuse.

## Résultat S7 — Répétition finie du mot W5

Pour `W5=PIPIPIPIPIPI`, `T(x)=(729/64)(x+2)−2`. Nous avons construit une répétition de trois mots `W5`, réalisant **trois premières créations de tête successives**, à partir de `1 000 341 502` (10 chiffres) :

- 12 opérations : `11 394 514 942` (11 chiffres) ;
- 24 opérations : `129 790 646 782` (12 chiffres) ;
- 36 opérations : `1 478 396 586 022` (13 chiffres).

Mais **quatre répétitions consécutives sont universellement impossibles**, à toute longueur initiale, parce que `(729/640)^4 > 3/2` et que la quatrième valeur devrait alors dépasser la borne imposée par une première création tardive de tête. La démonstration formelle figure dans `Lemmes_S1_S5.tex` (désormais S1 à S7). `repetitions_W5_exactes.csv` donne les classes et fenêtres pour une à sept répétitions.

## Élargissement de l'espace des raccordements

Parmi les dix mots les plus fréquents de longueur inférieure à 18 opérations, une matrice de compatibilité construite à 12 chiffres compte **57 couples admissibles** (sur 100 couples candidats) sans exiger que l'un d'eux ait été observé sur les 21 records. Les fenêtres exactes et leurs nombres de candidats sont dans `matrice_admissibilite_10_mots.csv` ; une représentation figure dans `matrice_admissibilite_10_mots_L12.png`.

La compatibilité d'un nombre fini de mots ne signifie pas qu'ils puissent se répéter à l'infini pour un même entier.

## Résultat S8 — Les 25 raccords locaux entre les cinq portes sont réalisés

Sur les **193 jonctions tardives→tardives**, tous les **25 couples ordonnés** issus des cinq signatures de tête `(3,1),(3,2),(4,0),(4,1),(4,2)` sont effectivement représentés. Ceci est un résultat de corpus vérifié : on ne doit pas le confondre avec 25 classes de comportements globaux.

Le résultat est plus fort : en imposant les deux signatures de tête par des inégalités exactes sur les chiffres et les retenues, les 25 paires disposent chacune d'un couple de mots témoin avec une fenêtre **normalisée de largeur strictement positive**. Par stabilisation des fenêtres affines, **chacun des 25 raccords de porte est réalisable à toute longueur initiale suffisamment grande**, pour une paire de mots témoin fixe dépendant de la porte. Une vérification explicite fournit déjà des candidats pour ces 25 paires à 12 chiffres ; ce constat fini n'est pas utilisé pour prouver la généralisation.

Fichiers : `25_jonctions_portes_fideles.csv` (25 certificats rationnels et mots témoins), `matrice_25_portes_phi_psi.png` (occurrences), preuve dans S8 du manuscrit TeX.

**Limite décisive** : la complétude de toutes les paires adjacentes de portes n'implique pas la compatibilité de toutes les chaînes de trois portes ou davantage, ni celle d'une chaîne infinie pour un entier fixé. L'état complet et toutes les contraintes intermédiaires restent indispensables.
