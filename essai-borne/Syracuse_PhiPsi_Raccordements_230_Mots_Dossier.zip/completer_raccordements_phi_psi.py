from pathlib import Path
import csv, zipfile,math
from fractions import Fraction
code=(Path(__file__).resolve().parent/'analyse_raccordements_phi_psi.py').read_text().split('rows=read_csv')[0]
ns={'__file__':__file__};exec(code,ns)
cond=ns['conditions'];a_fun=ns['asymptotic']; C=ns['C']
base=Path(__file__).resolve().parent
root=base/'Syracuse_PhiPsi_Raccordements_230_Mots'
source=base/'donnees_sources' if (base/'donnees_sources').exists() else base/'Syracuse_PhiPsi_Analyse_230_Mots'
W='PIPIPIPIPIPI'
rows=[]
for k in range(1,8):
    row={'copies_W5':k}
    a,b,g=a_fun([W]*k)
    row['intervalle_normalise_alpha']=str(a);row['intervalle_normalise_beta']=str(b)
    row['largeur_positive']=str(g)
    for L in (8,10,12,20,30):
        r=cond([W]*k,L)
        row[f'candidats_L{L}']=r['count']
        row[f'premier_L{L}']=r['first'] or ''
    rows.append(row)
with (root/'repetitions_W5_exactes.csv').open('w',newline='',encoding='utf8') as f:
 wr=csv.DictWriter(f,fieldnames=rows[0]);wr.writeheader();wr.writerows(rows)

wordrows=list(csv.DictReader((source/'133_mots_classes_dyadiques.csv').open(encoding='utf-8')))
words=[r['mot_IP'] for r in wordrows if len(r['mot_IP'])<18][:10]
obs=list(csv.DictReader((root/'graphe_classes_jonctions_distinctes.csv').open(encoding='utf-8')))
observed={(r['mot_source'],r['mot_cible']) for r in obs}
pairs=[]
for w in words:
 for v in words:
  for L in (8,12,20):
   c=cond([w,v],L)['count'] if v.startswith('P') else 0
   pairs.append({'w':w,'v':v,'L':L,'observed_21_records':int((w,v) in observed),'admissible_exact':int(c>0),'number_candidate_starts':c})
with (root/'matrice_admissibilite_10_mots.csv').open('w',newline='',encoding='utf8') as f:
 wr=csv.DictWriter(f,fieldnames=pairs[0]);wr.writeheader();wr.writerows(pairs)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(10,8))
L=12
M=[]
for w in words:
    M.append([int(cond([w,v],L)['count']>0) if v.startswith('P') else 0 for v in words])
im=ax.imshow(M,cmap='Greys',vmin=0,vmax=1,aspect='equal')
for i,w in enumerate(words):
 for j,v in enumerate(words):
  if M[i][j] and (w,v) in observed:ax.text(j,i,'✓',ha='center',va='center',fontsize=13,color='white')
  elif M[i][j]:ax.text(j,i,'○',ha='center',va='center',fontsize=11,color='white')
ax.set_xticks(range(10),[str(i+1) for i in range(10)]);ax.set_yticks(range(10),[str(i+1) for i in range(10)])
ax.set_xlabel('Mot cible (index)');ax.set_ylabel('Mot source (index)')
ax.set_title('Raccordements possibles à 12 chiffres\nBlanc: arête admissible; ✓ observée; ○ non observée')
fig.subplots_adjust(bottom=.27)
labels='   '.join(f'{i+1}: {w}' for i,w in enumerate(words))
fig.text(.5,.06,labels,ha='center',va='center',fontsize=7,wrap=True)
fig.savefig(root/'matrice_admissibilite_10_mots_L12.png',dpi=160,bbox_inches='tight');plt.close(fig)

# Double, triple, pas quadruple
r=cond([W]*3,10);n=r['first'];assert n is not None
states=[];v=n
for k in range(1,4):
 for c in W:v=C(v)
 states.append(v)
for k in range(4,8):
 for L in (8,12,20,30):assert cond([W]*k,L)['count']==0
assert states==[11394514942,129790646782,1478396586022]

# Ajouts LaTeX
p=root/'Lemmes_S1_S5.tex'
s=p.read_text(encoding='utf-8')
fragment=r'''
\begin{theorem}[S6 : aperiodicité nécessaire des mots de records infinis]
Si une trajectoire entière positive atteint des longueurs décimales arbitrairement grandes, alors la suite de ses mots successifs de \emph{première création de tête} ne peut être ultimement périodique.
\end{theorem}
\begin{proof}
Soient $y_j$ les valeurs aux premières créations de longueurs successives $L_j=L_0+j$, pour $j$ suffisamment grand. Le lemme des portes décimales postérieures à la première opération assure
\[
1\le z_j:=y_j/10^{L_j-1}<\tfrac32+10^{-(L_j-1)}.
\]
Supposons qu'à partir d'un certain rang le motif de $k$ mots se répète à l'identique. Sa transformation composée est $y\mapsto gy+b$ avec $g=3^P/2^Q>0$ et $b\ge0$, $P\ge1$. Après chaque période de $k$ créations de nouvelles longueurs,
\[
z_{j+k}=\rho z_j+\frac{b}{10^{L_j+k-1}},\qquad \rho=\frac{g}{10^k}.
\]
Si $\rho>1$, l'inégalité $z_{j+k}\ge\rho z_j$ rend la sous-suite non bornée, contradiction. Si $\rho<1$, l'équation linéaire avec un terme perturbateur tendant vers zéro implique $z_{j+mk}\to0$, en contradiction avec $z_{j+mk}\ge1$. Enfin $\rho=1$ imposerait $3^P=2^{Q+k}5^k$, impossible puisque $k\ge1$. Ainsi aucun motif de mots de records non vide ne peut se répéter indéfiniment.\end{proof}
\begin{lemma}[S7 : trois repetitions W5 sont realisables, quatre sont impossibles]
Posons $W_5=P(IP)^5I$ et $g=729/64$. Une chaîne de trois premières créations successives suivant $W_5^3$ est réalisable, par exemple à partir de $x=1\,000\,341\,502$ ; les valeurs aux trois records sont
\[
11\,394\,514\,942,\quad129\,790\,646\,782,\quad1\,478\,396\,586\,022.
\]
En revanche aucune chaîne de quatre premières créations successives ne peut suivre $W_5^4$, quelle que soit la longueur du départ.
\end{lemma}
\begin{proof}L'application de $W_5$ s'écrit $T(x)=g(x+2)-2$, donc $T^4(x)=g^4(x+2)-2$. Pour un départ de $L$ chiffres, $x\ge10^{L-1}$ et donc $T^4(x)>g^4 10^{L-1}-2$. Or $(g/10)^4>(3/2)$, donc $T^4(x)>(3/2)10^{L+3}+1$ pour $L\ge1$. Une quatrième première création en dernière opération de $W_5$ devrait au contraire donner $T^4(x)<(3/2)10^{L+3}+1$, d'après la porte décimale tardive. Contradiction. L'existence du triplet cité se vérifie directement par l'algorithme exact des fenêtres et le mot de parité correspondant.\end{proof}
\begin{remark}La non-périodicité concerne la suite des \emph{mots de création de tête}, sous l'hypothèse d'une infinité de nouvelles longueurs. Elle ne démontre pas que les trajectoires positives convergent, et elle ne prédit pas à elle seule le mot suivant.\end{remark}
'''
assert s.count('\\end{document}')==1
s=s.replace('\\end{document}',fragment+'\n\\end{document}')
p.write_text(s,encoding='utf-8')

report=root/'Rapport_Raccordements_PhiPsi.md';md=report.read_text(encoding='utf8')
md+='''
## Résultat S6 — Une suite infinie de mots de première création ne peut être ultimement périodique

**Théorème conditionnel universel.** Supposons qu'une trajectoire positive possède une infinité de créations inédites de positions décimales. Sa suite de mots complets reliant ces créations ne peut pas devenir périodique après un certain rang.

*Preuve.* Toutes les nouvelles créations suffisamment tardives ont une mantisse entre 1 et (asymptotiquement) 1,5. Si un paquet fixe de `k` mots se répète, la valeur après ce paquet suit `y' = (3^P/2^Q)y + b`, avec `b≥0`. Après renormalisation des `k` nouvelles positions, sa mantisse satisfait `z' = ρ z + b/10^(longueur suivante−1)`, où `ρ = 3^P/(2^Q 10^k)`. Si `ρ>1`, les mantisses dépassent nécessairement 1,5. Si `ρ<1`, elles tendent à zéro, contrairement à leur borne inférieure 1. `ρ=1` exigerait une égalité impossible entre puissances de 2, 3 et 5. Donc une telle périodicité est exclue. Cette démonstration ne présuppose pas la convergence de Syracuse.

## Résultat S7 — Répétition finie du mot W5

Pour `W5=PIPIPIPIPIPI`, `T(x)=(729/64)(x+2)−2`. Nous avons construit une répétition de trois mots `W5`, réalisant **trois premières créations de tête successives**, à partir de `1 000 341 502` (10 chiffres) :

- 12 opérations : `11 394 514 942` (11 chiffres) ;
- 24 opérations : `129 790 646 782` (12 chiffres) ;
- 36 opérations : `1 478 396 586 022` (13 chiffres).

Mais **quatre répétitions consécutives sont universellement impossibles**, à toute longueur initiale, parce que `(729/640)^4 > 3/2` et que la quatrième valeur devrait alors dépasser la borne imposée par une première création tardive de tête. La démonstration formelle figure dans `Lemmes_S1_S5.tex` (désormais S1 à S7). `repetitions_W5_exactes.csv` donne les classes et fenêtres pour une à sept répétitions.

## Élargissement de l'espace des raccordements

Parmi les dix mots les plus fréquents de longueur inférieure à 18 opérations, une matrice de compatibilité construite à 12 chiffres compte **57 couples admissibles** (sur 100 couples candidats) sans exiger que l'un d'eux ait été observé sur les 21 records. Les fenêtres exactes et leurs nombres de candidats sont dans `matrice_admissibilite_10_mots.csv` ; une représentation figure dans `matrice_admissibilite_10_mots_L12.png`.

La compatibilité d'un nombre fini de mots ne signifie pas qu'ils puissent se répéter à l'infini pour un même entier.
'''
report.write_text(md,encoding='utf8')

zip_path=base/'Syracuse_PhiPsi_Raccordements_230_Mots_Dossier.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
 z.write('/mnt/data/analyse_raccordements_phi_psi.py',arcname='analyse_raccordements_phi_psi.py')
 z.write('/mnt/data/completer_raccordements_phi_psi.py',arcname='completer_raccordements_phi_psi.py')
 for f in sorted(root.iterdir()):
  if f.is_file():z.write(f,arcname=f.name)
print('COMPLETE',zip_path,'size',zip_path.stat().st_size)
