from pathlib import Path
from fractions import Fraction
import csv,json,zipfile
ns={'__file__':__file__};exec((Path(__file__).resolve().parent/'analyse_raccordements_phi_psi.py').read_text().split('rows=read_csv')[0],ns)
conditions=ns['conditions'];asym=ns['asymptotic'];pref=ns['word_prefixes'];divceil=ns['divceil']
base=Path(__file__).resolve().parent
root=base/'Syracuse_PhiPsi_Raccordements_230_Mots'
edges=list(csv.DictReader((root/'209_jonctions_observees_et_certifiees.csv').open(encoding='utf8')))
late=[e for e in edges if int(e['rang_jonction'])>1]

def porte(w):
    d,c,h=map(int,w.split('|'));assert d in (3,4) and c in (0,1,2) and h==1
    assert (d!=3 or c!=0)
    return d,c

def ported_conditions(words,portes,L):
    base=conditions(words,L)
    left,right=base['lo'],base['hi']
    cum=0
    allpr=pref(''.join(words))
    for i,(w,port) in enumerate(zip(words,portes)):
        d,c=porte(port)
        # Etat au dernier I du mot, avant cette operation
        A,B,D,_,_=allpr[cum+len(w)-2]
        ten=10**(L+i-1)
        lo_t=max(0,divceil(c*ten-1,3));hi_t=min(ten-1,((c+1)*ten-2)//3)
        lo_u=d*ten+lo_t;hi_u=d*ten+hi_t
        left=max(left,divceil(D*lo_u-B,A))
        right=min(right,(D*hi_u-B)//A)
        cum+=len(w)
    r,mod=base['r'],base['mod']
    lower=divceil(left-r,mod);upper=(right-r)//mod
    count=max(0,upper-lower+1)
    return {'lo':left,'hi':right,'r':r,'mod':mod,'count':count,'first':(r+lower*mod) if count else None}

def ported_limit(words,portes):
    alpha,beta,gap=asym(words)
    P=pref(''.join(words))
    cursor=0
    for i,(w,port) in enumerate(zip(words,portes)):
        d,c=porte(port)
        A,B,D,_,_=P[cursor+len(w)-2]
        g=Fraction(A,D)
        q=Fraction(10**i,10)
        alpha=max(alpha,q*(Fraction(3*d+c,3))/g)
        beta=min(beta,q*(Fraction(3*d+c+1,3))/g)
        cursor+=len(w)
    return alpha,beta,max(Fraction(0),beta-alpha)

for e in late:
    words=[e['mot_avant'],e['mot_apres']];portes=[e['porte_avant'],e['porte_apres']];L=int(e['longueur_entree'])
    x=int(e['etat_entree'])
    ans=ported_conditions(words,portes,L)
    assert ans['count']>0 and ans['lo']<=x<=ans['hi'] and x%ans['mod']==ans['r'],(e,ans)

# Pour chacune des 25 paires, choisir un couple de mots admettant une zone de positivite a la limite
D={}
for e in late:
    p=(e['porte_avant'],e['porte_apres'])
    a,b,g=ported_limit([e['mot_avant'],e['mot_apres']],[e['porte_avant'],e['porte_apres']])
    if g>0:
        if p not in D or int(e['n_divisions'])<int(D[p]['n_divisions']):D[p]=e
Pnames=['3|1|1','3|2|1','4|0|1','4|1|1','4|2|1']
assert len(D)==25,('ports non certifiables pour toutes grandes longueurs', set((u,v) for u in Pnames for v in Pnames)-set(D))

rows=[]
for (u,v),e in sorted(D.items()):
    w,z=e['mot_avant'],e['mot_apres']
    a,b,g=ported_limit([w,z],[u,v])
    assert g>0
    counts={L:ported_conditions([w,z],[u,v],L)['count'] for L in (8,10,12,20,30)}
    rows.append({'porte_avant':u,'porte_apres':v,'mot_temoin_avant':w,'mot_temoin_apres':z,
      'valeurs_observees_dans_corpus':sum(int(x['porte_avant']==u and x['porte_apres']==v) for x in late),
      'alpha':str(a),'beta':str(b),'largeur':str(g),'total_divisions':int(e['n_divisions']),
      **{f'candidats_L{L}':counts[L] for L in counts}})
assert all(r['candidats_L12']>0 for r in rows)
with (root/'25_jonctions_portes_fideles.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('25 types portes validés positive asympt',len(rows))
for L in (8,10,12,20):print('L',L,'realizable port pairs',sum(r[f'candidats_L{L}']>0 for r in rows))

# Matrix of observations only 25 local portals
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
obs={(u,v):sum(e['porte_avant']==u and e['porte_apres']==v for e in late) for u in Pnames for v in Pnames}
fig,ax=plt.subplots(figsize=(9,7)); mat=[[obs[(a,b)] for b in Pnames] for a in Pnames]
im=ax.imshow(mat,cmap='Blues',aspect='equal')
for i in range(5):
 for j in range(5):ax.text(j,i,mat[i][j],va='center',ha='center',color='white' if mat[i][j]>13 else 'black',fontsize=12)
labels=[s.replace('|1','') for s in Pnames]
ax.set_xticks(range(5),Pnames);ax.set_yticks(range(5),Pnames)
ax.set_xlabel('Porte de création suivante (d | c | retenue sortante)')
ax.set_ylabel('Porte de création précédente')
ax.set_title('Les 25 raccords entre portes Φ–Ψ sont réalisés\n193 jonctions de records postérieures à la première opération')
fig.colorbar(im,ax=ax,label='Occurrences observées')
fig.tight_layout();fig.savefig(root/'matrice_25_portes_phi_psi.png',dpi=170);plt.close(fig)

p=root/'Lemmes_S1_S5.tex'
s=p.read_text(encoding='utf8')
fragment=r'''
\begin{theorem}[S8 : complétude des 25 raccordements de portes à grande longueur]
Notons $\mathcal P=\{(3,1),(3,2),(4,0),(4,1),(4,2)\}$ les cinq signatures locales de première création de tête après la première opération, où le premier nombre est le chiffre de tête de la source et le second la retenue entrante en cette position. Pour chaque paire ordonnée $(p,p')\in\mathcal P^2$, il existe une paire fixée de mots de première création successifs $w,v$ et un entier $L_0(p,p')$ tels que, pour toute longueur décimale initiale $L\ge L_0(p,p')$, au moins un départ de longueur $L$ réalise successivement ces deux mots avec les portes $(p,p')$. 
\end{theorem}
\begin{proof}Le calcul exact joint fournit pour les 25 paires de portes un couple témoin $w,v$ observé sur une trajectoire record, et un intervalle normalisé de valeurs initiales $\alpha_{p,p'}<x/10^L<\beta_{p,p'}$ de largeur strictement positive pour lequel les mots, les deux premières créations, et les deux signatures de porte sont satisfaits dans la limite $L\to\infty$. Les bornes sur les chiffres de tête et leurs retenues sont des inégalités entières affines supplémentaires, car pour une source $u=d10^{K-1}+t$ la retenue en tête vaut $c=\lfloor(3t+1)/10^{K-1}\rfloor$. L'argument de S5, appliqué à ces contraintes, donne un nombre de départs de la classe congruentielle qui croît comme $(\beta-\alpha)10^L/2^{Q+1}+O(1)$ ; il est donc strictement positif pour tout $L$ assez grand. Comme $\mathcal P^2$ est fini, un même seuil $L_0$ peut être choisi par maximum. Les intervalles rationnels et mots témoins sont consignés dans \texttt{25\_jonctions\_portes\_fideles.csv}.\end{proof}
\begin{remark}La complétude locale de $\mathcal P^2$ ne signifie pas que toute suite infinie de portes est réalisable par un entier positif fixé. Les contraintes globales des mots, congruences et frontières doivent être vérifiées pour les chaînes entières.\end{remark}
'''
s=s.replace('\\end{document}',fragment+'\n\\end{document}')
p.write_text(s,encoding='utf8')

r=root/'Rapport_Raccordements_PhiPsi.md'
t=r.read_text(encoding='utf8')
t+='''
## Résultat S8 — Les 25 raccords locaux entre les cinq portes sont réalisés

Sur les **193 jonctions tardives→tardives**, tous les **25 couples ordonnés** issus des cinq signatures de tête `(3,1),(3,2),(4,0),(4,1),(4,2)` sont effectivement représentés. Ceci est un résultat de corpus vérifié : on ne doit pas le confondre avec 25 classes de comportements globaux.

Le résultat est plus fort : en imposant les deux signatures de tête par des inégalités exactes sur les chiffres et les retenues, les 25 paires disposent chacune d'un couple de mots témoin avec une fenêtre **normalisée de largeur strictement positive**. Par stabilisation des fenêtres affines, **chacun des 25 raccords de porte est réalisable à toute longueur initiale suffisamment grande**, pour une paire de mots témoin fixe dépendant de la porte. Une vérification explicite fournit déjà des candidats pour ces 25 paires à 12 chiffres ; ce constat fini n'est pas utilisé pour prouver la généralisation.

Fichiers : `25_jonctions_portes_fideles.csv` (25 certificats rationnels et mots témoins), `matrice_25_portes_phi_psi.png` (occurrences), preuve dans S8 du manuscrit TeX.

**Limite décisive** : la complétude de toutes les paires adjacentes de portes n'implique pas la compatibilité de toutes les chaînes de trois portes ou davantage, ni celle d'une chaîne infinie pour un entier fixé. L'état complet et toutes les contraintes intermédiaires restent indispensables.
'''
r.write_text(t,encoding='utf8')
zip_path=base/'Syracuse_PhiPsi_Raccordements_230_Mots_Dossier.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
 for file in ['/mnt/data/analyse_raccordements_phi_psi.py','/mnt/data/completer_raccordements_phi_psi.py','/mnt/data/analyse_portes_composees.py']:
  z.write(file,arcname=Path(file).name)
 for f in sorted(root.iterdir()):
  if f.is_file():z.write(f,arcname=f.name)
print('rearchive',zip_path,zip_path.stat().st_size)
