#!/usr/bin/env python3
"""Raccordements exacts des mots de creation de tete Syracuse Phi-Psi.
Source: 230_intervalles_phi_psi_enrichis.csv (premiers records des 21 trajectoires).
Sans dependances pour les CSV/rapport. Optionnel: matplotlib pour le schema.
"""
from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction
import csv,json,math,random,statistics,zipfile

BASE=Path(__file__).resolve().parent
ROOT=BASE/'donnees_sources' if (BASE/'donnees_sources').exists() else BASE/'Syracuse_PhiPsi_Analyse_230_Mots'
OUT=BASE/'Syracuse_PhiPsi_Raccordements_230_Mots'
OUT.mkdir(parents=True,exist_ok=True)

def read_csv(path):
    with path.open(encoding='utf-8',newline='') as f: return list(csv.DictReader(f))
def save_csv(name,data):
    if not data: return
    with (OUT/name).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)

def divceil(a,b): return -((-a)//b)
def word_prefixes(w):
    assert w and w[-1]=='I' and 'II' not in w and set(w)<={'I','P'}
    A,B,D,p,q=1,0,1,0,0
    out=[]
    for c in w:
        if c=='I': A*=3; B=3*B+D; p+=1
        else: D*=2; q+=1
        out.append((A,B,D,p,q))
    return out

def residue(w):
    prefixes=word_prefixes(w)
    if len(w)==1:return 1,2
    # Parite finale de l'entree precedant le dernier I
    A,B,D,p,q=prefixes[-2]
    mod=2*D
    r=((D-B)*pow(A,-1,mod))%mod
    return r,mod

def C(n):return 3*n+1 if n&1 else n//2

def conditions(words,L):
    # Intersection d'un intervalle entier avec la classe des mots concaténés
    full=''.join(words)
    pr=word_prefixes(full)
    left,right=10**(L-1),10**L-1
    consumed=0
    for level,w in enumerate(words):
        th=10**(L+level)
        for i in range(len(w)):
            A,B,D,_,_=pr[consumed+i]
            if i==len(w)-1:
                left=max(left,divceil(D*th-B,A))
            else:
                right=min(right,(D*th-1-B)//A)
        consumed+=len(w)
    r,mod=residue(full)
    low_k=divceil(left-r,mod)
    high_k=(right-r)//mod
    count=max(0,high_k-low_k+1)
    first=r+low_k*mod if count else None
    last=r+high_k*mod if count else None
    return dict(lo=left,hi=right,r=r,mod=mod,count=count,first=first,last=last,p=full.count('I'),q=full.count('P'),word=full)

def asymptotic(words):
    full=''.join(words);pr=word_prefixes(full)
    alpha=Fraction(1,10);beta=Fraction(1,1)
    cursor=0
    for level,w in enumerate(words):
        base=10**level
        for i in range(len(w)):
            A,B,D,p,q=pr[cursor+i]
            cut=Fraction(base*D,A)
            if i==len(w)-1:alpha=max(alpha,cut)
            else: beta=min(beta,cut)
        cursor+=len(w)
    gap=max(Fraction(0),beta-alpha)
    return alpha,beta,gap

def sig(row):return f"{row['chiffre_tete_source']}|{row['retenue_entree_tete']}|{row['retenue_sortie_tete']}"

rows=read_csv(ROOT/'230_intervalles_phi_psi_enrichis.csv')
assert len(rows)==230
bydep=defaultdict(list)
for row in rows:
    bydep[int(row['depart'])].append(row)
for seq in bydep.values():
    seq.sort(key=lambda r:int(r['numero_tete']))
    for a,b in zip(seq,seq[1:]):
        assert int(a['fin_etat'])==int(b['debut_etat'])
        assert int(a['rang_fin'])==int(b['rang_debut'])
        assert int(b['nouvelle_longueur'])==int(a['nouvelle_longueur'])+1
        assert b['mot_IP'][0]=='P'

for row in rows:
    w=row['mot_IP'];r,mod=residue(w)
    assert r==int(row['residu_dyadique']) and mod==int(row['modulo_dyadique']),(w,r,mod,row)
    L=len(str(int(row['debut_etat'])))
    check=conditions([w],L)
    assert check['count']==int(row['candidats_dans_la_classe_dyadique'])
    assert check['lo']<=int(row['debut_etat'])<=check['hi']
    assert int(row['debut_etat'])%mod==r

edges=[]
for dep,seq in bydep.items():
    for a,b in zip(seq,seq[1:]):
        w,v=a['mot_IP'],b['mot_IP']
        L=len(str(int(a['debut_etat'])))
        joined=conditions([w,v],L)
        x=int(a['debut_etat']);y=int(a['fin_etat']);z=int(b['fin_etat'])
        assert joined['count']>=1 and joined['lo']<=x<=joined['hi'] and x%joined['mod']==joined['r']
        # Composition affinie des deux mots dans les deux ordres
        A1,B1,D1,_,_=word_prefixes(w)[-1]
        A2,B2,D2,_,_=word_prefixes(v)[-1]
        compA=A1*A2;compB=A2*B1+D1*B2;compD=D1*D2
        assert compA*x+compB==compD*z
        assert A1*x+B1==D1*y
        a_terminal=int(a['profondeur_terminale'])
        a_initial=len(v)-len(v.lstrip('P'))
        assert a_terminal==a_initial,(dep,a_terminal,a_initial)
        # Vérification du raccord exact après la nouvelle tête
        tmp=y
        for _ in range(a_terminal):
            assert tmp%2==0;tmp//=2
        assert tmp%2==1
        alph,bet,gap=asymptotic([w,v])
        edges.append(dict(depart=dep,longueur_initiale=int(a['longueur_depart']),
          position_record=int(a['numero_tete']),longueur_entree=L,
          rang_entree=int(a['rang_debut']),rang_jonction=int(a['rang_fin']),rang_sortie=int(b['rang_fin']),
          mot_avant=w,mot_apres=v,taille_avant=len(w),taille_apres=len(v),
          etat_entree=x,etat_jonction=y,etat_sortie=z,
          profondeur_terminale=a_terminal,P_initiaux_suivants=a_initial,
          porte_avant=sig(a),porte_apres=sig(b),
          chiffre_tete_jonction=int(str(y)[0]),
          n_multiplications=joined['p'],n_divisions=joined['q'],
          coefficient_numerateur=compA,terme_additif=compB,denominateur=compD,
          classe_r=joined['r'],classe_modulo=joined['mod'],
          borne_entree_min=joined['lo'],borne_entree_max=joined['hi'],
          candidats_raccord_dans_longueur=joined['count'],
          limite_alpha=f'{alph.numerator}/{alph.denominator}',
          limite_beta=f'{bet.numerator}/{bet.denominator}',
          intervalle_normalise_positif=int(gap>0)))
assert len(edges)==209
save_csv('209_jonctions_observees_et_certifiees.csv',edges)

counts=Counter((e['mot_avant'],e['mot_apres']) for e in edges)
nodes=Counter(r['mot_IP'] for r in rows)
links=[]
for (w,v),freq in counts.most_common():
    es=[e for e in edges if e['mot_avant']==w and e['mot_apres']==v]
    Ls=sorted(set(e['longueur_entree'] for e in es))
    lprobe=max(Ls)
    aa,bb,gap=asymptotic([w,v]);probe=conditions([w,v],lprobe)
    links.append(dict(mot_source=w,mot_cible=v,occurrences=freq,
      longueurs_entree=';'.join(map(str,Ls)),nombre_longueurs=len(Ls),
      profondeur_initiale_suivante=len(v)-len(v.lstrip('P')),
      n_multiplications=(w+v).count('I'),n_divisions=(w+v).count('P'),
      classe_r=probe['r'],classe_modulo=probe['mod'],
      alpha=f'{aa.numerator}/{aa.denominator}',beta=f'{bb.numerator}/{bb.denominator}',
      largeur_intervalle_limite=f'{gap.numerator}/{gap.denominator}',
      densite_positive_a_grande_longueur=int(gap>0),
      candidats_a_la_plus_grande_longueur_observee=probe['count']))
save_csv('graphe_classes_jonctions_distinctes.csv',links)

# Mot complet de première et deuxième création de tête: count/construction pour plusieurs L
most=Counter(r['mot_IP'] for r in rows)
w5='PIPIPIPIPIPI'
illustrations=[]
for words in [[w5],[w5,w5],['I','PIPIPIPI'],['I','PIPIPIPIPIPI'],['IPI','PIPIPIPI']]:
    for L in [6,8,12,20,30]:
        r=conditions(words,L)
        a,b,gap=asymptotic(words)
        illustrations.append(dict(mots=' | '.join(words),longueur_depart=L,
          classe=f"{r['r']} mod {r['mod']}",
          intervalle_min=r['lo'],intervalle_max=r['hi'],nombre_candidats=r['count'],
          premier_depart=r['first'] or '',dernier_depart=r['last'] or '',
          zone_normalisee_non_nulle=int(gap>0)))
save_csv('exemples_familles_composables.csv',illustrations)

# Vérifications intensives sur quelques nouveaux candidats constructions
rng=random.Random(20261117)
checks=0
for sample in illustrations:
    if not sample['nombre_candidats']:continue
    words=sample['mots'].split(' | ');L=sample['longueur_depart']
    a=conditions(words,L)
    inds={0,a['count']-1,a['count']//2}
    if a['count']>4:inds.add(rng.randrange(a['count']))
    for ind in inds:
        x=a['first']+ind*a['mod'];cur=x
        for stage,word in enumerate(words):
            threshold=10**(L+stage)
            for j,letter in enumerate(word):
                assert (cur&1)==(letter=='I')
                cur=C(cur)
                if j<len(word)-1:assert cur<threshold
                else:assert cur>=threshold
        checks+=1

# Etude durée de projection: chaque paire partage même classe de parité pour toute L
patterns=Counter((e['profondeur_terminale'],e['porte_apres']) for e in edges)
port_edges=Counter((e['porte_avant'],e['porte_apres']) for e in edges)
prefix_categories=Counter(e['profondeur_terminale'] for e in edges)
w5_edge=Counter((e['mot_avant']==w5,e['mot_apres']==w5) for e in edges)
summary={
  'source_rows':len(rows),'trajectoires':len(bydep),'raccordements_observes':len(edges),
  'types_mots_distincts':len(nodes),'types_liens_orientes_distincts':len(links),
  'raccordements_repetes_occurrences':sum(v for v in counts.values() if v>1),
  'raccordements_repetes_types':sum(v>1 for v in counts.values()),
  'raccordements_rearmements':dict(sorted(prefix_categories.items())),
  'jonctions_meme_mot':sum(e['mot_avant']==e['mot_apres'] for e in edges),
  'classes_mot_source_avec_sortants':len({e['mot_avant'] for e in edges}),
  'classes_mot_cible_avec_entrants':len({e['mot_apres'] for e in edges}),
  'liens_avec_zone_limite_positive':sum(e['densite_positive_a_grande_longueur'] for e in links),
  'top_liens':[{k:entry[k] for k in ('mot_source','mot_cible','occurrences','longueurs_entree','profondeur_initiale_suivante')} for entry in links[:12]],
  'portes_apres':dict(Counter(e['porte_apres'] for e in edges)),
  'controle_candidats_independants':checks,
  'W5_W5': {str(L): {key:value for key,value in conditions([w5,w5],L).items() if key in ['lo','hi','r','mod','count','first']} for L in [6,8,12,20,30]},
  'note':'209 raccordements observes dans 21 records, ne représentent pas 209 raccordements possibles universellement.'
}
(OUT/'controles_raccordements.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False,default=str),encoding='utf-8')
print(json.dumps(summary,indent=2,ensure_ascii=False,default=str))

# Graphe des transitions (mots fréquents seulement) et distributions
try:
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    best=[w for w,_ in nodes.most_common(14)]
    size=len(best)
    mat=[[counts.get((u,v),0) for v in best] for u in best]
    fig,ax=plt.subplots(figsize=(13,10));im=ax.imshow(mat,aspect='auto',cmap='Blues')
    ax.set_xticks(range(size),[f'{i+1}: {w[:12]}'+('…' if len(w)>12 else '') for i,w in enumerate(best)],rotation=80,ha='right',fontsize=8)
    ax.set_yticks(range(size),[f'{i+1}: {w[:12]}'+('…' if len(w)>12 else '') for i,w in enumerate(best)],fontsize=8)
    ax.set_xlabel('Mot suivant');ax.set_ylabel('Mot précédent');ax.set_title('Raccordements entre 14 mots Φ–Ψ les plus fréquents (observations)')
    for i in range(size):
        for j in range(size):
            if mat[i][j]:ax.text(j,i,str(mat[i][j]),ha='center',va='center',fontsize=8,color='black')
    fig.colorbar(im,ax=ax,label='Fréquence observée')
    fig.tight_layout();fig.savefig(OUT/'matrice_des_raccordements.png',dpi=170);plt.close(fig)

    fig,ax=plt.subplots(figsize=(9,5))
    xs=sorted(prefix_categories);ys=[prefix_categories[x] for x in xs]
    ax.bar([str(x) for x in xs],ys)
    for i,y in enumerate(ys):ax.text(i,y+1,str(y),ha='center',fontsize=10)
    ax.set_xlabel('Nombre de divisions immédiatement après une création de tête')
    ax.set_ylabel('Raccordements observés')
    ax.set_title('Réarmement dyadique — 209 jonctions exactes')
    fig.tight_layout();fig.savefig(OUT/'rearmements_209_jonctions.png',dpi=170);plt.close(fig)
except ImportError: pass

# Rapport Markdown audit et résultats actualisés par script
from collections import OrderedDict
popular='\n'.join(f"| `{x['mot_source'][:35]}` | `{x['mot_cible'][:35]}` | {x['occurrences']} | {x['profondeur_initiale_suivante']} | {x['nombre_longueurs']} |" for x in links[:12])
ww=summary['W5_W5']
md=f'''# Syracuse Φ–Ψ — Raccordements exacts des 230 mots de première création de tête

## Périmètre et règles

Corpus : **21 trajectoires records**, **230 intervalles** (premiers franchissements successifs de longueur), **133 mots littéraux**. Chaque trajectoire s'arrête au premier maximum de longueur, non au retour à 1. Un raccordement est une paire consécutive de mots, et il y en a exactement **209** (230 − 21). Les mots sont pris dans la suite *classique* avec `I:3n+1`, `P:n/2` ; les calculs des parités utilisent l'opérateur condensé lorsqu'il est indiqué.

Les nombres ci-dessous sont des observations certifiées sur ces trajectoires ; la section « lemmes » donne des formules universelles pour **tout horizon fini**.

## Bilan du graphe observé

- {len(edges)} raccordements consécutifs et **{len(links)} couples ordonnés de mots distincts**.
- {summary['raccordements_repetes_types']} types de couples apparaissent plusieurs fois, totalisant {summary['raccordements_repetes_occurrences']} occurrences.
- {summary['jonctions_meme_mot']} raccordements relient un mot au même mot.
- {summary['classes_mot_source_avec_sortants']} classes de mots ont au moins un raccord sortant, {summary['classes_mot_cible_avec_entrants']} au moins un raccord entrant.
- Distribution des réarmements `P^a` au début du mot suivant : {', '.join(f'a={k} : {v}' for k,v in sorted(prefix_categories.items()))}.
- {summary['liens_avec_zone_limite_positive']} types de couples observés ont une fenêtre **strictement positive dans la limite des longueurs élevées** (le résultat est conditionné au mot fixé).

### Couples de mots les plus récurrents

| Mot précédent | Mot suivant | Observations | Réarmement `a` | Longueurs différentes |
|---|---|---:|---:|---:|
{popular}

## Loi de composition exacte

Pour tout mot valide `w`, écrire `T_w(x)=(3^p x+B_w)/2^q`. Pour deux mots `w` puis `v`,

`T_(v∘w)(x)=[3^(p_w+p_v) x + 3^(p_v) B_w + 2^(q_w) B_v] / 2^(q_w+q_v)`.

Une concordance de motifs de frontières (mêmes retenues en tête, même profondeur terminale, etc.) ne suffit pas à certifier un raccord : il faut la **classe résiduelle complète** et les **bornes de première création** pour les deux étapes. L'intervalle intersection est une fenêtre entière exacte `[A_(w,v)(L),Z_(w,v)(L)]` intersectée avec une classe unique modulo `2^(q_w+q_v+1)`.

Toutes les **209** observations satisfont cette identité, leur classe résiduelle composée et les contraintes de premier franchissement, sans contradiction arithmétique. Des candidats pour plusieurs longueurs ont été reconstruits et vérifiés directement : {checks} contrôles indépendants.

## Le point important : admissibilité ≠ observation

Le graphe des 209 raccords observés est un **sous-graphe** de l'ensemble des raccordements mathématiquement admissibles. Une arête absente du corpus n'est pas interdite. Inversement, assembler deux mots simplement parce que leurs signatures locales coïncident peut inventer une fausse arête : la classe dyadique et les seuils de longueur doivent rester compatibles.

## Stabilité pour l'augmentation décimale L → L+1

À mot composé `v∘w` **fixé** et longueur initiale `L` variable, les états initiaux admissibles satisfont des inégalités affines de la forme `3^p x+B < 2^q 10^(L+j)` ou `≥` pour les premières créations. En posant `z=x/10^L`, les corrections `B/10^L` s'annulent lorsque `L→∞`. On obtient un intervalle fermé à ses frontières `α≤z≤β` à ajuster pour les inégalités strictes. Pour `α<β`, le nombre de départs admissibles croît asymptotiquement comme :

`C_(w,v)(L) = ((β−α)/2^(q_w+q_v+1))·10^L + O(1)`.

Il s'agit d'un théorème de **stabilisation des fenêtres de mots finis**. Il ne certifie pas l'existence d'une seule orbite positive dont les créations se répètent indéfiniment.

## Exemple : W5=PIPIPIPIPIPI

`W5(x)=(729x+1330)/64`, classe initiale `x≡126 mod128`.

Pour la **double composition** `W5 | W5`, les résultats exacts sont :

| Chiffres initiaux L | Candidats admissibles | Premier candidat si non nul |
|---:|---:|---:|
'''
for L,obj in ww.items(): md+=f"| {L} | {obj['count']} | {obj['first'] or '—'} |\n"
md+='''
Ces candidats sont construits pour la succession exacte des deux franchissements. Le nombre de mots successifs fixé reste fini.

## Lemmatisation proposée

**S1 — Composition affine des mots** : formule de composition, preuve par substitution.

**S2 — Congruence dyadique du mot composé** : une classe unique modulo `2^(Q+1)` où `Q` compte les divisions avant le dernier `I`, calculable par inversion de `3^p` modulo `2^(Q+1)`.

**S3 — Raccord exact de réarmement** : si le premier mot se termine par `3u+1`, le second commence par `P^a` avec `a=ν₂(3u+1)` ; une signature réduite ne détermine pas `a` indépendamment de la valeur de `u`.

**S4 — Fenêtre entière d'une chaîne de créations** : pour une liste finie de mots et des frontières décimales successives, l'ensemble des départs est une progression arithmétique unique tronquée par un intervalle entier explicite ; nombre exact par divisions entières.

**S5 — Stabilisation asymptotique des fenêtres finies** : à mots fixes, fenêtre normalisée limite ; densité de candidats `((β−α)/2^(Q+1))10^L + O(1)` si `α<β`.

**S6 — Non-clôture par la seule porte de tête** : conserver seulement les cinq portes et les longueurs peut autoriser des compositions non réalisées par un entier ; la congruence complète et les bornes numériques rétablissent la fidélité.

L'intégralité des 209 raccordements (et les couples de mots distincts) est donnée dans les CSV. Les statistiques ne démontrent aucune propriété des orbites infinies.
'''
(OUT/'Rapport_Raccordements_PhiPsi.md').write_text(md,encoding='utf-8')

# Source latex complet pour S1-S5 et exemple
tex=r'''\documentclass[11pt,a4paper]{article}
\usepackage[utf8]{inputenc}
\usepackage[T1]{fontenc}
\usepackage[french]{babel}
\usepackage{amsmath,amssymb,amsthm,geometry,hyperref}
\geometry{margin=2.4cm}
\newtheorem{lemma}{Lemme}
\newtheorem{theorem}{Théorème}
\newtheorem{remark}{Remarque}
\title{Syracuse $\Phi$--$\Psi$ : composition des mots de création de tête}
\date{17 novembre 2026}
\begin{document}\maketitle
On prend l'opérateur classique $C$, $I(n)=3n+1$ sur les impairs et $P(n)=n/2$ sur les pairs. Une création de tête au niveau $L$ est le premier franchissement de $10^L$. Les mots finissent par $I$ et codent des préfixes finis. On ne suppose pas la convergence universelle.
\begin{lemma}[S1 : composition affine]
À chaque mot admissible $w$ comportant $p_w$ lettres $I$ et $q_w$ lettres $P$ correspond $B_w\in\mathbb N_0$ tel que $T_w(x)=(3^{p_w}x+B_w)/2^{q_w}$. Pour deux mots successifs $w,v$ :
\[
T_{wv}(x)=\frac{3^{p_w+p_v}x+3^{p_v}B_w+2^{q_w}B_v}{2^{q_w+q_v}}.
\]
\end{lemma}
\begin{proof}Composition immédiate des deux transformations affines, par substitution. La constante s'obtient en initialisant $B=0$ et $q=0$, puis en appliquant $B\leftarrow3B+2^q$ pour $I$, et $q\leftarrow q+1$ pour $P$.\end{proof}
\begin{lemma}[S2 : congruence dyadique]
Soit $w$ admissible finissant par $I$, et $Q$ son nombre de lettres $P$. Soit $w^-$ le mot privé du $I$ terminal, et $T_{w^-}(x)=(Ax+B)/2^Q$ avec $A$ impair. L'ensemble des départs entiers réalisant les décisions de parité de $w$ est la classe
\[
x\equiv(2^Q-B)A^{-1}\pmod{2^{Q+1}}.
\]
\end{lemma}
\begin{proof}Le dernier argument du $I$ doit être impair, donc $Ax+B\equiv2^Q\pmod{2^{Q+1}}$. $A=3^{p(w^-)}$ est inversible modulo $2^{Q+1}$. La congruence obtenue impose inductivement l'intégralité et les parités intermédiaires : en parcourant le mot de droite à gauche, chaque $P$ double l'état, tandis que chaque $I$ admet pour inverse $(z-1)/3$ sur la classe requise.\end{proof}
\begin{lemma}[S3 : raccord de réarmement]
Si $w$ crée une tête par l'opération finale $3u+1$, l'état de jonction $y=3u+1$ est pair. La transition suivante est $P$ et, jusqu'à la prochaine opération $I$, le nombre de divisions est exactement $a=\nu_2(y)$. Ainsi, pour des mots consécutifs $w,v$, le mot $v$ commence par $P^a$.
\end{lemma}
\begin{proof}Le résultat de toute opération $I$ est pair, et le nombre de divisions successives jusqu'au prochain entier impair vaut sa valuation $2$-adique.\end{proof}
\begin{theorem}[S4 : fenêtre exacte pour une chaîne finie de créations]
Soit une chaîne de $k$ mots $w_0,\ldots,w_{k-1}$, avec mot concaténé $W$ se terminant par $I$. On fixe la longueur décimale initiale $L$. Pour chaque préfixe de longueur $h$ de $W$, on note $T_h(x)=(A_hx+B_h)/D_h$ avec $A_h=3^{p_h}$ et $D_h=2^{q_h}$. Pour l'étape $i$ ($0\le i<k$), soit $J_i$ l'ensemble des indices correspondant aux préfixes strictement antérieurs au dernier caractère de $w_i$, et $h_i$ l'indice final de ce mot dans $W$. Posons $F_i=10^{L+i}$. Alors l'ensemble des états initiaux de longueur $L$ réalisant ces $k$ premières créations successives, sous le mot $W$, est exactement l'intersection d'une classe $x\equiv r_W\pmod{2^{q_W+1}}$ avec $[A,B]\cap\mathbb Z$, où
\[
 A=\max\left(10^{L-1},\max_i\left\lceil\frac{D_{h_i}F_i-B_{h_i}}{A_{h_i}}\right\rceil\right),
\]
\[
 B=\min\left(10^L-1,\min_i\min_{h\in J_i}\left\lfloor\frac{D_hF_i-1-B_h}{A_h}\right\rfloor\right).
\]
Le nombre de candidats vaut
\[
\max\left(0,\left\lfloor\frac{B-r_W}{2^{q_W+1}}\right\rfloor-\left\lceil\frac{A-r_W}{2^{q_W+1}}\right\rceil+1\right).
\]
\end{theorem}
\begin{proof}À l'intérieur de l'étape $i$, chaque valeur précédant le dernier caractère est strictement inférieure à $F_i$, tandis que la valeur finale lui est supérieure ou égale. Les transformations $T_h$ sont des fonctions affines croissantes sur les entiers admissibles, donc toutes ces inégalités déterminent un intervalle entier. La classe unique de parité de $W$ est donnée par S2. La dernière expression compte les éléments d'une progression arithmétique dans cet intervalle.\end{proof}
\begin{theorem}[S5 : stabilisation des fenêtres à mots finis fixés]
Sous les hypothèses de S4, la chaîne de mots et $k$ restent fixes, tandis que $L\to\infty$. Écrivons $g_h=A_h/D_h$, $z=x/10^L$ et
\[
\alpha=\max\left(\frac1{10},\max_i\frac{10^i}{g_{h_i}}\right),\qquad
\beta=\min\left(1,\min_i\min_{h\in J_i}\frac{10^i}{g_h}\right).
\]
Si $\alpha<\beta$, le nombre de départs entiers de longueur $L$ réalisant exactement cette chaîne vérifie
\[
C_W(L)=\frac{\beta-\alpha}{2^{q_W+1}}\,10^L+O_W(1).
\]
Si $\alpha>\beta$, la famille est vide pour tout $L$ assez grand. Dans le cas limite $\alpha=\beta$, l'asymptotique se réduit à $O_W(1)$ et exige une analyse des termes additifs.
\end{theorem}
\begin{proof}Chacune des bornes de S4 a la forme $c\cdot10^L+O_W(1)$, les coefficients $c$ venant des rapports de puissance $10^i/g_h$, et les constantes $B_h$ restant fixes. Les deux extrémités de l'intervalle entier sont donc $\alpha 10^L+O_W(1)$ et $\beta 10^L+O_W(1)$. Une classe modulo $2^{q_W+1}$ contient $((\beta-\alpha)10^L)/2^{q_W+1}+O_W(1)$ entiers dans cet intervalle dès que $\alpha<\beta$.\end{proof}
\begin{remark}Ces résultats portent sur des chaînes finies de créations. Le passage à une chaîne infinie pour \emph{un entier initial fixé} n'est pas justifié par la seule existence de familles admissibles pour toutes les longueurs. Une union de préfixes compatibles au sens $2$-adique n'est pas nécessairement l'orbite d'un entier positif.\end{remark}
\end{document}
'''
(OUT/'Lemmes_S1_S5.tex').write_text(tex,encoding='utf-8')
zip_path=BASE/'Syracuse_PhiPsi_Raccordements_230_Mots_Dossier.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    z.write(Path(__file__),arcname='analyse_raccordements_phi_psi.py')
    for file in sorted(OUT.iterdir()):
        if file.is_file():z.write(file,arcname=file.name)
print('DOSSIER',zip_path)
