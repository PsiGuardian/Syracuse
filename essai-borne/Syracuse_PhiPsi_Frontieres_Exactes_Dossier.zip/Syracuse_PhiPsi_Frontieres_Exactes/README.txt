SYRACUSE PHI-PSI — FRONTIERES EXACTES S23–S29
================================================
Date : 18 novembre 2026

Documents
- Lemmes_S23_S29.pdf            : manuscrit mathématique (3 pages)
- Lemmes_S23_S29.tex            : source LaTeX
- Rapport_Frontieres_Exactes.md : rapport complet et portée des résultats

Programme
- certification_frontieres.py : moteur arithmétique exact, bibliothèque standard Python
- catalogue_source_133_mots.csv : source des 133 mots
- 230_intervalles_phi_psi_enrichis.csv : 230 observations sources
- 17689_paires_classifiees.csv : référence des fenêtres asymptotiques S18–S22

Contrôle intégral depuis le dossier extrait :
    python3 certification_frontieres.py

Il produit validation_frontieres.json et paires_exactes_L12_L40.csv.
Les résultats vérifiés fournis sont déjà présents dans l'archive.

Principes :
- I = 3n+1 (uniquement si n impair), P = n/2 (uniquement si n pair).
- Chaque mot se termine à la PREMIERE création d'une nouvelle longueur.
- Les signatures du pied, de la tête et des profondeurs de réarmement
  sont des contraintes arithmétiques, non des variables indépendantes.
- Tous les énoncés démontrés portent sur un horizon FINI.
- Les 133 mots proviennent de records particuliers, pas d'un alphabet universel.
