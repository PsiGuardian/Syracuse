#!/usr/bin/env python3
"""Syracuse Phi–Psi: exact finite-length compatibility engine for a fixed chain
of *first new decimal-length* creation words, with parity, head carries, foot
residues and terminal 2-adic rearming. Pure standard library; arbitrary integers.

I(z)=3z+1 on odd inputs; P(z)=z//2 on even inputs.
State describes ALL positive L-digit initial integers realizing the constrained
chain, not just one simulated trajectory. It stores x in [lo,hi] and x=r mod m.
The A,B,q triple records the current affine value y=(A*x+B)/2^q.
"""
from __future__ import annotations
import csv, json, math
from dataclasses import dataclass, replace
from pathlib import Path
from fractions import Fraction
from collections import Counter

HERE=Path(__file__).resolve().parent
CAT=HERE/'catalogue_source_133_mots.csv'


def ceildiv(a,b): return -((-a)//b)


def crt(r,m,s,n):
    """Meet x=r(mod m), x=s(mod n); return (r,lcm) or None."""
    g=math.gcd(m,n)
    if (s-r)%g:return None
    k=n//g
    if k==1:return r % m,m
    t=(((s-r)//g)*pow(m//g,-1,k))%k
    mm=m*k
    return (r+m*t)%mm,mm


@dataclass(frozen=True)
class State:
    L:int
    lo:int
    hi:int
    r:int=0
    m:int=1
    A:int=1
    B:int=0
    q:int=0
    p:int=0
    steps:int=0
    creations:int=0
    def count(self):
        return max(0,(self.hi-self.r)//self.m-(self.lo-1-self.r)//self.m)
    def witness(self):
        x=self.lo+(self.r-self.lo)%self.m
        return x if x<=self.hi else None
    def value(self,x):
        z=self.A*x+self.B
        assert z%(1<<self.q)==0
        return z>>self.q


def init(L):
    assert L>=1
    return State(L,10**(L-1),10**L-1)


def clip_value(s, low=None, high=None):
    """Clip on y=(A*x+B)/2^q; inclusive value bounds."""
    lo=s.lo if low is None else max(s.lo,ceildiv((low<<s.q)-s.B,s.A))
    hi=s.hi if high is None else min(s.hi,((high<<s.q)-s.B)//s.A)
    if lo>hi:return None
    s=replace(s,lo=lo,hi=hi)
    return s if s.count()>0 else None


def impose_congruence(s,t,mod):
    met=crt(s.r,s.m,t,mod)
    if met is None:return None
    rr,mm=met
    s=replace(s,r=rr,m=mm)
    return s if s.count()>0 else None


def impose_parity(s,odd):
    """Before an operation, parity of y=(A*x+B)/2^q."""
    mod=1<<(s.q+1)
    value=(odd*(1<<s.q)-s.B)*pow(s.A,-1,mod)%mod
    return impose_congruence(s,value,mod)


def impose_foot(s,k,t):
    """Current value y ≡ t (mod 10^k).  Exact, no independence assumption."""
    assert k>=1 and 0<=t<10**k
    mod=(1<<s.q)*10**k
    residue=((1<<s.q)*t-s.B)*pow(s.A,-1,mod)%mod
    return impose_congruence(s,residue,mod)


def impose_terminal_rearm(s,a):
    """Require v2(current y)=a; a>=0. For terminal I, a>=1."""
    assert a>=0
    mod=1<<(s.q+a+1)
    r=((1<<s.q)*(1<<a)-s.B)*pow(s.A,-1,mod)%mod
    return impose_congruence(s,r,mod)


def impose_head_gate(s,k,d,c):
    """Before final I, source y has k digits, head=d and incoming carry=c.
    Bdec=10^(k-1); y=d*Bdec+z, 0<=z<Bdec,
    c=floor((3*z+1)/Bdec)."""
    assert k>=2 and 1<=d<=9 and 0<=c<=2
    base=10**(k-1)
    zlo=max(0,ceildiv(c*base-1,3))
    zhi=min(base-1,((c+1)*base-2)//3)
    if zlo>zhi:return None
    return clip_value(s,low=d*base+zlo,high=d*base+zhi)


def apply(s,op):
    assert op in 'IP'
    s=impose_parity(s,int(op=='I'))
    if s is None:return None
    if op=='I':
        return replace(s,A=3*s.A,B=3*s.B+(1<<s.q),p=s.p+1,steps=s.steps+1)
    return replace(s,q=s.q+1,steps=s.steps+1)


def append_word(s,w,head_gate=None,foot=None):
    """Append word w ending I, with its final step *first* crossing
    next record length. head_gate=(d,c) constrains pre-final-I source; foot=(k,t)
    constrains the new terminal value."""
    if not w or w[-1]!='I' or set(w)-set('IP'):raise ValueError(w)
    k=s.L+s.creations    # threshold=10^k, output k+1 digits
    threshold=10**k
    for j,op in enumerate(w):
        if j==len(w)-1 and head_gate is not None:
            s=impose_head_gate(s,k,*head_gate)
            if s is None:return None
        s=apply(s,op)
        if s is None:return None
        s=clip_value(s,low=threshold if j==len(w)-1 else None,
                       high=None if j==len(w)-1 else threshold-1)
        if s is None:return None
    if foot is not None:
        s=impose_foot(s,*foot)
        if s is None:return None
    return replace(s,creations=s.creations+1)


def simulate(n,words):
    x=n; results=[];ops=[]
    maxlen=len(str(x))
    for w in words:
        T=10**maxlen
        for j,op in enumerate(w):
            assert (x%2==1)==(op=='I'),(n,w,op,x)
            pre=x
            if op=='I':x=3*x+1
            else:x//=2
            if j==len(w)-1:assert x>=T,(n,w,x,T)
            else: assert x<T,(n,w,x,T)
            ops.append((op,pre,x))
        maxlen+=1
        results.append(x)
    return results,ops


def observed_tests():
    """Verify 230 creations from supplied CSV, exact witnesses, all affine & parity states."""
    src=HERE/'230_intervalles_phi_psi_enrichis.csv'
    rows=list(csv.DictReader(src.open(encoding='utf-8',newline='')))
    bystart={}
    tested=0; gates=Counter(); rearm=Counter()
    for row in rows:
        n=int(row['depart']);L=int(row['longueur_depart']);w=row['mot_IP']
        s=bystart.get(n,init(L))
        prev=s
        s=append_word(s,w)
        assert s is not None,(n,row['numero_tete'],w)
        assert (n-s.r)%s.m==0 and s.lo<=n<=s.hi,(n,w,s)
        assert s.value(n)==int(row['fin_etat']),(n,w,s.value(n),row['fin_etat'])
        assert s.count()>=1
        pre=int(row['etat_avant_creation']) if row.get('etat_avant_creation') else None
        if pre is None: # Reconstruct pre from endpoint using last I
            pre=(int(row['fin_etat'])-1)//3
        k=L+int(row['numero_tete'])-1
        if k>=2:
            base=10**(k-1)
            d=pre//base
            c=(3*(pre%base)+1)//base
            g=append_word(prev,w,head_gate=(d,c))
            assert g is not None and (n-g.r)%g.m==0 and g.lo<=n<=g.hi
            gates[(int(row['rang_fin'])>1,d,c)]+=1
        a=(int(row['fin_etat'])&-int(row['fin_etat'])).bit_length()-1
        rearm[a]+=1
        g=impose_terminal_rearm(s,a)
        assert g is not None and (n-g.r)%g.m==0 and g.lo<=n<=g.hi
        s=g
        bystart[n]=s
        tested+=1
    assert tested==230
    return {'events':tested,'gate_counts':{str(k):v for k,v in gates.items()},'terminal_rearm_depth':dict(rearm)}


def brute_check():
    """Independent enumeration of small n and their first two length creations."""
    tests=0; word_counts=Counter()
    for L in (2,3,4):
        nums=range(10**(L-1),10**L)
        # Extract all realized first-creation word prefixes up to 120 steps.
        candidates=Counter()
        for x0 in nums:
            x=x0; w='';seg=[]; maximum=L
            for t in range(120):
                if x==1:break
                op='I' if x&1 else 'P'
                x=3*x+1 if x&1 else x//2
                w+=op
                if len(str(x))>maximum:
                    seg.append(w);w='';maximum+=1
                    if len(seg)==2:break
            for d in range(1,len(seg)+1):
                key=tuple(seg[:d])
                if sum(map(len,key))<=120:candidates[key]+=1
        for key,n_actual in candidates.items():
            st=init(L)
            for w in key:
                st=append_word(st,w)
                assert st is not None,(L,key)
            # count ALL x realizing this chain, including ones not enumerated
            # for 120 steps; if total length<=80, every witness enumerated above
            # except for starting x=1, which is outside L>=2.
            assert st.count()==n_actual,(L,key,n_actual,st.count(),st.witness())
            tests+=1
            word_counts[len(key)]+=1
    return {'distinct_bruteforce_chains':tests,'chains_by_depth':dict(word_counts)}


def sample_states():
    words=list(csv.DictReader(CAT.open(encoding='utf-8',newline='')))
    w1=words[0]['mot_IP'];w2=words[1]['mot_IP']
    # S18 window positive for all 133 words (asymptotic); at finite length
    # exact residue mod2^q plus integer bounds may yield no witness.
    records=[]
    for L in (8,12,20,40,60):
        nonempty=0
        for row in words:
            s=append_word(init(L),row['mot_IP'])
            if s is not None:nonempty+=1
        records.append({'L':L,'asymptotic_positive':133,'exact_nonempty_single_words':nonempty})
    # Same word and congruence class can split into several head-carry gates.
    L=8
    st=append_word(init(L),w1)
    assert st is not None
    hist=[]
    for d in range(3,10):
        for c in range(3):
            t=append_word(init(L),w1,head_gate=(d,c))
            if t is not None:
                hist.append({'d':d,'c':c,'count':t.count(),'example':t.witness()})
    pairs=[]
    asymp=list(csv.DictReader((HERE/'17689_paires_classifiees.csv').open(encoding='utf-8',newline='')))
    asymp_label={(int(v['classe_i'])-1,int(v['classe_j'])-1):v['etat'] for v in asymp}
    pairrows=[]
    for L in (8,12,20,30,40,60):
        exact=Counter()
        first=[append_word(init(L),r['mot_IP']) for r in words]
        for i,st in enumerate(first):
            if st is None:continue
            for j,row in enumerate(words):
                follow=append_word(st,row['mot_IP'])
                if follow is None:continue
                label=asymp_label[(i,j)]
                exact[label]+=1
                if L in (12,40):
                    pairrows.append({'L':L,'i':i+1,'j':j+1,'word_i':words[i]['mot_IP'], 'word_j':row['mot_IP'], 'witness':follow.witness(), 'count':follow.count(), 'modulus':follow.m})
        pairs.append({'L':L,'exact_nonempty_pair_words':sum(exact.values()),'classified_by_asymptotic':dict(exact)})
        print('L',L,'pairs',sum(exact.values()),flush=True)
    with (HERE/'paires_exactes_L12_L40.csv').open('w',encoding='utf-8',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=pairrows[0].keys());wr.writeheader();wr.writerows(pairrows)
    return {'word_example':w1,'states_by_length':records,'pairs_by_length':pairs,'last_head_gate_options_L8':hist}


def main():
    exact=observed_tests()
    checked=brute_check()
    samples=sample_states()
    stats={'observed':exact,'independent_bruteforce':checked,'examples':samples}
    target=HERE/'validation_frontieres.json'
    target.write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(stats,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
