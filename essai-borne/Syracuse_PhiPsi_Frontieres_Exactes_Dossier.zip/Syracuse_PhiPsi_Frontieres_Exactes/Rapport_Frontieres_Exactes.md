# Syracuse Φ–Ψ — Frontières exactes et transfert à longueur finie (S23–S29)

**18 novembre 2026 — Complément au catalogue S18–S22.** Cette analyse prolonge la classification des 133 mots de *première création de tête* tirés des 21 trajectoires records. Elle s'appuie sur la récurrence décimale Φ–Ψ du manuscrit v9 (théorème 5.19), sur le lemme d'influence 5.37 et sur les fenêtres S18–S22. Les règles sont démontrées pour des chaînes **finies** et des longueurs initiales fixées. Ni les données ni les lemmes ne démontrent la conjecture de Syracuse.

## 1. Pourquoi l'état rationnel précédent doit être enrichi

S18–S22 utilisent l'état de fenêtre **asymptotique** `(α, β, λ)` en négligeant les décalages additifs des compositions affines à l'ordre `10^{-L}`. Il permet de classifier les *fenêtres limites* de créations successives, mais **pas** de décider de manière exacte, à longueur décimale donnée, le nombre de témoins entiers, le chiffre de tête, la retenue terminale ou le réarmement dyadique.

Nous introduisons l'état exact :

\[
\boxed{\mathfrak E=(L,j,A,b,q;\ell,u;r,M)}
\]

Il représente tous les entiers initiaux `x` de longueur `L` tels que :

\[
\ell\le x\le u,\qquad x\equiv r\pmod M,\qquad y=\frac{Ax+b}{2^q},\quad A=3^p.
\]

`j` est le nombre de premières créations achevées. Les contraintes supplémentaires sur les frontières sont réalisées en *restreignant* ce même ensemble par des intervalles et des congruences ; elles ne constituent pas des probabilités indépendantes.

## 2. Lemmatisation formelle

### S23 — Composition affine exacte avec retenue additive

Pour un état courant `y=(Ax+b)/2^q`, les deux opérations classiques, appliquées uniquement si leur condition de parité est satisfaite, donnent :

\[
I:(A,b,q)\mapsto(3A,3b+2^q,q),\qquad
P:(A,b,q)\mapsto(A,b,q+1).
\]

**Preuve :** substitution directe dans `I(y)=3y+1` et `P(y)=y/2`. Cette récurrence ne dépend pas du nombre de chiffres et préserve exactement le `+1`.

### S24 — Cylindre arithmétique exact des chaînes finies

Avant une opération, `y` est impair pour `I` et pair pour `P`. En posant `π=1` pour `I` et `π=0` pour `P`, la condition s'écrit :

\[
\boxed{x\equiv A^{-1}(\pi 2^q-b)\pmod{2^{q+1}}.}
\]

Ici `A` est impair et donc inversible modulo `2^{q+1}`. Tous les tests de parité d'un mot se condensent par le théorème chinois des restes généralisé : s'ils sont compatibles, ils définissent **une seule** classe `r mod M`; sinon l'ensemble est vide.

Pour la `j`-ième nouvelle tête, on pose `T=10^{L+j-1}`. Chaque état produit avant la dernière lettre du mot doit être `<T`, et le dernier doit être `≥T`. Comme les valeurs affines sont croissantes en `x`, chaque contrainte découpe un **intervalle entier**. L'intersection de toutes ces contraintes demeure un intervalle `[ℓ,u]`.

**Conclusion :** l'ensemble exact des nombres réalisant une chaîne finie donnée de premières créations est **vide** ou une progression arithmétique tronquée :

\[
\boxed{\mathcal C_{L,W}=[\ell,u]\cap\{x:x\equiv r\pmod M\}.}
\]

Pour ce modèle de première création, aucune énumération des `10^L` nombres n'est requise pour compter les témoins.

### S25 — Fenêtre exacte de la retenue Φ–Ψ en tête

Juste avant la multiplication créant `k+1` chiffres, la valeur impaire `y` possède `k` chiffres. Notons `D=10^{k-1}` et `y=dD+z` avec `0≤z<D`. La retenue remontant de droite vers la tête est

\[
\boxed{c=\left\lfloor\frac{3z+1}{D}\right\rfloor\in\{0,1,2\}.}
\]

La signature `(d,c)` est équivalente à un intervalle exact pour `z` :

\[
\boxed{\max\!\left(0,\left\lceil\frac{cD-1}{3}\right\rceil\right)
\le z\le
\min\!\left(D-1,\left\lfloor\frac{(c+1)D-2}{3}\right\rfloor\right).}
\]

Cette contrainte est transposée à l'entier initial `x` au moyen de la valeur affine de `y` et intersectée avec son cylindre actuel.

Si la création survient **après la première opération classique globale**, l'opération précédente est nécessairement `P` : elle donne `y=v/2` avec `v<T=10^k`. Pour franchir `T`, on exige `y≥(T-1)/3`, donc `T/3≈y<T/2`. Les seules portes possibles sont alors :

`(3,1)`, `(3,2)`, `(4,0)`, `(4,1)`, `(4,2)`.

Pour les 230 créations de tête du corpus, 213 surviennent après la première opération, et sont distribuées entre ces portes avec les effectifs : **59, 50, 41, 36, 27**. Les 17 autres surviennent dès la première opération et n'obéissent pas nécessairement à cette restriction.

### S26 — Résidu exact du pied sous un mot composé

Pour imposer les `k` chiffres du pied de la valeur courante, `y≡t (mod 10^k)` avec `0≤t<10^k`, on impose exactement :

\[
\boxed{x\equiv A^{-1}(2^q t-b)\pmod{2^q10^k}.}
\]

Comme `A=3^p`, l'inverse existe modulo `2^q10^k`. Cette contrainte s'intersecte avec la classe de parité par CRT généralisé. Le choix de `t` ne doit donc **jamais** être considéré comme indépendant des décisions de parité ou de la retenue de tête.

### S27 — Profondeur de réarmement dyadique exacte

À la sortie d'un mot terminé par `I`, `y` est pair. Pour imposer que le mot suivant commence par exactement `a≥1` opérations `P` avant une opération `I`, il faut et il suffit que `ν₂(y)=a`, c'est-à-dire :

\[
\boxed{x\equiv A^{-1}(2^{q+a}-b)\pmod{2^{q+a+1}}.}
\]

Le réarmement est ainsi un **raffinement de la congruence dyadique**, et non une étiquette de transition attribuée indépendamment.

### S28 — Fermeture exacte par intersection des frontières

Toute condition de parité, de pied ou de réarmement ajoute une congruence ; toute condition de longueur ou de retenue de tête ajoute un intervalle. L'intersection de deux congruences est vide ou une unique classe modulo le PPCM. L'intersection d'intervalles est un intervalle. La famille des états `\mathfrak E` est donc stable par extension **pour toute chaîne de longueur finie et toute signature de frontières fixée**.

Lorsque plusieurs sorties de tête, pieds ou profondeurs sont possibles, il faut **ramifier** l'état en plusieurs cylindres. L'ensemble des cylindres demeure exact, mais leur nombre n'est pas uniformément borné lorsque la profondeur croît.

### S29 — Comptage sans énumérer les entiers

Pour un état non vide, le nombre d'entiers initiaux admissibles est exactement :

\[
\boxed{\#\mathcal C_{L,W}=\left\lfloor\frac{u-r}{M}\right\rfloor-\left\lfloor\frac{\ell-1-r}{M}\right\rfloor.}
\]

Il s'obtient par comptage des entiers d'une progression arithmétique dans un intervalle, sans calculer leurs trajectoires une par une. Cela n'implique pas un coût indépendant de la taille des coefficients entiers ou du nombre de branches.

## 3. Audit quantitatif du catalogue des 133 mots

Les **133** mots ont une fenêtre asymptotique positive selon S18. Les nombres suivants comptent les classes effectivement réalisables à **longueur initiale fixée** :

| Longueur L | Mots exacts / 133 | Couples exacts / 17 689 | Couples à fenêtre limite positive |
|---:|---:|---:|---:|
| 8 | 89 | 1 418 | 14 879 |
| 12 | 119 | 6 358 | 14 879 |
| 20 | 132 | 12 883 | 14 879 |
| 30 | — | 14 588 | 14 879 |
| 40 | 133 | 14 843 | 14 879 |
| 60 | 133 | 14 879 | 14 879 |

La coïncidence à 60 chiffres est un **résultat calculé sur cet alphabet**, et non un seuil universel pour tous les mots possibles. Dans les six longueurs testées, aucune des 2 810 paires classées comme non positives asymptotiquement n'a été réalisée ; cela ne démontre pas leur impossibilité à toutes petites longueurs.

## 4. Exemple d'une classe subdivisée par ses portes : W₅

Considérons le mot `W₅=PIPIPIPIPIPI`, pour lequel :

\[
T_{W_5}(x)=\frac{729x+1330}{64},\qquad x\equiv126\pmod{128}.
\]

À huit chiffres, la fenêtre de première création donne exactement **24 755** départs admissibles. Pourtant ces 24 755 départs n'ont **pas tous la même frontière** :

| Porte `(d,c)` | Départs admissibles | Premier témoin |
|---|---:|---:|
| `(3,2)` | 4 179 | 10 000 126 |
| `(4,0)` | 6 859 | 10 535 038 |
| `(4,1)` | 6 858 | 11 412 990 |
| `(4,2)` | 6 859 | 12 290 814 |

La porte `(3,1)` n'apparaît pas pour ce mot et cette longueur. Ainsi, **un même mot et une même classe de parité contiennent plusieurs configurations de retenue de tête** : l'état de frontière enrichi apporte une information réellement nouvelle.

La méthode subdivise également ces portes selon les résidus décimaux de pied et selon `ν₂(y)`, en intersections exactes de congruences et fenêtres, sans supposer l'indépendance des facteurs.

## 5. Contrôles et portée

- **230/230** créations du corpus vérifiées, y compris leur valeur terminale, la classe résiduelle et la porte `(d,c)`.
- **922** chaînes distinctes de une ou deux premières créations, obtenues par énumération indépendante des entiers à 2, 3 et 4 chiffres sur 120 opérations, reproduites exactement par le moteur de cylindres.
- Tous les effectifs de couples à 8, 12, 20, 30, 40 et 60 chiffres obtenus par intersections arithmétiques, non par balayage de tous les entiers de ces longueurs.
- La règle du pied et celle des réarmements sont des identités arithmétiques prouvées ; les effectifs sont des audits computationnels reproductibles.
- Le moteur compile les **frontières sélectionnées** mais ne mémorise pas automatiquement chaque retenue de toutes les cellules internes. Ces retenues sont calculables à partir d'un témoin entier et des règles Φ–Ψ ; imposer toutes leurs signatures exige de raffiner les classes.
- Le catalogue de 133 mots n'est **pas** l'ensemble universel de tous les mots possibles ; aucune conclusion sur la convergence universelle n'est établie.

## 6. Prochaine question mathématique

Une fois les fenêtres, congruences, portes et réarmements transportés sans perte à horizon fini, la question restante est de caractériser l'évolution des **familles de cylindres lorsque la profondeur des chaînes n'est plus bornée**. L'opérateur est exact pour tout horizon fini, mais cela ne montre pas qu'une famille de cylindres non vides de profondeurs croissantes contienne un entier positif fixé dont l'orbite réalise toutes les contraintes.

**Fichiers joints** : `certification_frontieres.py`, `validation_frontieres.json`, `paires_exactes_L12_L40.csv`, `effectifs_133_mots_17689_couples.csv`, `portes_tete_W5_L8.csv`, et les trois catalogues sources nécessaires à la reproductibilité.
