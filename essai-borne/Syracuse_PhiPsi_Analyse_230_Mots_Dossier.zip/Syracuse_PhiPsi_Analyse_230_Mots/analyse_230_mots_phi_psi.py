#!/usr/bin/env python3
"""Analyse exacte des 230 intervalles de création de tête (21 records Syracuse).
Aucune dépendance externe. Entrée: deux CSV des préfixes de longueur record.
Sorties: matrice détaillée, comptage des mots, relevé des frontières Φ–Ψ,
contrôles, rapport Markdown. Les tracés sont produits séparément si matplotlib.
"""
import csv, json, math, statistics
from pathlib import Path
from collections import Counter, defaultdict

ROOT=Path('/mnt/data/Syracuse_PhiPsi_Comparaison_21_Prefixes/donnees')
OUT=Path('/mnt/data/Syracuse_PhiPsi_Analyse_230_Mots')
OUT.mkdir(exist_ok=True)

def parse(name):
    with (ROOT/name).open(newline='', encoding='utf8') as f: return list(csv.DictReader(f))
def write_csv(name, rows):
    if not rows:return
    with (OUT/name).open('w', newline='', encoding='utf8') as f:
        wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
def length(x):return len(str(x))
def digit_carries(n):
    assert n&1
    digits=list(map(int,str(n)[::-1]))
    c=1; e=[]; theta=[]
    for d in digits:
        z=3*d+c
        theta.append(z%10);c=z//10;e.append(c)
    y=3*n+1
    assert y==int(''.join(map(str,(theta+[c] if c else theta)[::-1])))
    return {'retenues_completes_pied_vers_tete':''.join(map(str,e)),
            'chiffres_sortie_complets_pied_vers_tete':''.join(map(str,theta)),
            'carry_in_head': 1 if len(digits)==1 else e[-2], 'carry_out_head':e[-1],
            'output_lead':int(str(y)[0]), 'input_lead':digits[-1],
            'carries_nonzero':sum(x>0 for x in e),
            'carry_per_digit':sum(x>0 for x in e)/len(e),
            'carries_0':e.count(0), 'carries_1':e.count(1), 'carries_2':e.count(2),
            'end_carries':str(e[-min(4,len(e)):]), 'input_top3':str(n)[:3],
            'output_top3':str(y)[:3]}

ints=parse('les_230_intervalles_de_creation.csv')
states=parse('toutes_les_5699_transitions.csv')
groups=defaultdict(list)
for r in states:groups[int(r['depart'])].append(r)
for key,v in groups.items():
    assert v[0]['rang']=='0' and int(v[0]['valeur'])==key
    assert all(int(v[i]['rang'])==i for i in range(len(v)))
    for i in range(1,len(v)):
        x=int(v[i-1]['valeur']); expected=3*x+1 if x&1 else x//2
        assert int(v[i]['valeur'])==expected

features=[]; detailed=[]; grouped_words=defaultdict(list); positive_records=[]
for r in ints:
    n=int(r['depart']); prev=int(r['rang_precedent']); end=int(r['rang']); w=r['mot_IP']
    seq=groups[n]
    assert len(w)==int(r['duree'])==end-prev
    assert all(seq[i]['operation_precedente']==c for i,c in zip(range(prev+1,end+1),w))
    start=int(seq[prev]['valeur']); finish=int(seq[end]['valeur'])
    assert str(finish)==r['valeur_franchissement'] and length(finish)==int(r['tete_atteinte'])
    assert length(start)==length(finish)-1
    p=w.count('I');q=w.count('P');assert p==int(r['I']) and q==int(r['P'])
    assert 'II' not in w and w[-1]=='I'
    initial_ps=len(w)-len(w.lstrip('P'))
    a_list=[]; j=initial_ps
    while j<len(w)-1:
        assert w[j]=='I'
        k=j+1
        while k<len(w) and w[k]=='P':k+=1
        assert k>j+1 and (k==len(w) or w[k]=='I')
        a_list.append(k-j-1);j=k
    assert j==len(w)-1 and len(a_list)==p-1
    assert initial_ps+sum(a_list)==q
    # exact affine relation on a fixed word in classic Syracuse
    A=1;B=0;D=1
    for letter in w:
        if letter=='I':B=3*B+D;A*=3
        else:D*=2
    assert A==3**p and D==2**q and (A*start+B)==D*finish
    # La première atteinte de la longueur suivante se traduit par
    # un système fini d'inégalités affines sur la valeur au début du mot.
    L=length(start); frontier=10**L
    pref_A=1;pref_B=0;pref_D=1
    lo=10**(L-1);hi=frontier-1
    for jletter,letter in enumerate(w,1):
        if letter=='I': pref_B=3*pref_B+pref_D;pref_A*=3
        else: pref_D*=2
        if jletter<len(w):
            hi=min(hi,(pref_D*frontier-1-pref_B)//pref_A)
        else:
            lo=max(lo,-((pref_B-pref_D*frontier)//pref_A)) # ceil((D*frontier-B)/A)
    assert lo<=start<=hi,(n,w,start,lo,hi)
    residue_mod=1<<(q+1)
    rr=start%residue_mod
    count_admissible=max(0,(hi-rr)//residue_mod - (-((rr-lo)//residue_mod)) +1)
    if w=='I': assert residue_mod==2
    grouped_words[w].append((start%residue_mod,n,int(r['longueur_initiale'])))
    creation=digit_carries(int(r['valeur_precedente']))
    assert creation['carry_out_head']==int(r['premier_chiffre_nouvelle_tete'])
    assert int(r['valeur_precedente'])==int(seq[end-1]['valeur'])
    max_dip=min(int(seq[t]['longueur']) for t in range(prev,end+1))
    from_last=start
    # local frontier transitions
    add_carry=[0,0,0]; down_div=[0,0]
    for t in range(prev+1,end+1):
        curr=int(seq[t-1]['valeur']); nxt=int(seq[t]['valeur']); op=w[t-(prev+1)]
        dc=length(nxt)-length(curr)
        carry=digit_carries(curr) if op=='I' else None
        if carry: add_carry[carry['carry_out_head']]+=1
        if op=='P':down_div[1 if dc<0 else 0]+=1
        detailed.append(dict(longueur_depart=r['longueur_initiale'],depart=n,numero_tete=r['gain_cumule'],rang=t,
          position_intervalle=t-prev,operation=op,etat_avant=curr,etat_apres=nxt,
          chiffres_avant=length(curr),chiffres_apres=length(nxt),delta_longueur=dc,
          derniere_creation=int(t==end),
          chiffre_tete_entree=carry['input_lead'] if carry else str(curr)[0],
          retenue_phi_entree_tete=carry['carry_in_head'] if carry else '',
          retenue_phi_sortie_tete=carry['carry_out_head'] if carry else '',
          repartition_retenues_phi=(f"{carry['carries_0']}/{carry['carries_1']}/{carry['carries_2']}" if carry else ''),
          retenues_phi_toutes_positions=(carry['retenues_completes_pied_vers_tete'] if carry else ''),
          chiffres_normalises_phi_pied_vers_tete=(carry['chiffres_sortie_complets_pied_vers_tete'] if carry else ''),
          restes_dyadiques_tete_vers_pied=(''.join(str(int(d)%2) for d in str(curr)) if op=='P' else ''),
          part_chiffres_retenue_phi=(round(carry['carry_per_digit'],6) if carry else ''),
          reste_dyadique_tete=(int(str(curr)[0])%2 if op=='P' else ''),
          tete_creation=(carry['output_lead'] if (carry and dc==1) else '')))
    assert sum(add_carry[1:])==int(r['montées_locales'])
    assert down_div[1]==int(r['pertes_locales'])
    if end>1: assert creation['carry_out_head']==1
    if creation['carry_out_head']==2: assert end==1
    # repeat block depth grouping
    maxrun=0; cur=0
    for a in a_list:
        if a==1:cur+=1;maxrun=max(maxrun,cur)
        else:cur=0
    tail=0
    for a in a_list[::-1]:
        if a==1: tail+=1
        else:break
    drift= p*math.log2(3)-q
    assert drift>0
    row=dict(longueur_depart=int(r['longueur_initiale']),depart=n,numero_tete=int(r['gain_cumule']),
      nouvelle_longueur=int(r['tete_atteinte']),rang_debut=prev,rang_fin=end,duree=end-prev,
      debut_etat=start,fin_etat=finish,mot_IP=w,multiplications=p,divisions=q,
      P_initiaux=initial_ps,profondeurs_completes=';'.join(map(str,a_list)),nombre_blocs=len(a_list),
      a1=sum(a==1 for a in a_list),a2=sum(a==2 for a in a_list),a3plus=sum(a>=3 for a in a_list),
      plus_grande_profondeur=max(a_list,default=0),plus_long_corridor_a1=maxrun,
      dernier_corridor_a1=tail,profondeur_terminale=int(r['v2_3n_plus_1']),
      monte= int(r['montées_locales']),pertes=int(r['pertes_locales']),
      oscille=(int(r['montées_locales'])-1),minimum_longueur=max_dip,
      amplitude_recul=length(start)-max_dip,
      flux_multiplicatif_log2=round(drift,8),
      facteur_3p_sur_2q=round(2**drift,8),
      facteur_total=round(finish/start,8),
      terme_additif_B=B,modulo_dyadique=residue_mod,residu_dyadique=start%residue_mod,
      seuil_exact_debut_mot=lo,borne_superieure_premier_franchissement=hi,
      candidats_dans_la_classe_dyadique=count_admissible,
      mantisse_debut=round(start/(10**(length(start)-1)),9),
      mantisse_fin=round(finish/(10**(length(finish)-1)),9),
      chiffre_tete_finale=creation['carry_out_head'],
      chiffre_tete_source=creation['input_lead'],
      retenue_entree_tete=creation['carry_in_head'],
      retenue_sortie_tete=creation['carry_out_head'],
      nombre_retenues_phi_nonnulles_final=creation['carries_nonzero'],
      fraction_retenues_phi_nonnulles_final=round(creation['carry_per_digit'],8),
      prefixe_source_3ch=creation['input_top3'],
      prefixe_sortie_3ch=creation['output_top3'],
      a1_seuls=int(all(a==1 for a in a_list)),
      classe=('direct' if len(w)==1 else 'corridor_a1_pur' if all(a==1 for a in a_list) else 'mixte'))
    if end>1:
        v=int(seq[end-2]['valeur'])
        assert v%4==2 and v//2==int(r['valeur_precedente'])
        assert int(str(v)[0]) in {6,7,8,9}
        row['etat_pair_avant_porte']=v
        row['chiffre_tete_etat_pair']=int(str(v)[0])
    else:
        row['etat_pair_avant_porte']=''
        row['chiffre_tete_etat_pair']=''
    features.append(row)

assert len(features)==230 and len(detailed)==5699
for word,group in grouped_words.items():
    vals={z[0] for z in group}
    assert len(vals)==1,(word,vals)

motlist=[]
for w,instances in sorted(grouped_words.items(),key=lambda t:(-len(t[1]),len(t[0]),t[0])):
    rep=next(d for d in features if d['mot_IP']==w)
    motlist.append(dict(mot_IP=w,occurrences=len(instances),nombre_longueurs_distinctes=len(set(x[2] for x in instances)),
      longueurs_initiales=';'.join(map(str, sorted(set(x[2] for x in instances)))),
      longueur_mot=len(w),I=w.count('I'),P=w.count('P'),classes=rep['classe'],
      residue=instances[0][0],modulo=1<<(w.count('P')+1),
      flux_multiplicatif=rep['facteur_3p_sur_2q']))
write_csv('230_intervalles_phi_psi_enrichis.csv',features)
write_csv('5699_transitions_retenues_frontieres.csv',detailed)
write_csv('133_mots_classes_dyadiques.csv',motlist)

cat=Counter(d['classe'] for d in features)
head=Counter(d['chiffre_tete_finale'] for d in features)
head_source=Counter(d['chiffre_tete_source'] for d in features)
carry_head=Counter(d['retenue_entree_tete'] for d in features)
max_a=Counter(d['plus_grande_profondeur'] for d in features)
last_a=Counter(d['profondeur_terminale'] for d in features)
length=Counter(d['duree'] for d in features)
repeat_words=[m for m in motlist if m['occurrences']>=2]
unique_len_words=[m for m in motlist if m['nombre_longueurs_distinctes']>=2]
large=sorted(features,key=lambda x:-x['duree'])[:10]
bygroup=defaultdict(list)
for d in features:bygroup['court' if d['duree']<=12 else 'intermediaire' if d['duree']<=30 else 'long'].append(d)
report_stats={}
for k,rows in bygroup.items():
    report_stats[k]=dict(n=len(rows),median_duree=statistics.median(d['duree'] for d in rows),
      frac_mixes=round(sum(d['classe']=='mixte' for d in rows)/len(rows),4),
      frac_a1=round(sum(d['a1'] for d in rows)/sum(d['nombre_blocs'] for d in rows),4) if sum(d['nombre_blocs'] for d in rows) else None,
      moyenne_nombre_deux_plus=round(statistics.mean(d['a2']+d['a3plus'] for d in rows),3),
      med_nb_recroisements=statistics.median(d['oscille'] for d in rows),
      recul_max=max(d['amplitude_recul'] for d in rows))
print('total',len(features),'words distinct',len(motlist))
print('class',cat,'head',head,'source head',head_source,'carry in head',carry_head)
print('repeat words',len(repeat_words),'repeated rows',sum(m['occurrences'] for m in repeat_words),
      'words cross L',len(unique_len_words),'rows cross L',sum(m['occurrences'] for m in unique_len_words))
print('max a',max_a,'terminal a',last_a)
print('report groups',report_stats)
print('longest records')
for z in large[:6]:print(z['depart'],z['numero_tete'],z['duree'],'I/P',z['multiplications'],z['divisions'], 'a1/a2/a3+',z['a1'],z['a2'],z['a3plus'],'maxa',z['plus_grande_profondeur'],'osc',z['oscille'],'type',z['classe'])
print('most common')
for m in motlist[:12]:print(m['occurrences'],m['mot_IP'],m['nombre_longueurs_distinctes'], 'residue',m['residue'], '/',m['modulo'])
print('strat lengths',Counter(d['amplitude_recul'] for d in features))
print('correlations for I/P',min(d['divisions']/d['multiplications'] for d in features),max(d['divisions']/d['multiplications'] for d in features))

stats={'total_intervalles':len(features),'transitions':len(detailed),'mots_distincts':len(motlist),
 'mots_repetes':len(repeat_words),'intervalles_avec_mot_repete':sum(m['occurrences'] for m in repeat_words),
 'mots_reemployes_dans_longueurs_differentes':len(unique_len_words),
 'intervalles_avec_mot_interlongueurs':sum(m['occurrences'] for m in unique_len_words),
 'categories':cat,'chiffre_nouvelle_tete':head,'chiffre_source':head_source,
 'retenue_entree_tete':carry_head,'profondeur_terminal':last_a,
 'taille_groupes':report_stats,'maximum_intervalle':max(d['duree'] for d in features)}
(OUT/'controles_230_mots.json').write_text(json.dumps(stats,indent=2,ensure_ascii=False),encoding='utf8')
