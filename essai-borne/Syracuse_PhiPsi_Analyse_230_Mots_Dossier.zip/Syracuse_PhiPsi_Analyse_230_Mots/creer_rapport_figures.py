import csv,math,statistics,collections,json,zipfile
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
SRC=Path('/mnt/data/Syracuse_PhiPsi_Analyse_230_Mots')
rows=list(csv.DictReader((SRC/'230_intervalles_phi_psi_enrichis.csv').open()))
ws=list(csv.DictReader((SRC/'133_mots_classes_dyadiques.csv').open()))
D=collections.Counter(int(x['duree']) for x in rows)
types=collections.Counter(x['classe'] for x in rows)
gates=collections.Counter((int(x['chiffre_tete_source']),int(x['retenue_entree_tete'])) for x in rows if int(x['rang_fin'])>1)
three=collections.Counter(x['chiffre_tete_etat_pair'] for x in rows if x['chiffre_tete_etat_pair'])

# Chart 1 ranked frequency
fig,ax=plt.subplots(figsize=(12.2,5.9))
words=[x for x in ws[:9]]
labels=[x['mot_IP'] for x in words][::-1]
vals=[int(x['occurrences']) for x in words][::-1]
ax.barh(labels,vals)
for j,v in enumerate(vals):ax.text(v+0.3,j,str(v),va='center',fontsize=9)
ax.set(xlabel="Nombre d'intervalles", title='Mots de transitions I/P les plus fréquents — 230 créations de tête')
ax.set_xlim(0,max(vals)+4)
fig.tight_layout();fig.savefig(SRC/'01_mots_recurrents.png',dpi=175);plt.close(fig)

# Chart 2 duration vs number of a>=2
fig,ax=plt.subplots(figsize=(10.5,6.2))
for kind,marker in [('direct','o'),('corridor_a1_pur','s'),('mixte','^')]:
 a=[x for x in rows if x['classe']==kind]
 ax.scatter([int(x['a2'])+int(x['a3plus']) for x in a], [int(x['duree']) for x in a],label=kind,marker=marker,alpha=.65)
ax.set(xlabel='Nombre de blocs internes de profondeur a ≥ 2',ylabel="Durée jusqu'à la nouvelle tête (opérations classiques)",title='Oscillation entre deux records de longueur — 230 intervalles')
ax.legend();ax.grid(alpha=.2)
fig.tight_layout();fig.savefig(SRC/'02_duree_et_profondeurs.png',dpi=175);plt.close(fig)

# Chart 3 gates
fig,ax=plt.subplots(figsize=(10,5.5))
keys=sorted(gates)
vals=[gates[k] for k in keys]
ax.bar([f'd={a}, c={b}' for a,b in keys],vals)
for j,v in enumerate(vals):ax.text(j,v+0.8,str(v),ha='center')
ax.set(title='Cinq portes locales Φ–Ψ — 213 créations après la première opération',ylabel='Occurrences observées',xlabel='Chiffre source en tête d ; retenue entrante c')
ax.set_ylim(0,max(vals)+12)
fig.tight_layout();fig.savefig(SRC/'03_cinq_portes_de_tete.png',dpi=175);plt.close(fig)

# Chart 4 record interval heatmap
starts=sorted(set(int(x['longueur_depart']) for x in rows))
max_g=max(int(x['numero_tete']) for x in rows)
import numpy as np
mat=np.full((len(starts),max_g),np.nan)
for x in rows:
 mat[int(x['longueur_depart'])-1, int(x['numero_tete'])-1]=int(x['duree'])
fig,ax=plt.subplots(figsize=(13.2,7.1))
im=ax.imshow(mat,aspect='auto',cmap='viridis')
ax.set(xlabel='Nouvelle position de tête atteinte (gain cumulé)',ylabel='Longueur initiale',title='Durées des 230 intervalles entre deux records de tête')
ax.set_yticks(range(len(starts)));ax.set_yticklabels(starts)
ax.set_xticks(range(max_g));ax.set_xticklabels(range(1,max_g+1))
fig.colorbar(im,ax=ax,label='Opérations classiques')
fig.tight_layout();fig.savefig(SRC/'04_matrice_durees_21x21.png',dpi=175);plt.close(fig)

# Report
rpt=[]
append=rpt.append
append('# Syracuse Φ–Ψ — Anatomie exacte des 230 mots entre créations de tête')
append('')
append('**Périmètre :** 21 records initiaux, 5 699 transformations classiques, 230 intervalles consécutifs découpés au premier instant où une longueur décimale supplémentaire est créée. On n’inclut aucune transition postérieure au dernier premier franchissement de chaque record.')
append('')
append('## 1. Conventions et audit')
append('')
append('- `I` : transformation impaire `3n+1` ; `P` : division par 2 ; tous les mots se terminent par `I` et ne contiennent jamais `II`.')
append('- Une position de tête nouvelle correspond au premier franchissement d’une puissance de 10 jusque-là jamais atteinte depuis le départ.')
append('- `a = ν₂(3u+1)` pour les blocs impairs→impairs **complètement contenus dans l’intervalle**. La valeur `a` de la dernière création de tête est donnée à part, car les divisions correspondantes sortent de cet intervalle.')
append('- Contrôles : reconstruction de chaque transition à partir de ses deux états, bilan de longueur, affinité exacte de chaque mot, mêmes résidus modulo `2^(P+1)` pour les mots répétés, et tests des frontières décimales et des retenues en base 10.')
append('')
append('## 2. Taxonomie des 230 mots')
append('')
append('| Type de mot | Nombre | Caractéristique |')
append('|---|---:|---|')
append('| `I` direct | 17 | Création dès la première opération du nombre initial |')
append('| Corridor de profondeurs internes exclusivement `a=1` | 64 | Aucun bloc terminé ne contient plus d’une division |')
append('| Mot mixte | 149 | Au moins un bloc interne contient `a≥2` |')
append('')
append('**133 mots littéraux distincts** ; 20 mots apparaissent au moins deux fois et couvrent 117 intervalles. Parmi eux, 19 mots couvrent plusieurs longueurs initiales, pour 115 intervalles.')
append('')
append('| Mot | Occurrences | Longueurs initiales distinctes | Classe dyadique de départ |')
append('|---|---:|---:|---|')
for m in ws[:10]:append(f"| `{m['mot_IP']}` | {m['occurrences']} | {m['nombre_longueurs_distinctes']} | `{m['residue']} mod {m['modulo']}` |")
append('')
append('Tous les mots répétitifs ont effectivement la même classe résiduelle parmi les occurrences observées. Cette fidélité est une conséquence de la détermination des mots de parité par les classes dyadiques, pas une loi statistique inventée.')
append('')
append('## 3. Trois classes de durée')
append('')
append('| Durée d’un intervalle | Nombre | Part de mots mixtes | Profondeurs `a=1` parmi les blocs complets |')
append('|---|---:|---:|---:|')
for name,subset in [('1–12',[x for x in rows if int(x['duree'])<=12]),('13–30',[x for x in rows if 13<=int(x['duree'])<=30]),('31–160',[x for x in rows if int(x['duree'])>=31])]:
 pct=100*sum(x['classe']=='mixte' for x in subset)/len(subset)
 total=sum(int(x['nombre_blocs']) for x in subset);a1=sum(int(x['a1']) for x in subset)
 append(f'| {name} | {len(subset)} | {pct:.1f} % | {100*a1/total if total else 0:.1f} % |')
append('')
append('Sur ces seuls 230 intervalles, toutes les durées supérieures à 30 comprennent au moins un bloc de profondeur 2 ou davantage. Ce n’est pas une loi universelle pour tous les nombres.')
append('')
append('### Les plus longs intervalles')
append('')
append('| Départ (nombre de chiffres) | Gain en cours | Durée | I | P | Blocs a=1/a=2/a≥3 | Profondeur max |')
append('|---:|---:|---:|---:|---:|---|---:|')
for r in sorted(rows,key=lambda z:-int(z['duree']))[:6]:
 append(f"| {r['longueur_depart']} | +{r['numero_tete']} | {r['duree']} | {r['multiplications']} | {r['divisions']} | {r['a1']}/{r['a2']}/{r['a3plus']} | {r['plus_grande_profondeur']} |")
append('')
append('Les intervalles de durée 100 et 160 présentent des compositions de profondeurs différentes. Deux mots peuvent donc contenir le même nombre de multiplications et de divisions sans partager le même ordre de transitions ou les mêmes états de frontière.')
append('')
append('## 4. Lemme R1 — Porte de création après la première opération')
append('')
append('**Énoncé.** Soit `x_t` une trajectoire classique, et `t>1` le premier instant où elle atteint `L+1` chiffres, alors que tous les états précédents ont au plus `L` chiffres. Il existe un entier pair `v=x_(t-2)` et un entier impair `u=x_(t-1)=v/2` tels que :')
append('')
append('`v ≡ 2 (mod 4)`, `2(10^L−1)/3 ≤ v < 10^L`, `u=v/2`, et `x_t=3u+1`.')
append('')
append('Il en résulte que le chiffre de tête de `v` appartient à `{6,7,8,9}`, celui de `u` à `{3,4}`, celui de `x_t` est **1**, et l’étape suivante `/2` ramène la longueur à `L`.')
append('')
append('**Preuve.** Toute étape impaire postérieure au départ est précédée d’au moins une division. L’entier précédent `v=2u` est pair, avec `v<10^L` par définition du premier franchissement. La création impose `3u+1 ≥ 10^L`, donc `v≥2(10^L−1)/3`. En combinant les inégalités, `u ∈ [(10^L−1)/3, 10^L/2)` ; alors `10^L ≤3u+1< (3/2)10^L+1<2·10^L`. La nouvelle tête est donc 1, et la division suivante en fait perdre la position.')
append('')
append('Ceci est universel en base 10 pour l’algorithme classique. Le premier franchissement **à l’itération 1** est l’unique exception possible : une tête commençant par 2 peut alors persister après la division.')
append('')
append('**Contrôle du corpus :** 213 franchissements après le rang 1, tous avec tête créée `1` et chiffre source `3` ou `4` ; 17 franchissements au rang 1, dont 15 avec tête `2` et 2 avec tête `1`.')
append('')
append('## 5. Lemme R2 — Alphabet fini des frontières Φ–Ψ sur les records tardifs')
append('')
append('Lors d’une multiplication classique `3u+1`, écrivons le chiffre de tête du nombre source `d` et la retenue entrante depuis la position immédiatement inférieure `c∈{0,1,2}`. La retenue sortante est `⌊(3d+c)/10⌋`.')
append('')
append('Pour tout nouveau record de longueur à `t>1`, le lemme R1 donne `d∈{3,4}` et la nouvelle tête vaut 1. Il n’existe donc que cinq configurations locales :')
append('')
append('| Chiffre de tête source `d` | Retenue entrante `c` | Nouvelle tête | Occurrences observées |')
append('|---:|---:|---:|---:|')
for (a,b),cnt in sorted(gates.items()):append(f'| {a} | {b} | 1 | {cnt} |')
append('')
append('**Précision :** ce sont cinq types de **jonction locale de création de record**, non cinq classes globales de trajectoires. Les états globaux et leurs historiques restent en nombre non borné.')
append('')
append('## 6. Lemme R3 — Réarmement après une création de tête')
append('')
append('Si une nouvelle tête est créée par `3u+1`, alors ce résultat pair est immédiatement suivi d’au moins une division. Avant la prochaine multiplication, le nombre de divisions successives est exactement `ν₂(3u+1)`.')
append('')
append('Dans les 209 jonctions **entre** deux premières créations successives (à l’intérieur d’un même départ), la séquence initiale `P^b` du mot suivant possède exactement `b=ν₂(3u+1)` calculé au record précédent. Vérification exhaustive : 152 cas `b=1`, 50 cas `b=2`, 7 cas `b=3`.')
append('')
append('Il ne s’agit pas de 209 nouveaux comportements indépendants, mais d’un raccordement temporel déterministe entre les mots, déjà compatible avec l’opérateur Φ–Ψ.')
append('')
append('## 7. Lemme R4 — Affinité d’un mot et classe dyadique')
append('')
append('Pour tout mot admissible `w` se terminant par `I`, contenant `p` opérations impaires et `q` divisions, l’état final est exactement')
append('')
append('`T_w(x) = (3^p x + B_w)/2^q`,')
append('')
append('où `B_w` se calcule par `B←3B+2^q` lors d’un `I`, et `q←q+1` lors d’un `P` (en initialisant `B=q=0`).')
append('')
append('L’ensemble des entiers réalisant exactement ce mot jusqu’au `I` terminal est une classe résiduelle modulo `2^(q+1)` ; l’identité des mots entraîne l’identité de la classe. Tous les groupes répétés du corpus ont satisfait cette vérification.')
append('')
append('## 8. Lemme R5 — Fenêtre entière de première création de tête pour un mot fixé')
append('')
append('Pour un départ `x` à `L` chiffres et un mot admissible `w=w_1…w_H`, notons à chaque préfixe `j` son application affine `T_j(x)=(3^{p_j}x+B_j)/2^{q_j}`. Le fait que `w` crée pour la **première fois** `L+1` chiffres exactement à la dernière étape équivaut à :')
append('')
append('`T_j(x)<10^L` pour `0≤j<H`, et `T_H(x)≥10^L`.')
append('')
append('Ce système détermine exactement une fenêtre entière `A_w(L)≤x≤Z_w(L)`, où')
append('')
append('`A_w(L)=max(10^(L−1), ceil((2^q 10^L−B_w)/3^p))`,')
append('')
append('`Z_w(L)=min(10^L−1, min_(1≤j<H) floor((2^(q_j) 10^L−1−B_j)/3^(p_j)))`.')
append('')
append('L’intersection avec la classe `x ≡ r_w (mod 2^(q+1))` donne **tous** les états à `L` chiffres réalisant exactement ce mot de première création. Un dénombrement exact s’obtient par deux divisions entières, sans parcourir les trajectoires des candidats.')
append('')
append('**Exemple vérifié :** pour `w=PIPIPIPIPIPI` et `L=8`, on trouve `10 000 000 ≤ x ≤ 13 168 722`, `x ≡126 mod128`, soit **24 755 états de départ admissibles**. L’un d’eux, `10 077 694`, est le record intermédiaire du départ `77 671`, conduisant en douze opérations à `114 791 254`.')
append('')
append('L’appartenance à la fenêtre garantit **un préfixe et un premier franchissement**, mais ne prétend pas que tous ces états soient accessibles comme records intermédiaires depuis un départ donné, ni que leurs trajectoires convergent.')
append('')
append('## 9. Lemme R6 — Famille canonique de réarmements superficiels')
append('')
append('Pour `k≥0`, posons `W_k = P(IP)^k I`. Exactement quand `x ≡ -2 (mod 2^(k+2))`, ce mot initial est admissible, et son effet est :')
append('')
append('`T_(W_k)(x) = (3/2)^(k+1) (x+2) − 2`.')
append('')
append('En particulier `PIPIPIPIPIPI = W_5`, `x ≡126 mod128` et `T(x)=(729x+1330)/64`. Les 27 occurrences proviennent de longueurs initiales différentes, mais obéissent à la même loi rationnelle et à la même classe dyadique.')
append('')
append('## 10. Limites de l’inférence')
append('')
append('- Les valeurs `133 mots`, `5 portes observées`, `213 créations tardives` et les fréquences par profondeur proviennent des 21 records sélectionnés : elles ne décrivent pas la fréquence parmi tous les départs.')
append('- Les cinq portes sont en revanche une classification locale **universelle** des premières créations de nouvelle longueur survenant après la première itération classique.')
append('- Les critères R4 et R5 caractérisent des préfixes finis. La classification des trajectoires infinies, et notamment la convergence universelle, demeure distincte et non démontrée.')
append('- Les mécanismes sont des spécialisations et conséquences de la composition affine, des retenues Φ–Ψ et de la superposition établies dans v9 et le lemme 5.37 ; ils ne les remplacent pas.')
append('')
append('## 11. Fichiers produits')
append('')
append('- `230_intervalles_phi_psi_enrichis.csv` : mots, profondeurs, seuils, valeurs, classes dyadiques, paramètres d’affinité, signatures des nouvelles têtes.')
append('- `5699_transitions_retenues_frontieres.csv` : chaque opération classique avec valeur avant/après, variation de longueur, retenue entrante et sortante en tête, histogramme des retenues internes Φ.')
append('- `133_mots_classes_dyadiques.csv` : types littéraux, fréquence, classes et longueurs.')
append('- `controles_230_mots.json` et `analyse_230_mots_phi_psi.py` : contrôles et reproduction intégrale.')
append('- `01` à `04` : graphiques de mots, durées, portes de tête et matrice des intervalles.')
(SRC/'Rapport_Mathematique_230_Mots.md').write_text('\n'.join(rpt)+'\n',encoding='utf8')

# standalone LaTeX excerpt
tex=r'''% Lemmes nouveaux des 230 intervalles ; insertion possible dans le manuscrit Phi--Psi.
% Toutes les transformations C sont les pas de Syracuse classique.
\section*{Lemmes sur les portes de longueur et la classification des mots}
\newcommand{\Ldec}[1]{\ell_{10}(#1)}
\paragraph{Lemme R1 (porte de nouvelle longueur).}
Soit $x_t=C^t(x_0)$ et $t>1$ le premier instant où la longueur décimale atteint $L+1$, alors que $\Ldec{x_j}\leq L$ pour $j<t$. Il existe $v=x_{t-2}$ pair, $u=x_{t-1}=v/2$ impair, tels que
\[
 v\equiv2\pmod4,\qquad
 \frac{2(10^L-1)}3\leq v<10^L,\qquad
 x_t=\frac{3v}{2}+1.
\]
Ainsi le premier chiffre de $v$ appartient à $\{6,7,8,9\}$, celui de $u$ à $\{3,4\}$, celui de $x_t$ est $1$, et $\Ldec{x_{t+1}}=L$.
\emph{Preuve.} Une opération impaire postérieure à l'état initial est précédée d'une division. Par maximalité antérieure $v<10^L$ et par franchissement $3v/2+1\geq10^L$. Les autres bornes et conclusions s'en déduisent.

\paragraph{Lemme R2 (cinq signatures de retenue).}
Soit $d$ le chiffre le plus à gauche de $u$ et $c\in\{0,1,2\}$ sa retenue entrante pour l'opération $3u+1$ de droite à gauche. Sous les hypothèses du lemme R1, $(d,c)$ appartient exactement à l'ensemble des cinq types possibles
\[
 \{(3,1),(3,2),(4,0),(4,1),(4,2)\}.
\]
La retenue sortante vaut toujours $\lfloor(3d+c)/10\rfloor=1$. Ceci classe la jonction locale de tête, non la trajectoire globale.

\paragraph{Lemme R3 (réarmement inter-records).}
Si $x_t=3u+1$ est une première création de tête et $x_s$ est la suivante, pour le même départ, le mot classique de $t$ à $s$ commence exactement par $P^{\nu_2(x_t)}$.
\emph{Preuve.} L'état $x_t$ est pair. Toutes ses divisions forcées avant le prochain impair sont au nombre $\nu_2(x_t)$ ; aucune ne peut créer de nouvelle longueur.

\paragraph{Lemme R4 (composition affine d'un mot).}
Pour un mot classique admissible $w$ de $p$ multiplications impaires et $q$ divisions, terminé par $I$, on a
\[
 T_w(x)=\frac{3^p x+B_w}{2^q},
\]
avec $B_w\geq0$ entier calculé récursivement. Les états initiaux réalisant le mot appartiennent à une classe résiduelle unique modulo $2^{q+1}$.

\paragraph{Lemme R5 (fenêtre de première nouvelle tête).}
Sur un mot fixé $w=w_1\cdots w_H$, posons $T_j(x)=(3^{p_j}x+B_j)/2^{q_j}$. La première atteinte de $L+1$ chiffres au dernier pas équivaut au système
\[
 10^{L-1}\leq x<10^L,\qquad T_j(x)<10^L\quad(0\leq j<H),\qquad T_H(x)\geq10^L.
\]
Sa solution est l'intersection de la classe résiduelle du lemme R4 et d'un intervalle entier explicitement calculable.

\paragraph{Lemme R6 (mot de réarmement superficiel).}
Pour tout $k\geq0$, le mot $W_k=P(IP)^kI$ est réalisé exactement lorsque
\[
 x\equiv-2\pmod{2^{k+2}},\qquad
 T_{W_k}(x)=\left(\frac32\right)^{k+1}(x+2)-2.
\]
\emph{Preuve.} Après le premier $P$, les $k+1$ états visités avant les $I$ sont impairs si et seulement si $x/2\equiv-1\pmod{2^{k+1}}$. En posant $z_0=x/2$, la récurrence $z_{j+1}=(3z_j+1)/2$ donne $z_j+1=(3/2)^j(z_0+1)$, d'où l'identité terminale.
'''
(SRC/'Lemmes_R1_R6.tex').write_text(tex,encoding='utf8')

with zipfile.ZipFile('/mnt/data/Syracuse_PhiPsi_Analyse_230_Mots_Dossier.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for f in sorted(SRC.iterdir()):
  if f.is_file() and f.name!='run.log': z.write(f,arcname='Syracuse_PhiPsi_Analyse_230_Mots/'+f.name)
print('files',list(map(lambda a:a.name,SRC.iterdir())))
print('archive bytes',Path('/mnt/data/Syracuse_PhiPsi_Analyse_230_Mots_Dossier.zip').stat().st_size)
