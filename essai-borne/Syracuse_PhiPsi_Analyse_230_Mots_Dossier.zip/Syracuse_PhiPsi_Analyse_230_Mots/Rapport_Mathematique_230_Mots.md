# Syracuse Φ–Ψ — Anatomie exacte des 230 mots entre créations de tête

**Périmètre :** 21 records initiaux, 5 699 transformations classiques, 230 intervalles consécutifs découpés au premier instant où une longueur décimale supplémentaire est créée. On n’inclut aucune transition postérieure au dernier premier franchissement de chaque record.

## 1. Conventions et audit

- `I` : transformation impaire `3n+1` ; `P` : division par 2 ; tous les mots se terminent par `I` et ne contiennent jamais `II`.
- Une position de tête nouvelle correspond au premier franchissement d’une puissance de 10 jusque-là jamais atteinte depuis le départ.
- `a = ν₂(3u+1)` pour les blocs impairs→impairs **complètement contenus dans l’intervalle**. La valeur `a` de la dernière création de tête est donnée à part, car les divisions correspondantes sortent de cet intervalle.
- Contrôles : reconstruction de chaque transition à partir de ses deux états, bilan de longueur, affinité exacte de chaque mot, mêmes résidus modulo `2^(P+1)` pour les mots répétés, et tests des frontières décimales et des retenues en base 10.

## 2. Taxonomie des 230 mots

| Type de mot | Nombre | Caractéristique |
|---|---:|---|
| `I` direct | 17 | Création dès la première opération du nombre initial |
| Corridor de profondeurs internes exclusivement `a=1` | 64 | Aucun bloc terminé ne contient plus d’une division |
| Mot mixte | 149 | Au moins un bloc interne contient `a≥2` |

**133 mots littéraux distincts** ; 20 mots apparaissent au moins deux fois et couvrent 117 intervalles. Parmi eux, 19 mots couvrent plusieurs longueurs initiales, pour 115 intervalles.

| Mot | Occurrences | Longueurs initiales distinctes | Classe dyadique de départ |
|---|---:|---:|---|
| `PIPIPIPIPIPI` | 27 | 16 | `126 mod 128` |
| `I` | 17 | 17 | `1 mod 2` |
| `PIPIPIPIPI` | 17 | 11 | `62 mod 64` |
| `PIPIPIPI` | 8 | 8 | `30 mod 32` |
| `PIPPIPIPIPIPIPI` | 7 | 5 | `338 mod 512` |
| `PIPIPIPIPIPPIPI` | 5 | 5 | `318 mod 512` |
| `PPIPIPIPIPIPIPI` | 5 | 5 | `508 mod 512` |
| `PIPPIPIPIPIPIPIPI` | 4 | 4 | `338 mod 1024` |
| `IPI` | 3 | 3 | `3 mod 4` |
| `PIPIPIPPIPIPPIPIPIPI` | 3 | 3 | `334 mod 4096` |

Tous les mots répétitifs ont effectivement la même classe résiduelle parmi les occurrences observées. Cette fidélité est une conséquence de la détermination des mots de parité par les classes dyadiques, pas une loi statistique inventée.

## 3. Trois classes de durée

| Durée d’un intervalle | Nombre | Part de mots mixtes | Profondeurs `a=1` parmi les blocs complets |
|---|---:|---:|---:|
| 1–12 | 74 | 1.4 % | 99.6 % |
| 13–30 | 96 | 91.7 % | 79.3 % |
| 31–160 | 60 | 100.0 % | 68.7 % |

Sur ces seuls 230 intervalles, toutes les durées supérieures à 30 comprennent au moins un bloc de profondeur 2 ou davantage. Ce n’est pas une loi universelle pour tous les nombres.

### Les plus longs intervalles

| Départ (nombre de chiffres) | Gain en cours | Durée | I | P | Blocs a=1/a=2/a≥3 | Profondeur max |
|---:|---:|---:|---:|---:|---|---:|
| 19 | +14 | 160 | 63 | 97 | 40/17/5 | 5 |
| 19 | +9 | 100 | 40 | 60 | 26/8/5 | 4 |
| 19 | +18 | 100 | 40 | 60 | 25/10/4 | 5 |
| 21 | +13 | 100 | 40 | 60 | 27/8/4 | 6 |
| 17 | +6 | 87 | 35 | 52 | 25/4/5 | 4 |
| 16 | +6 | 77 | 31 | 46 | 21/5/4 | 4 |

Les intervalles de durée 100 et 160 présentent des compositions de profondeurs différentes. Deux mots peuvent donc contenir le même nombre de multiplications et de divisions sans partager le même ordre de transitions ou les mêmes états de frontière.

## 4. Lemme R1 — Porte de création après la première opération

**Énoncé.** Soit `x_t` une trajectoire classique, et `t>1` le premier instant où elle atteint `L+1` chiffres, alors que tous les états précédents ont au plus `L` chiffres. Il existe un entier pair `v=x_(t-2)` et un entier impair `u=x_(t-1)=v/2` tels que :

`v ≡ 2 (mod 4)`, `2(10^L−1)/3 ≤ v < 10^L`, `u=v/2`, et `x_t=3u+1`.

Il en résulte que le chiffre de tête de `v` appartient à `{6,7,8,9}`, celui de `u` à `{3,4}`, celui de `x_t` est **1**, et l’étape suivante `/2` ramène la longueur à `L`.

**Preuve.** Toute étape impaire postérieure au départ est précédée d’au moins une division. L’entier précédent `v=2u` est pair, avec `v<10^L` par définition du premier franchissement. La création impose `3u+1 ≥ 10^L`, donc `v≥2(10^L−1)/3`. En combinant les inégalités, `u ∈ [(10^L−1)/3, 10^L/2)` ; alors `10^L ≤3u+1< (3/2)10^L+1<2·10^L`. La nouvelle tête est donc 1, et la division suivante en fait perdre la position.

Ceci est universel en base 10 pour l’algorithme classique. Le premier franchissement **à l’itération 1** est l’unique exception possible : une tête commençant par 2 peut alors persister après la division.

**Contrôle du corpus :** 213 franchissements après le rang 1, tous avec tête créée `1` et chiffre source `3` ou `4` ; 17 franchissements au rang 1, dont 15 avec tête `2` et 2 avec tête `1`.

## 5. Lemme R2 — Alphabet fini des frontières Φ–Ψ sur les records tardifs

Lors d’une multiplication classique `3u+1`, écrivons le chiffre de tête du nombre source `d` et la retenue entrante depuis la position immédiatement inférieure `c∈{0,1,2}`. La retenue sortante est `⌊(3d+c)/10⌋`.

Pour tout nouveau record de longueur à `t>1`, le lemme R1 donne `d∈{3,4}` et la nouvelle tête vaut 1. Il n’existe donc que cinq configurations locales :

| Chiffre de tête source `d` | Retenue entrante `c` | Nouvelle tête | Occurrences observées |
|---:|---:|---:|---:|
| 3 | 1 | 1 | 59 |
| 3 | 2 | 1 | 50 |
| 4 | 0 | 1 | 41 |
| 4 | 1 | 1 | 36 |
| 4 | 2 | 1 | 27 |

**Précision :** ce sont cinq types de **jonction locale de création de record**, non cinq classes globales de trajectoires. Les états globaux et leurs historiques restent en nombre non borné.

## 6. Lemme R3 — Réarmement après une création de tête

Si une nouvelle tête est créée par `3u+1`, alors ce résultat pair est immédiatement suivi d’au moins une division. Avant la prochaine multiplication, le nombre de divisions successives est exactement `ν₂(3u+1)`.

Dans les 209 jonctions **entre** deux premières créations successives (à l’intérieur d’un même départ), la séquence initiale `P^b` du mot suivant possède exactement `b=ν₂(3u+1)` calculé au record précédent. Vérification exhaustive : 152 cas `b=1`, 50 cas `b=2`, 7 cas `b=3`.

Il ne s’agit pas de 209 nouveaux comportements indépendants, mais d’un raccordement temporel déterministe entre les mots, déjà compatible avec l’opérateur Φ–Ψ.

## 7. Lemme R4 — Affinité d’un mot et classe dyadique

Pour tout mot admissible `w` se terminant par `I`, contenant `p` opérations impaires et `q` divisions, l’état final est exactement

`T_w(x) = (3^p x + B_w)/2^q`,

où `B_w` se calcule par `B←3B+2^q` lors d’un `I`, et `q←q+1` lors d’un `P` (en initialisant `B=q=0`).

L’ensemble des entiers réalisant exactement ce mot jusqu’au `I` terminal est une classe résiduelle modulo `2^(q+1)` ; l’identité des mots entraîne l’identité de la classe. Tous les groupes répétés du corpus ont satisfait cette vérification.

## 8. Lemme R5 — Fenêtre entière de première création de tête pour un mot fixé

Pour un départ `x` à `L` chiffres et un mot admissible `w=w_1…w_H`, notons à chaque préfixe `j` son application affine `T_j(x)=(3^{p_j}x+B_j)/2^{q_j}`. Le fait que `w` crée pour la **première fois** `L+1` chiffres exactement à la dernière étape équivaut à :

`T_j(x)<10^L` pour `0≤j<H`, et `T_H(x)≥10^L`.

Ce système détermine exactement une fenêtre entière `A_w(L)≤x≤Z_w(L)`, où

`A_w(L)=max(10^(L−1), ceil((2^q 10^L−B_w)/3^p))`,

`Z_w(L)=min(10^L−1, min_(1≤j<H) floor((2^(q_j) 10^L−1−B_j)/3^(p_j)))`.

L’intersection avec la classe `x ≡ r_w (mod 2^(q+1))` donne **tous** les états à `L` chiffres réalisant exactement ce mot de première création. Un dénombrement exact s’obtient par deux divisions entières, sans parcourir les trajectoires des candidats.

**Exemple vérifié :** pour `w=PIPIPIPIPIPI` et `L=8`, on trouve `10 000 000 ≤ x ≤ 13 168 722`, `x ≡126 mod128`, soit **24 755 états de départ admissibles**. L’un d’eux, `10 077 694`, est le record intermédiaire du départ `77 671`, conduisant en douze opérations à `114 791 254`.

L’appartenance à la fenêtre garantit **un préfixe et un premier franchissement**, mais ne prétend pas que tous ces états soient accessibles comme records intermédiaires depuis un départ donné, ni que leurs trajectoires convergent.

## 9. Lemme R6 — Famille canonique de réarmements superficiels

Pour `k≥0`, posons `W_k = P(IP)^k I`. Exactement quand `x ≡ -2 (mod 2^(k+2))`, ce mot initial est admissible, et son effet est :

`T_(W_k)(x) = (3/2)^(k+1) (x+2) − 2`.

En particulier `PIPIPIPIPIPI = W_5`, `x ≡126 mod128` et `T(x)=(729x+1330)/64`. Les 27 occurrences proviennent de longueurs initiales différentes, mais obéissent à la même loi rationnelle et à la même classe dyadique.

## 10. Limites de l’inférence

- Les valeurs `133 mots`, `5 portes observées`, `213 créations tardives` et les fréquences par profondeur proviennent des 21 records sélectionnés : elles ne décrivent pas la fréquence parmi tous les départs.
- Les cinq portes sont en revanche une classification locale **universelle** des premières créations de nouvelle longueur survenant après la première itération classique.
- Les critères R4 et R5 caractérisent des préfixes finis. La classification des trajectoires infinies, et notamment la convergence universelle, demeure distincte et non démontrée.
- Les mécanismes sont des spécialisations et conséquences de la composition affine, des retenues Φ–Ψ et de la superposition établies dans v9 et le lemme 5.37 ; ils ne les remplacent pas.

## 11. Fichiers produits

- `230_intervalles_phi_psi_enrichis.csv` : mots, profondeurs, seuils, valeurs, classes dyadiques, paramètres d’affinité, signatures des nouvelles têtes.
- `5699_transitions_retenues_frontieres.csv` : chaque opération classique avec valeur avant/après, variation de longueur, retenue entrante et sortante en tête, histogramme des retenues internes Φ.
- `133_mots_classes_dyadiques.csv` : types littéraux, fréquence, classes et longueurs.
- `controles_230_mots.json` et `analyse_230_mots_phi_psi.py` : contrôles et reproduction intégrale.
- `01` à `04` : graphiques de mots, durées, portes de tête et matrice des intervalles.
